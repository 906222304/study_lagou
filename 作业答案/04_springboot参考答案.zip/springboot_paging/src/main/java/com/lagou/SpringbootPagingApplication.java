package com.lagou;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootPagingApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootPagingApplication.class, args);
    }

}
