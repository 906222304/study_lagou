package cn.hp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.hp.bean.administrators;
import cn.hp.bean.administratorsExample;

import cn.hp.dao.administratorsMapper;

@Service
public class AdministratorsService {
	@Autowired
	private administratorsMapper administratorsMapper;


	public boolean queryUserAndPasswordAndPermissions(String username, String userpassword, int permissions) {
		// TODO Auto-generated method stub
				administratorsExample administratorsExample = new administratorsExample();
				administratorsExample.or().andAUsernameEqualTo(username).andAPasswordEqualTo(userpassword).andAPermissionsEqualTo(permissions);

				List<administrators> selectByExample = administratorsMapper.selectByExample(administratorsExample);
				if(selectByExample.size()>0) {
					return true;
				}
				
				return false;
	}


	public List<administrators> queryAll() {
		// TODO Auto-generated method stub
		
		return administratorsMapper.selectByExample(null);
	}


	public boolean deleteAdminInfo(int aid) {
		// TODO Auto-generated method stub
		
		return administratorsMapper.deleteByPrimaryKey(aid)>0;
	}


	public boolean addAdmin(administrators admin) {
		// TODO Auto-generated method stub
		return administratorsMapper.insert(admin)>0;
	}


	public List<administrators> queryOneAdmin(String ausername) {
		// TODO Auto-generated method stub
		administratorsExample administratorsExample = new administratorsExample();
		administratorsExample.or().andAUsernameEqualTo(ausername);
		return administratorsMapper.selectByExample(administratorsExample);
	}


	public boolean UpdateAdminInfo(administrators admin) {
		// TODO Auto-generated method stub
		return administratorsMapper.updateByPrimaryKey(admin)>0;
	}


	public administrators selectOne(int aid) {
		// TODO Auto-generated method stub
		return administratorsMapper.selectByPrimaryKey(aid);
	}

}
