package cn.hp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.hp.bean.department;
import cn.hp.bean.departmentExample;
import cn.hp.bean.positionExample;
import cn.hp.bean.staff;
import cn.hp.dao.departmentMapper;
import cn.hp.dao.positionMapper;



@Service
public class departmentService {

	@Autowired
	private departmentMapper departmentMapper;
	@Autowired
	private positionMapper positionMapper;
	
	public List<department> queryAll() {
		// TODO Auto-generated method stub
		
		return departmentMapper.selectByExample(null);
	}

	public boolean deleteDepart(int did) {
		// TODO Auto-generated method stub
//		positionExample positionExample = new positionExample();
//		positionExample.or().andDIdEqualTo(did);
//
//		int isok = positionMapper.deleteByExample(positionExample);
//		if(isok>0) {
			if(departmentMapper.deleteByPrimaryKey(did)>0) {
				return true;
			//}
		}
		
		return false;
	}

	public boolean addDepart(department dep) {
		// TODO Auto-generated method stub
		int insert = departmentMapper.insert(dep);
		if(insert>0) {
			return true;
		}
		return false;
	}

	public List<department> queryOnDepart(String dname) {
		// TODO Auto-generated method stub
		departmentExample departmentExample = new departmentExample();
		departmentExample.or().andDNameEqualTo(dname);
		List<department> selectByExample = departmentMapper.selectByExample(departmentExample);
		return selectByExample;
	}

	public department selectOne(int did) {
		// TODO Auto-generated method stub
		
		return departmentMapper.selectByPrimaryKey(did);
	}

	public boolean UpdateDepart(department d) {
		// TODO Auto-generated method stub
		int updateByPrimaryKey = departmentMapper.updateByPrimaryKey(d);
		if(updateByPrimaryKey>0) {
			return true;
		}
		return false;
	}




	
	
}
