package cn.hp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import cn.hp.bean.staff;
import cn.hp.bean.staffExample;
import cn.hp.dao.staffMapper;

@Service
public class StaffService {
	
	@Autowired
	private staffMapper staffMapper;
	
	public List<staff> queryAll() {

		return staffMapper.selectAll();
	}

	public boolean deleteStaff(int sid) {
		// TODO Auto-generated method stub
		if(staffMapper.deleteByPrimaryKey(sid)>0) {
			return true;
		}
		return false;
	}

	public staff selectOne(int sid) {
		// TODO Auto-generated method stub
		
		return staffMapper.selectBySid(sid);
	}

	public List<staff> queryOnestaff(String sname) {
		// TODO Auto-generated method stub
		staffExample staffExample = new staffExample();
		staffExample.or().andSNameEqualTo(sname);
		List<staff> selectByExample = staffMapper.selectByExample(staffExample);
		return selectByExample;
	}

	public boolean UpdateStaff(staff staff) {
		// TODO Auto-generated method stub
		//System.out.println("要修改的参数"+staff);
		staffExample staffExample = new staffExample();
		staffExample.or().andSIdEqualTo(staff.getsId());
		int i = staffMapper.updateByExample(staff, staffExample);
		if(i>0) {
			return true;
		}
		return false;
	}

	public boolean addStaff(staff s) {
		// TODO Auto-generated method stub
		if(staffMapper.insert(s)>0) {
			return true;
		}
		return false;
	}

}
