package cn.hp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.hp.bean.position;
import cn.hp.dao.positionMapper;

@Service
public class positionService {

	@Autowired
	private positionMapper positionMapper;

	public List<position> queryAll() {
		// TODO Auto-generated method stub
		return positionMapper.selectByExample(null);
	}

	
}
