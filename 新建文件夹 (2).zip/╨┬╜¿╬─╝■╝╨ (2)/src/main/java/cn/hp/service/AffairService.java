package cn.hp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.hp.bean.affair;
import cn.hp.dao.affairMapper;

@Service
public class AffairService {

	@Autowired
	private affairMapper affairMapper;

	public boolean affairFk(affair af) {
		// TODO Auto-generated method stub
		if(affairMapper.insert(af)>0) {
			return true;
		}
		return false;
	}

	public List<affair> queryAll() {
		// TODO Auto-generated method stub
		return affairMapper.selectByExample(null);
	}

	public boolean deleteAffair(int afId) {
		// TODO Auto-generated method stub
		int deleteByPrimaryKey = affairMapper.deleteByPrimaryKey(afId);
		
		return deleteByPrimaryKey>0;
	}

	public affair selectOne(int afId) {
		// TODO Auto-generated method stub
		return affairMapper.selectByPrimaryKey(afId);
	}
	

}
