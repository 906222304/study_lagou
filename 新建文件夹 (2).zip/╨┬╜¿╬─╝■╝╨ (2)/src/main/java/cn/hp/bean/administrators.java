package cn.hp.bean;

public class administrators {
    private Integer aId;

    private String aUsername;

    private String aPassword;

    private Integer aPermissions;

    public Integer getaId() {
        return aId;
    }

    public void setaId(Integer aId) {
        this.aId = aId;
    }

    public String getaUsername() {
        return aUsername;
    }

    public void setaUsername(String aUsername) {
        this.aUsername = aUsername == null ? null : aUsername.trim();
    }

    public String getaPassword() {
        return aPassword;
    }

    public void setaPassword(String aPassword) {
        this.aPassword = aPassword == null ? null : aPassword.trim();
    }

    public Integer getaPermissions() {
        return aPermissions;
    }

    public void setaPermissions(Integer aPermissions) {
        this.aPermissions = aPermissions;
    }

	public administrators(Integer aId, String aUsername, String aPassword, Integer aPermissions) {
		super();
		this.aId = aId;
		this.aUsername = aUsername;
		this.aPassword = aPassword;
		this.aPermissions = aPermissions;
	}

	public administrators(String aUsername, String aPassword) {
		super();
		this.aUsername = aUsername;
		this.aPassword = aPassword;
	}

	public administrators(String aUsername, String aPassword, Integer aPermissions) {
		super();
		this.aUsername = aUsername;
		this.aPassword = aPassword;
		this.aPermissions = aPermissions;
	}

	/**
	 * 
	 */
	public administrators() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
	
    
}