package cn.hp.bean;

import java.util.Date;

public class staff {
    private Integer sId;

    private String sName;

    private String sSex;

    private String sRofs;

    private String sAddress;

    private String sMarriage;

    private String sMajor;

    private String sNative;

    private String sPolitical;

    private String sMinority;

    private String sPhone;

    private Integer dId;

    private Integer pId;

    private Double sMoneyWages;

    private Date sBirthday;

    private Date sEntrydate;

    private Date sBecomedate;

    private String sEmployment;

    private String sState;

    public Integer getsId() {
        return sId;
    }

    public void setsId(Integer sId) {
        this.sId = sId;
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName == null ? null : sName.trim();
    }

    public String getsSex() {
        return sSex;
    }

    public void setsSex(String sSex) {
        this.sSex = sSex == null ? null : sSex.trim();
    }

    public String getsRofs() {
        return sRofs;
    }

    public void setsRofs(String sRofs) {
        this.sRofs = sRofs == null ? null : sRofs.trim();
    }

    public String getsAddress() {
        return sAddress;
    }

    public void setsAddress(String sAddress) {
        this.sAddress = sAddress == null ? null : sAddress.trim();
    }

    public String getsMarriage() {
        return sMarriage;
    }

    public void setsMarriage(String sMarriage) {
        this.sMarriage = sMarriage == null ? null : sMarriage.trim();
    }

    public String getsMajor() {
        return sMajor;
    }

    public void setsMajor(String sMajor) {
        this.sMajor = sMajor == null ? null : sMajor.trim();
    }

    public String getsNative() {
        return sNative;
    }

    public void setsNative(String sNative) {
        this.sNative = sNative == null ? null : sNative.trim();
    }

    public String getsPolitical() {
        return sPolitical;
    }

    public void setsPolitical(String sPolitical) {
        this.sPolitical = sPolitical == null ? null : sPolitical.trim();
    }

    public String getsMinority() {
        return sMinority;
    }

    public void setsMinority(String sMinority) {
        this.sMinority = sMinority == null ? null : sMinority.trim();
    }

    public String getsPhone() {
        return sPhone;
    }

    public void setsPhone(String sPhone) {
        this.sPhone = sPhone == null ? null : sPhone.trim();
    }

    public Integer getdId() {
        return dId;
    }

    public void setdId(Integer dId) {
        this.dId = dId;
    }

    public Integer getpId() {
        return pId;
    }

    public void setpId(Integer pId) {
        this.pId = pId;
    }

    public Double getsMoneyWages() {
        return sMoneyWages;
    }

    public void setsMoneyWages(Double sMoneyWages) {
        this.sMoneyWages = sMoneyWages;
    }

    public Date getsBirthday() {
        return sBirthday;
    }

    public void setsBirthday(Date sBirthday) {
        this.sBirthday = sBirthday;
    }

    public Date getsEntrydate() {
        return sEntrydate;
    }

    public void setsEntrydate(Date sEntrydate) {
        this.sEntrydate = sEntrydate;
    }

    public Date getsBecomedate() {
        return sBecomedate;
    }

    public void setsBecomedate(Date sBecomedate) {
        this.sBecomedate = sBecomedate;
    }

    public String getsEmployment() {
        return sEmployment;
    }

    public void setsEmployment(String sEmployment) {
        this.sEmployment = sEmployment == null ? null : sEmployment.trim();
    }

    public String getsState() {
        return sState;
    }

    public void setsState(String sState) {
        this.sState = sState == null ? null : sState.trim();
    }
    

	/**
	 * 
	 */
	public staff() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sId
	 * @param sName
	 * @param sSex
	 * @param sRofs
	 * @param sAddress
	 * @param sMarriage
	 * @param sMajor
	 * @param sNative
	 * @param sPolitical
	 * @param sMinority
	 * @param sPhone
	 * @param dId
	 * @param pId
	 * @param sMoneyWages
	 * @param sBirthday
	 * @param sEntrydate
	 * @param sBecomedate
	 * @param sEmployment
	 * @param sState
	 */
	public staff(Integer sId, String sName, String sSex, String sRofs, String sAddress, String sMarriage, String sMajor,
			String sNative, String sPolitical, String sMinority, String sPhone, Integer dId, Integer pId,
			Double sMoneyWages, Date sBirthday, Date sEntrydate, Date sBecomedate, String sEmployment, String sState) {
		this.sId = sId;
		this.sName = sName;
		this.sSex = sSex;
		this.sRofs = sRofs;
		this.sAddress = sAddress;
		this.sMarriage = sMarriage;
		this.sMajor = sMajor;
		this.sNative = sNative;
		this.sPolitical = sPolitical;
		this.sMinority = sMinority;
		this.sPhone = sPhone;
		this.dId = dId;
		this.pId = pId;
		this.sMoneyWages = sMoneyWages;
		this.sBirthday = sBirthday;
		this.sEntrydate = sEntrydate;
		this.sBecomedate = sBecomedate;
		this.sEmployment = sEmployment;
		this.sState = sState;
	}

	@Override
	public String toString() {
		return "staff [sId=" + sId + ", sName=" + sName + ", sSex=" + sSex + ", sRofs=" + sRofs + ", sAddress="
				+ sAddress + ", sMarriage=" + sMarriage + ", sMajor=" + sMajor + ", sNative=" + sNative
				+ ", sPolitical=" + sPolitical + ", sMinority=" + sMinority + ", sPhone=" + sPhone + ", dId=" + dId
				+ ", pId=" + pId + ", sMoneyWages=" + sMoneyWages + ", sBirthday=" + sBirthday + ", sEntrydate="
				+ sEntrydate + ", sBecomedate=" + sBecomedate + ", sEmployment=" + sEmployment + ", sState=" + sState
				+ "]";
	}
    
}