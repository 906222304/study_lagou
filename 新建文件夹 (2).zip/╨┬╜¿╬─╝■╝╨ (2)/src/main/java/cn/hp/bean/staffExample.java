package cn.hp.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class staffExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public staffExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andSIdIsNull() {
            addCriterion("S_id is null");
            return (Criteria) this;
        }

        public Criteria andSIdIsNotNull() {
            addCriterion("S_id is not null");
            return (Criteria) this;
        }

        public Criteria andSIdEqualTo(Integer value) {
            addCriterion("S_id =", value, "sId");
            return (Criteria) this;
        }

        public Criteria andSIdNotEqualTo(Integer value) {
            addCriterion("S_id <>", value, "sId");
            return (Criteria) this;
        }

        public Criteria andSIdGreaterThan(Integer value) {
            addCriterion("S_id >", value, "sId");
            return (Criteria) this;
        }

        public Criteria andSIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("S_id >=", value, "sId");
            return (Criteria) this;
        }

        public Criteria andSIdLessThan(Integer value) {
            addCriterion("S_id <", value, "sId");
            return (Criteria) this;
        }

        public Criteria andSIdLessThanOrEqualTo(Integer value) {
            addCriterion("S_id <=", value, "sId");
            return (Criteria) this;
        }

        public Criteria andSIdIn(List<Integer> values) {
            addCriterion("S_id in", values, "sId");
            return (Criteria) this;
        }

        public Criteria andSIdNotIn(List<Integer> values) {
            addCriterion("S_id not in", values, "sId");
            return (Criteria) this;
        }

        public Criteria andSIdBetween(Integer value1, Integer value2) {
            addCriterion("S_id between", value1, value2, "sId");
            return (Criteria) this;
        }

        public Criteria andSIdNotBetween(Integer value1, Integer value2) {
            addCriterion("S_id not between", value1, value2, "sId");
            return (Criteria) this;
        }

        public Criteria andSNameIsNull() {
            addCriterion("S_name is null");
            return (Criteria) this;
        }

        public Criteria andSNameIsNotNull() {
            addCriterion("S_name is not null");
            return (Criteria) this;
        }

        public Criteria andSNameEqualTo(String value) {
            addCriterion("S_name =", value, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameNotEqualTo(String value) {
            addCriterion("S_name <>", value, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameGreaterThan(String value) {
            addCriterion("S_name >", value, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameGreaterThanOrEqualTo(String value) {
            addCriterion("S_name >=", value, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameLessThan(String value) {
            addCriterion("S_name <", value, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameLessThanOrEqualTo(String value) {
            addCriterion("S_name <=", value, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameLike(String value) {
            addCriterion("S_name like", value, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameNotLike(String value) {
            addCriterion("S_name not like", value, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameIn(List<String> values) {
            addCriterion("S_name in", values, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameNotIn(List<String> values) {
            addCriterion("S_name not in", values, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameBetween(String value1, String value2) {
            addCriterion("S_name between", value1, value2, "sName");
            return (Criteria) this;
        }

        public Criteria andSNameNotBetween(String value1, String value2) {
            addCriterion("S_name not between", value1, value2, "sName");
            return (Criteria) this;
        }

        public Criteria andSSexIsNull() {
            addCriterion("S_sex is null");
            return (Criteria) this;
        }

        public Criteria andSSexIsNotNull() {
            addCriterion("S_sex is not null");
            return (Criteria) this;
        }

        public Criteria andSSexEqualTo(String value) {
            addCriterion("S_sex =", value, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexNotEqualTo(String value) {
            addCriterion("S_sex <>", value, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexGreaterThan(String value) {
            addCriterion("S_sex >", value, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexGreaterThanOrEqualTo(String value) {
            addCriterion("S_sex >=", value, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexLessThan(String value) {
            addCriterion("S_sex <", value, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexLessThanOrEqualTo(String value) {
            addCriterion("S_sex <=", value, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexLike(String value) {
            addCriterion("S_sex like", value, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexNotLike(String value) {
            addCriterion("S_sex not like", value, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexIn(List<String> values) {
            addCriterion("S_sex in", values, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexNotIn(List<String> values) {
            addCriterion("S_sex not in", values, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexBetween(String value1, String value2) {
            addCriterion("S_sex between", value1, value2, "sSex");
            return (Criteria) this;
        }

        public Criteria andSSexNotBetween(String value1, String value2) {
            addCriterion("S_sex not between", value1, value2, "sSex");
            return (Criteria) this;
        }

        public Criteria andSRofsIsNull() {
            addCriterion("S_rofs is null");
            return (Criteria) this;
        }

        public Criteria andSRofsIsNotNull() {
            addCriterion("S_rofs is not null");
            return (Criteria) this;
        }

        public Criteria andSRofsEqualTo(String value) {
            addCriterion("S_rofs =", value, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsNotEqualTo(String value) {
            addCriterion("S_rofs <>", value, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsGreaterThan(String value) {
            addCriterion("S_rofs >", value, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsGreaterThanOrEqualTo(String value) {
            addCriterion("S_rofs >=", value, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsLessThan(String value) {
            addCriterion("S_rofs <", value, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsLessThanOrEqualTo(String value) {
            addCriterion("S_rofs <=", value, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsLike(String value) {
            addCriterion("S_rofs like", value, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsNotLike(String value) {
            addCriterion("S_rofs not like", value, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsIn(List<String> values) {
            addCriterion("S_rofs in", values, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsNotIn(List<String> values) {
            addCriterion("S_rofs not in", values, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsBetween(String value1, String value2) {
            addCriterion("S_rofs between", value1, value2, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSRofsNotBetween(String value1, String value2) {
            addCriterion("S_rofs not between", value1, value2, "sRofs");
            return (Criteria) this;
        }

        public Criteria andSAddressIsNull() {
            addCriterion("S_address is null");
            return (Criteria) this;
        }

        public Criteria andSAddressIsNotNull() {
            addCriterion("S_address is not null");
            return (Criteria) this;
        }

        public Criteria andSAddressEqualTo(String value) {
            addCriterion("S_address =", value, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressNotEqualTo(String value) {
            addCriterion("S_address <>", value, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressGreaterThan(String value) {
            addCriterion("S_address >", value, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressGreaterThanOrEqualTo(String value) {
            addCriterion("S_address >=", value, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressLessThan(String value) {
            addCriterion("S_address <", value, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressLessThanOrEqualTo(String value) {
            addCriterion("S_address <=", value, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressLike(String value) {
            addCriterion("S_address like", value, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressNotLike(String value) {
            addCriterion("S_address not like", value, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressIn(List<String> values) {
            addCriterion("S_address in", values, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressNotIn(List<String> values) {
            addCriterion("S_address not in", values, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressBetween(String value1, String value2) {
            addCriterion("S_address between", value1, value2, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSAddressNotBetween(String value1, String value2) {
            addCriterion("S_address not between", value1, value2, "sAddress");
            return (Criteria) this;
        }

        public Criteria andSMarriageIsNull() {
            addCriterion("S_Marriage is null");
            return (Criteria) this;
        }

        public Criteria andSMarriageIsNotNull() {
            addCriterion("S_Marriage is not null");
            return (Criteria) this;
        }

        public Criteria andSMarriageEqualTo(String value) {
            addCriterion("S_Marriage =", value, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageNotEqualTo(String value) {
            addCriterion("S_Marriage <>", value, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageGreaterThan(String value) {
            addCriterion("S_Marriage >", value, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageGreaterThanOrEqualTo(String value) {
            addCriterion("S_Marriage >=", value, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageLessThan(String value) {
            addCriterion("S_Marriage <", value, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageLessThanOrEqualTo(String value) {
            addCriterion("S_Marriage <=", value, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageLike(String value) {
            addCriterion("S_Marriage like", value, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageNotLike(String value) {
            addCriterion("S_Marriage not like", value, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageIn(List<String> values) {
            addCriterion("S_Marriage in", values, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageNotIn(List<String> values) {
            addCriterion("S_Marriage not in", values, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageBetween(String value1, String value2) {
            addCriterion("S_Marriage between", value1, value2, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMarriageNotBetween(String value1, String value2) {
            addCriterion("S_Marriage not between", value1, value2, "sMarriage");
            return (Criteria) this;
        }

        public Criteria andSMajorIsNull() {
            addCriterion("S_major is null");
            return (Criteria) this;
        }

        public Criteria andSMajorIsNotNull() {
            addCriterion("S_major is not null");
            return (Criteria) this;
        }

        public Criteria andSMajorEqualTo(String value) {
            addCriterion("S_major =", value, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorNotEqualTo(String value) {
            addCriterion("S_major <>", value, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorGreaterThan(String value) {
            addCriterion("S_major >", value, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorGreaterThanOrEqualTo(String value) {
            addCriterion("S_major >=", value, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorLessThan(String value) {
            addCriterion("S_major <", value, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorLessThanOrEqualTo(String value) {
            addCriterion("S_major <=", value, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorLike(String value) {
            addCriterion("S_major like", value, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorNotLike(String value) {
            addCriterion("S_major not like", value, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorIn(List<String> values) {
            addCriterion("S_major in", values, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorNotIn(List<String> values) {
            addCriterion("S_major not in", values, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorBetween(String value1, String value2) {
            addCriterion("S_major between", value1, value2, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSMajorNotBetween(String value1, String value2) {
            addCriterion("S_major not between", value1, value2, "sMajor");
            return (Criteria) this;
        }

        public Criteria andSNativeIsNull() {
            addCriterion("S_Native is null");
            return (Criteria) this;
        }

        public Criteria andSNativeIsNotNull() {
            addCriterion("S_Native is not null");
            return (Criteria) this;
        }

        public Criteria andSNativeEqualTo(String value) {
            addCriterion("S_Native =", value, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeNotEqualTo(String value) {
            addCriterion("S_Native <>", value, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeGreaterThan(String value) {
            addCriterion("S_Native >", value, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeGreaterThanOrEqualTo(String value) {
            addCriterion("S_Native >=", value, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeLessThan(String value) {
            addCriterion("S_Native <", value, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeLessThanOrEqualTo(String value) {
            addCriterion("S_Native <=", value, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeLike(String value) {
            addCriterion("S_Native like", value, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeNotLike(String value) {
            addCriterion("S_Native not like", value, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeIn(List<String> values) {
            addCriterion("S_Native in", values, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeNotIn(List<String> values) {
            addCriterion("S_Native not in", values, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeBetween(String value1, String value2) {
            addCriterion("S_Native between", value1, value2, "sNative");
            return (Criteria) this;
        }

        public Criteria andSNativeNotBetween(String value1, String value2) {
            addCriterion("S_Native not between", value1, value2, "sNative");
            return (Criteria) this;
        }

        public Criteria andSPoliticalIsNull() {
            addCriterion("S_Political is null");
            return (Criteria) this;
        }

        public Criteria andSPoliticalIsNotNull() {
            addCriterion("S_Political is not null");
            return (Criteria) this;
        }

        public Criteria andSPoliticalEqualTo(String value) {
            addCriterion("S_Political =", value, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalNotEqualTo(String value) {
            addCriterion("S_Political <>", value, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalGreaterThan(String value) {
            addCriterion("S_Political >", value, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalGreaterThanOrEqualTo(String value) {
            addCriterion("S_Political >=", value, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalLessThan(String value) {
            addCriterion("S_Political <", value, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalLessThanOrEqualTo(String value) {
            addCriterion("S_Political <=", value, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalLike(String value) {
            addCriterion("S_Political like", value, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalNotLike(String value) {
            addCriterion("S_Political not like", value, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalIn(List<String> values) {
            addCriterion("S_Political in", values, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalNotIn(List<String> values) {
            addCriterion("S_Political not in", values, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalBetween(String value1, String value2) {
            addCriterion("S_Political between", value1, value2, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSPoliticalNotBetween(String value1, String value2) {
            addCriterion("S_Political not between", value1, value2, "sPolitical");
            return (Criteria) this;
        }

        public Criteria andSMinorityIsNull() {
            addCriterion("S_minority is null");
            return (Criteria) this;
        }

        public Criteria andSMinorityIsNotNull() {
            addCriterion("S_minority is not null");
            return (Criteria) this;
        }

        public Criteria andSMinorityEqualTo(String value) {
            addCriterion("S_minority =", value, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityNotEqualTo(String value) {
            addCriterion("S_minority <>", value, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityGreaterThan(String value) {
            addCriterion("S_minority >", value, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityGreaterThanOrEqualTo(String value) {
            addCriterion("S_minority >=", value, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityLessThan(String value) {
            addCriterion("S_minority <", value, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityLessThanOrEqualTo(String value) {
            addCriterion("S_minority <=", value, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityLike(String value) {
            addCriterion("S_minority like", value, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityNotLike(String value) {
            addCriterion("S_minority not like", value, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityIn(List<String> values) {
            addCriterion("S_minority in", values, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityNotIn(List<String> values) {
            addCriterion("S_minority not in", values, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityBetween(String value1, String value2) {
            addCriterion("S_minority between", value1, value2, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSMinorityNotBetween(String value1, String value2) {
            addCriterion("S_minority not between", value1, value2, "sMinority");
            return (Criteria) this;
        }

        public Criteria andSPhoneIsNull() {
            addCriterion("S_phone is null");
            return (Criteria) this;
        }

        public Criteria andSPhoneIsNotNull() {
            addCriterion("S_phone is not null");
            return (Criteria) this;
        }

        public Criteria andSPhoneEqualTo(String value) {
            addCriterion("S_phone =", value, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneNotEqualTo(String value) {
            addCriterion("S_phone <>", value, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneGreaterThan(String value) {
            addCriterion("S_phone >", value, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("S_phone >=", value, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneLessThan(String value) {
            addCriterion("S_phone <", value, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneLessThanOrEqualTo(String value) {
            addCriterion("S_phone <=", value, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneLike(String value) {
            addCriterion("S_phone like", value, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneNotLike(String value) {
            addCriterion("S_phone not like", value, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneIn(List<String> values) {
            addCriterion("S_phone in", values, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneNotIn(List<String> values) {
            addCriterion("S_phone not in", values, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneBetween(String value1, String value2) {
            addCriterion("S_phone between", value1, value2, "sPhone");
            return (Criteria) this;
        }

        public Criteria andSPhoneNotBetween(String value1, String value2) {
            addCriterion("S_phone not between", value1, value2, "sPhone");
            return (Criteria) this;
        }

        public Criteria andDIdIsNull() {
            addCriterion("D_id is null");
            return (Criteria) this;
        }

        public Criteria andDIdIsNotNull() {
            addCriterion("D_id is not null");
            return (Criteria) this;
        }

        public Criteria andDIdEqualTo(Integer value) {
            addCriterion("D_id =", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdNotEqualTo(Integer value) {
            addCriterion("D_id <>", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdGreaterThan(Integer value) {
            addCriterion("D_id >", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("D_id >=", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdLessThan(Integer value) {
            addCriterion("D_id <", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdLessThanOrEqualTo(Integer value) {
            addCriterion("D_id <=", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdIn(List<Integer> values) {
            addCriterion("D_id in", values, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdNotIn(List<Integer> values) {
            addCriterion("D_id not in", values, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdBetween(Integer value1, Integer value2) {
            addCriterion("D_id between", value1, value2, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdNotBetween(Integer value1, Integer value2) {
            addCriterion("D_id not between", value1, value2, "dId");
            return (Criteria) this;
        }

        public Criteria andPIdIsNull() {
            addCriterion("P_id is null");
            return (Criteria) this;
        }

        public Criteria andPIdIsNotNull() {
            addCriterion("P_id is not null");
            return (Criteria) this;
        }

        public Criteria andPIdEqualTo(Integer value) {
            addCriterion("P_id =", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdNotEqualTo(Integer value) {
            addCriterion("P_id <>", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdGreaterThan(Integer value) {
            addCriterion("P_id >", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("P_id >=", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdLessThan(Integer value) {
            addCriterion("P_id <", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdLessThanOrEqualTo(Integer value) {
            addCriterion("P_id <=", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdIn(List<Integer> values) {
            addCriterion("P_id in", values, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdNotIn(List<Integer> values) {
            addCriterion("P_id not in", values, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdBetween(Integer value1, Integer value2) {
            addCriterion("P_id between", value1, value2, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdNotBetween(Integer value1, Integer value2) {
            addCriterion("P_id not between", value1, value2, "pId");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesIsNull() {
            addCriterion("\"S_money wages\" is null");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesIsNotNull() {
            addCriterion("\"S_money wages\" is not null");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesEqualTo(Double value) {
            addCriterion("\"S_money wages\" =", value, "sMoneyWages");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesNotEqualTo(Double value) {
            addCriterion("\"S_money wages\" <>", value, "sMoneyWages");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesGreaterThan(Double value) {
            addCriterion("\"S_money wages\" >", value, "sMoneyWages");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesGreaterThanOrEqualTo(Double value) {
            addCriterion("\"S_money wages\" >=", value, "sMoneyWages");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesLessThan(Double value) {
            addCriterion("\"S_money wages\" <", value, "sMoneyWages");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesLessThanOrEqualTo(Double value) {
            addCriterion("\"S_money wages\" <=", value, "sMoneyWages");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesIn(List<Double> values) {
            addCriterion("\"S_money wages\" in", values, "sMoneyWages");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesNotIn(List<Double> values) {
            addCriterion("\"S_money wages\" not in", values, "sMoneyWages");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesBetween(Double value1, Double value2) {
            addCriterion("\"S_money wages\" between", value1, value2, "sMoneyWages");
            return (Criteria) this;
        }

        public Criteria andSMoneyWagesNotBetween(Double value1, Double value2) {
            addCriterion("\"S_money wages\" not between", value1, value2, "sMoneyWages");
            return (Criteria) this;
        }

        public Criteria andSBirthdayIsNull() {
            addCriterion("S_birthday is null");
            return (Criteria) this;
        }

        public Criteria andSBirthdayIsNotNull() {
            addCriterion("S_birthday is not null");
            return (Criteria) this;
        }

        public Criteria andSBirthdayEqualTo(Date value) {
            addCriterionForJDBCDate("S_birthday =", value, "sBirthday");
            return (Criteria) this;
        }

        public Criteria andSBirthdayNotEqualTo(Date value) {
            addCriterionForJDBCDate("S_birthday <>", value, "sBirthday");
            return (Criteria) this;
        }

        public Criteria andSBirthdayGreaterThan(Date value) {
            addCriterionForJDBCDate("S_birthday >", value, "sBirthday");
            return (Criteria) this;
        }

        public Criteria andSBirthdayGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("S_birthday >=", value, "sBirthday");
            return (Criteria) this;
        }

        public Criteria andSBirthdayLessThan(Date value) {
            addCriterionForJDBCDate("S_birthday <", value, "sBirthday");
            return (Criteria) this;
        }

        public Criteria andSBirthdayLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("S_birthday <=", value, "sBirthday");
            return (Criteria) this;
        }

        public Criteria andSBirthdayIn(List<Date> values) {
            addCriterionForJDBCDate("S_birthday in", values, "sBirthday");
            return (Criteria) this;
        }

        public Criteria andSBirthdayNotIn(List<Date> values) {
            addCriterionForJDBCDate("S_birthday not in", values, "sBirthday");
            return (Criteria) this;
        }

        public Criteria andSBirthdayBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("S_birthday between", value1, value2, "sBirthday");
            return (Criteria) this;
        }

        public Criteria andSBirthdayNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("S_birthday not between", value1, value2, "sBirthday");
            return (Criteria) this;
        }

        public Criteria andSEntrydateIsNull() {
            addCriterion("S_Entrydate is null");
            return (Criteria) this;
        }

        public Criteria andSEntrydateIsNotNull() {
            addCriterion("S_Entrydate is not null");
            return (Criteria) this;
        }

        public Criteria andSEntrydateEqualTo(Date value) {
            addCriterionForJDBCDate("S_Entrydate =", value, "sEntrydate");
            return (Criteria) this;
        }

        public Criteria andSEntrydateNotEqualTo(Date value) {
            addCriterionForJDBCDate("S_Entrydate <>", value, "sEntrydate");
            return (Criteria) this;
        }

        public Criteria andSEntrydateGreaterThan(Date value) {
            addCriterionForJDBCDate("S_Entrydate >", value, "sEntrydate");
            return (Criteria) this;
        }

        public Criteria andSEntrydateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("S_Entrydate >=", value, "sEntrydate");
            return (Criteria) this;
        }

        public Criteria andSEntrydateLessThan(Date value) {
            addCriterionForJDBCDate("S_Entrydate <", value, "sEntrydate");
            return (Criteria) this;
        }

        public Criteria andSEntrydateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("S_Entrydate <=", value, "sEntrydate");
            return (Criteria) this;
        }

        public Criteria andSEntrydateIn(List<Date> values) {
            addCriterionForJDBCDate("S_Entrydate in", values, "sEntrydate");
            return (Criteria) this;
        }

        public Criteria andSEntrydateNotIn(List<Date> values) {
            addCriterionForJDBCDate("S_Entrydate not in", values, "sEntrydate");
            return (Criteria) this;
        }

        public Criteria andSEntrydateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("S_Entrydate between", value1, value2, "sEntrydate");
            return (Criteria) this;
        }

        public Criteria andSEntrydateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("S_Entrydate not between", value1, value2, "sEntrydate");
            return (Criteria) this;
        }

        public Criteria andSBecomedateIsNull() {
            addCriterion("S_becomedate is null");
            return (Criteria) this;
        }

        public Criteria andSBecomedateIsNotNull() {
            addCriterion("S_becomedate is not null");
            return (Criteria) this;
        }

        public Criteria andSBecomedateEqualTo(Date value) {
            addCriterionForJDBCDate("S_becomedate =", value, "sBecomedate");
            return (Criteria) this;
        }

        public Criteria andSBecomedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("S_becomedate <>", value, "sBecomedate");
            return (Criteria) this;
        }

        public Criteria andSBecomedateGreaterThan(Date value) {
            addCriterionForJDBCDate("S_becomedate >", value, "sBecomedate");
            return (Criteria) this;
        }

        public Criteria andSBecomedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("S_becomedate >=", value, "sBecomedate");
            return (Criteria) this;
        }

        public Criteria andSBecomedateLessThan(Date value) {
            addCriterionForJDBCDate("S_becomedate <", value, "sBecomedate");
            return (Criteria) this;
        }

        public Criteria andSBecomedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("S_becomedate <=", value, "sBecomedate");
            return (Criteria) this;
        }

        public Criteria andSBecomedateIn(List<Date> values) {
            addCriterionForJDBCDate("S_becomedate in", values, "sBecomedate");
            return (Criteria) this;
        }

        public Criteria andSBecomedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("S_becomedate not in", values, "sBecomedate");
            return (Criteria) this;
        }

        public Criteria andSBecomedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("S_becomedate between", value1, value2, "sBecomedate");
            return (Criteria) this;
        }

        public Criteria andSBecomedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("S_becomedate not between", value1, value2, "sBecomedate");
            return (Criteria) this;
        }

        public Criteria andSEmploymentIsNull() {
            addCriterion("S_employment is null");
            return (Criteria) this;
        }

        public Criteria andSEmploymentIsNotNull() {
            addCriterion("S_employment is not null");
            return (Criteria) this;
        }

        public Criteria andSEmploymentEqualTo(String value) {
            addCriterion("S_employment =", value, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentNotEqualTo(String value) {
            addCriterion("S_employment <>", value, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentGreaterThan(String value) {
            addCriterion("S_employment >", value, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentGreaterThanOrEqualTo(String value) {
            addCriterion("S_employment >=", value, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentLessThan(String value) {
            addCriterion("S_employment <", value, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentLessThanOrEqualTo(String value) {
            addCriterion("S_employment <=", value, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentLike(String value) {
            addCriterion("S_employment like", value, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentNotLike(String value) {
            addCriterion("S_employment not like", value, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentIn(List<String> values) {
            addCriterion("S_employment in", values, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentNotIn(List<String> values) {
            addCriterion("S_employment not in", values, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentBetween(String value1, String value2) {
            addCriterion("S_employment between", value1, value2, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSEmploymentNotBetween(String value1, String value2) {
            addCriterion("S_employment not between", value1, value2, "sEmployment");
            return (Criteria) this;
        }

        public Criteria andSStateIsNull() {
            addCriterion("S_state is null");
            return (Criteria) this;
        }

        public Criteria andSStateIsNotNull() {
            addCriterion("S_state is not null");
            return (Criteria) this;
        }

        public Criteria andSStateEqualTo(String value) {
            addCriterion("S_state =", value, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateNotEqualTo(String value) {
            addCriterion("S_state <>", value, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateGreaterThan(String value) {
            addCriterion("S_state >", value, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateGreaterThanOrEqualTo(String value) {
            addCriterion("S_state >=", value, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateLessThan(String value) {
            addCriterion("S_state <", value, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateLessThanOrEqualTo(String value) {
            addCriterion("S_state <=", value, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateLike(String value) {
            addCriterion("S_state like", value, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateNotLike(String value) {
            addCriterion("S_state not like", value, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateIn(List<String> values) {
            addCriterion("S_state in", values, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateNotIn(List<String> values) {
            addCriterion("S_state not in", values, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateBetween(String value1, String value2) {
            addCriterion("S_state between", value1, value2, "sState");
            return (Criteria) this;
        }

        public Criteria andSStateNotBetween(String value1, String value2) {
            addCriterion("S_state not between", value1, value2, "sState");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}