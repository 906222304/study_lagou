package cn.hp.bean;

public class affair {
    private Integer afId;

    private String afName;

    private String afContent;

    public Integer getAfId() {
        return afId;
    }

    public void setAfId(Integer afId) {
        this.afId = afId;
    }

    public String getAfName() {
        return afName;
    }

    public void setAfName(String afName) {
        this.afName = afName == null ? null : afName.trim();
    }

    public String getAfContent() {
        return afContent;
    }

    public void setAfContent(String afContent) {
        this.afContent = afContent == null ? null : afContent.trim();
    }



	public affair(String afName, String afContent) {
		super();
		this.afName = afName;
		this.afContent = afContent;
	}

	/**
	 * 
	 */
	public affair() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param afId
	 * @param afName
	 * @param afContent
	 */
	public affair(Integer afId, String afName, String afContent) {
		super();
		this.afId = afId;
		this.afName = afName;
		this.afContent = afContent;
	}
    
	
}