package cn.hp.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.hp.bean.Msg;
import cn.hp.bean.affair;
import cn.hp.bean.staff;
import cn.hp.service.AffairService;

@Controller
@RequestMapping("/affair")
public class AffairController {
	
	@Autowired
	private AffairService affairService;
	
	//返回员工集合页面
	@RequestMapping("/affairFanKuiView")
	public String getStaffView() {
		
		return "affair_Fk";
	}
	
	//返回反馈集合查询页面
	@RequestMapping("/affairFkSelectView")
	public String affairFkSelectView() {
		
		return "affairFk_Select";
	}
	
	//查询并返回所有反馈列表集合
	@RequestMapping("/affairFkList")
	@ResponseBody
	public Map<String, Object> getaffairFkList(Integer page, Integer limit) {
		//Integer page, Integer limit
		System.out.println(page+"--"+limit);
		PageHelper.startPage(Integer.valueOf(page), Integer.valueOf(limit));
		List<affair> list=affairService.queryAll();
		System.out.println(list.size());
	    Map<String, Object> resultMap = new HashMap<String, Object>();
	    PageInfo<affair> pageInfo = new PageInfo<affair>(list);
		  //总条数
		  resultMap.put("count",pageInfo.getTotal());
		  //获取每页数据
		  resultMap.put("data", pageInfo.getList());
		  
		  System.out.println(pageInfo.getTotal());
		  resultMap.put("msg", "");
		  resultMap.put("code", 0);
		
		return resultMap;
	}
	
	//修改反馈信息
	@RequestMapping("/affairFanKui")
	@ResponseBody
	public Msg saffairFanKui(@RequestBody affair af ) {
		//Integer sId,String sName,String sSex,String sRofs,String sAddress,String sMarriage,String sMajor,String sNative,String sPolitical,String sMinority,String sPhone,Integer dId,Integer pId,Double sMoneyWages,Date sBirthday,Date sEntrydate,Date sBecomedate,String sEmployment,String sState
//		staff staff = new staff(sId, sName, sSex, sRofs, sAddress, sMarriage, sMajor, sNative, sPolitical, sMinority, sPhone, dId, pId, sMoneyWages, sBirthday, sEntrydate, sBecomedate, sEmployment, sState);
		System.out.println("反馈"+af.getAfContent());
		if(affairService.affairFk(af)) {
			
			return new Msg().success();
		}
		
		return new Msg().fail();
	}
	
	//根据afID删除反馈
	@RequestMapping("/affairDel")
	@ResponseBody
	public Msg affairDel(int afId) {
		System.out.println("删除反馈："+afId);
		if(affairService.deleteAffair(afId)) {
			
			return new Msg().success();
		}
		
		return new Msg().fail();
	}
	
	//根据id查询反馈记录affairQueryone
	//返回根据id查询的员工详情页面
	@RequestMapping("/affairQueryone")
	public String affairQueryone(int afId,HttpServletRequest request) {
		System.out.println("反馈ID"+afId);
		affair a =affairService.selectOne(afId);
//		System.out.println(s.toString());
		request.getSession().setAttribute("affair", a);
		
		return "affair_Queryono";
	}
}
