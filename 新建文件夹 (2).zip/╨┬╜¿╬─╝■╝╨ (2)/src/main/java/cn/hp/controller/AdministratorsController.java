package cn.hp.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.hp.bean.Msg;
import cn.hp.bean.administrators;
import cn.hp.bean.staff;
import cn.hp.service.AdministratorsService;

@Controller
@RequestMapping("/admin")
public class AdministratorsController {
	
	@Autowired
	private AdministratorsService administratorsService;
	
	//管理员登录
	@ResponseBody
	@RequestMapping("/login")
	public Msg admin_login(String username,String userpassword,int Permissions,HttpServletRequest request) {
		System.out.println(username+"--"+userpassword);
		
		if(administratorsService.queryUserAndPasswordAndPermissions(username,userpassword,Permissions)) {
			request.getSession().setAttribute("user", new administrators(username, userpassword,Permissions));
		
			return new Msg().success();
		}
		
		return new Msg().fail();
	}
	//登录成功
	@RequestMapping("admin_loginsucc")
	public String admin_loginsucc() {
	
		return "admin_index";
	}
	
	//退出登录
	@RequestMapping("logout")
	public String admin_logout(HttpServletRequest request) {
		
		request.getSession().invalidate();
		System.out.println("注销。");
		return "redirect:/index.jsp";
	}
	
	//人事登录
	@RequestMapping("user_loginsucc")
	public String user_loginsucc() {
	
		return "user_index";
	}
	
	//返回管理员集合页面
	@RequestMapping("/getAdminListView")
	public String getAdminListView() {
		
		return "admin_list";
	}
	//返回管理员添加页码
	//返回管理员集合页面
	
	@RequestMapping("/adminInfoAddView")
	public String getadminInfoAddView() {
		
		return "admin_add";
	}
	
	//查询并返回所有管理员集合
		@RequestMapping("/adminList")
		@ResponseBody
		public Map<String, Object> getadminList(Integer page, Integer limit) {
			//Integer page, Integer limit
			System.out.println(page+"--"+limit);
			PageHelper.startPage(Integer.valueOf(page), Integer.valueOf(limit));
			List<administrators> list=administratorsService.queryAll();
			System.out.println(list.size());
		    Map<String, Object> resultMap = new HashMap<String, Object>();
		    PageInfo<administrators> pageInfo = new PageInfo<administrators>(list);
			  //总条数
			  resultMap.put("count",pageInfo.getTotal());
			  //获取每页数据
			  resultMap.put("data", pageInfo.getList());
			  pageInfo.getPageNum();
			  
			  System.out.println(pageInfo.getTotal());
			  resultMap.put("msg", "");
			  resultMap.put("code", 0);
			
			return resultMap;
		}
		
		//删除管理员
		@RequestMapping("/delAdminInfo")
		@ResponseBody
		public Msg delAdminInfo(int aid) {
			System.out.println("删除"+aid);
			if(administratorsService.deleteAdminInfo(aid)) {
				
				return new Msg().success();
			}
			
			return new Msg().fail();
		}
		
		//添加管理员
		@RequestMapping("/addAdmin")
		@ResponseBody
		public Msg addAdmin(@RequestBody administrators admin) {
			System.out.println("添加"+admin.getaUsername());
			if(administratorsService.addAdmin(admin)) {
				
				return new Msg().success();
			}
			
			return new Msg().fail();
		}
		
		//根据用户名查询
				@RequestMapping("/queryOneAdmin")
				@ResponseBody
				public Map<String, Object> queryOneAdmin(String ausername,Integer page, Integer limit) {
					//Integer page, Integer limit
					System.out.println(page+"--"+limit);
					PageHelper.startPage(Integer.valueOf(page), Integer.valueOf(limit));
					List<administrators> list=administratorsService.queryOneAdmin(ausername);
					System.out.println(list.size());
				    Map<String, Object> resultMap = new HashMap<String, Object>();
				    PageInfo<administrators> pageInfo = new PageInfo<administrators>(list);
					  //总条数
					  resultMap.put("count",pageInfo.getTotal());
					  //获取每页数据
					  resultMap.put("data", pageInfo.getList());
					  pageInfo.getPageNum();
					  
					  System.out.println(pageInfo.getTotal());
					  resultMap.put("msg", "");
					  resultMap.put("code", 0);
					
					return resultMap;
				}
				
				//修改员工信息页面
				@RequestMapping("/adminInfoUpdateView")
				public String getadminInfoUpdateView(int aid,HttpServletRequest request) {
					System.out.println("修改ID"+aid);
					administrators ad =administratorsService.selectOne(aid);
					
					request.getSession().setAttribute("admin", ad);
					
					return "admin_Update";
				}
				
				//修改管理员信息
				@RequestMapping("/adminInfoUpdate")
				@ResponseBody
				public Msg adminInfoUpdate(@RequestBody administrators admin) {
					//Integer sId,String sName,String sSex,String sRofs,String sAddress,String sMarriage,String sMajor,String sNative,String sPolitical,String sMinority,String sPhone,Integer dId,Integer pId,Double sMoneyWages,Date sBirthday,Date sEntrydate,Date sBecomedate,String sEmployment,String sState
//					staff staff = new staff(sId, sName, sSex, sRofs, sAddress, sMarriage, sMajor, sNative, sPolitical, sMinority, sPhone, dId, pId, sMoneyWages, sBirthday, sEntrydate, sBecomedate, sEmployment, sState);
					System.out.println("修改"+admin.getaUsername());
					if(administratorsService.UpdateAdminInfo(admin)) {
						
						return new Msg().success();
					}
					
					return new Msg().fail();
				}
				
}
