package cn.hp.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.hp.bean.Msg;
import cn.hp.bean.administrators;
import cn.hp.bean.department;
import cn.hp.bean.position;
import cn.hp.bean.staff;
import cn.hp.service.StaffService;
import cn.hp.service.departmentService;
import cn.hp.service.positionService;


@Controller
@RequestMapping("/staff")
public class StaffController {

	@Autowired
	private StaffService staffService;
	@Autowired
	private departmentService depservice; 
	@Autowired
	private positionService positionservice; 
	//返回员工集合页面
	@RequestMapping("/staffView")
	public String getStaffView() {
		
		return "staff_list";
	}
	//添加员工页面
	@RequestMapping("/staffAddView")
	public String getStaffAddView(HttpServletRequest request) {
		
		List<position> pls=positionservice.queryAll();
		
		List<department> dls=depservice.queryAll();
		
		request.getSession().setAttribute("pls", pls);
		request.getSession().setAttribute("dls", dls);
		
		return "staff_add";
	}
	
	//返回根据id查询的员工详情页面
	@RequestMapping("/staffInfoView")
	public String getStaffInfoView(int sid,HttpServletRequest request) {
		System.out.println("详情ID"+sid);
		staff s =staffService.selectOne(sid);
//		System.out.println(s.toString());
		request.getSession().setAttribute("staff", s);
		
		return "staffinfo";
	}
	//修改员工信息页面
	@RequestMapping("/staffInfoUpdateView")
	public String getStaffInfoUpdateView(int sid,HttpServletRequest request) {
		System.out.println("修改ID"+sid);
		staff s =staffService.selectOne(sid);
		System.out.println(s.toString());
		request.getSession().setAttribute("staff", s);
		
		return "staffUpdate";
	}
	//查询并返回所有员工集合
	@RequestMapping("/staffList")
	@ResponseBody
	public Map<String, Object> getStaffList(Integer page, Integer limit) {
		//Integer page, Integer limit
		System.out.println(page+"--"+limit);
		PageHelper.startPage(Integer.valueOf(page), Integer.valueOf(limit));
		List<staff> list=staffService.queryAll();
		System.out.println(list.size());
	    Map<String, Object> resultMap = new HashMap<String, Object>();
	    PageInfo<staff> pageInfo = new PageInfo<staff>(list);
		  //总条数
		  resultMap.put("count",pageInfo.getTotal());
		  //获取每页数据
		  resultMap.put("data", pageInfo.getList());
		  pageInfo.getPageNum();
		  
		  System.out.println(pageInfo.getTotal());
		  resultMap.put("msg", "");
		  resultMap.put("code", 0);
		
		return resultMap;
	}
	
	//删除员工
	@RequestMapping("/delStaff")
	@ResponseBody
	public Msg deleteSatff(int sid) {
		System.out.println("删除"+sid);
		if(staffService.deleteStaff(sid)) {
			
			return new Msg().success();
		}
		
		return new Msg().fail();
	}
	//添加员工
	@RequestMapping("/addStaff")
	@ResponseBody
	public Msg addSatff(@RequestBody staff s) {
		System.out.println("添加"+s.toString());
		if(staffService.addStaff(s)) {
			
			return new Msg().success();
		}
		
		return new Msg().fail();
	}
	
	//根据用户名查询
			@RequestMapping("/queryOnestaff")
			@ResponseBody
			public Map<String, Object> queryOnestaff(String sname,Integer page, Integer limit) {
				//Integer page, Integer limit
				System.out.println(page+"--"+limit);
				PageHelper.startPage(Integer.valueOf(page), Integer.valueOf(limit));
				List<staff> list=staffService.queryOnestaff(sname);
				System.out.println(list.size());
			    Map<String, Object> resultMap = new HashMap<String, Object>();
			    PageInfo<staff> pageInfo = new PageInfo<staff>(list);
				  //总条数
				  resultMap.put("count",pageInfo.getTotal());
				  //获取每页数据
				  resultMap.put("data", pageInfo.getList());
				  pageInfo.getPageNum();
				  
				  System.out.println(pageInfo.getTotal());
				  resultMap.put("msg", "");
				  resultMap.put("code", 0);
				
				return resultMap;
			}
			//修改员工信息
			@RequestMapping("/staffInfoUpdate")
			@ResponseBody
			public Msg staffInfoUpdate(@RequestBody staff staff) {
				System.out.println("修改"+staff.toString());
				if(staffService.UpdateStaff(staff)) {
					
					return new Msg().success();
				}
				
				return new Msg().fail();
			}
			
}
