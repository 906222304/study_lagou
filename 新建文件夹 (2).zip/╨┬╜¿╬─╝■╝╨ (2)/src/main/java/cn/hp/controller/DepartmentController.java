package cn.hp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.hp.bean.Msg;
import cn.hp.bean.department;
import cn.hp.bean.staff;
import cn.hp.service.departmentService;

@Controller
@RequestMapping("/Depart")
public class DepartmentController {

	@Autowired
	private departmentService depservice; 
	//返回员工集合页面
	@RequestMapping("/DepartListView")
	public String getDepartListView() {
		
		return "Depart_List";
	}
	
	//返回部门添加页面
	@RequestMapping("/DepartAddView")
	public String DeparAddView() {
		
		return "Depart_Add";
	}
	
	//添加部门
	@RequestMapping("/addDepart")
	@ResponseBody
	public Msg addDepart(@RequestBody department dep) {
		System.out.println("添加部门"+dep.getdName());
		if(depservice.addDepart(dep)) {
			
			return new Msg().success();
		}
		
		return new Msg().fail();
	}
	
	//查询并返回所有部门集合
	@RequestMapping("/DepartList")
	@ResponseBody
	public Map<String, Object> getDepartList(Integer page, Integer limit) {
		//Integer page, Integer limit
		System.out.println(page+"--"+limit);
		PageHelper.startPage(Integer.valueOf(page), Integer.valueOf(limit));
		List<department> list=depservice.queryAll();
		System.out.println(list.size());
	    Map<String, Object> resultMap = new HashMap<String, Object>();
	    PageInfo<department> pageInfo = new PageInfo<department>(list);
		  //总条数
		  resultMap.put("count",pageInfo.getTotal());
		  //获取每页数据
		  resultMap.put("data", pageInfo.getList());
		  pageInfo.getPageNum();
		  
		  System.out.println(pageInfo.getTotal());
		  resultMap.put("msg", "");
		  resultMap.put("code", 0);
		
		return resultMap;
	}
	
	//删除部门
	@RequestMapping("/delDepart")
	@ResponseBody
	public Msg delDepart(int did) {
		System.out.println("删除部门"+did);
		if(depservice.deleteDepart(did)) {
			
			return new Msg().success();
		}
		
		return new Msg().fail();
	}
	
	//修改员工信息页面
	@RequestMapping("/DepartInfoUpdateView")
	public String getDepartInfoUpdateView(int did,HttpServletRequest request) {
		System.out.println("修改部门ID"+did);
		department d =depservice.selectOne(did);
		System.out.println(d.getdName());
		request.getSession().setAttribute("department", d);
		
		return "DepartInfoUpdate";
	}
	//修改部门信息
	@RequestMapping("/DepartInfoUpdate")
	@ResponseBody
	public Msg depaertInfoUpdate(@RequestBody department d) {
		//Integer sId,String sName,String sSex,String sRofs,String sAddress,String sMarriage,String sMajor,String sNative,String sPolitical,String sMinority,String sPhone,Integer dId,Integer pId,Double sMoneyWages,Date sBirthday,Date sEntrydate,Date sBecomedate,String sEmployment,String sState
//		staff staff = new staff(sId, sName, sSex, sRofs, sAddress, sMarriage, sMajor, sNative, sPolitical, sMinority, sPhone, dId, pId, sMoneyWages, sBirthday, sEntrydate, sBecomedate, sEmployment, sState);
		System.out.println("修改"+d.getdName());
		if(depservice.UpdateDepart(d)) {
			
			return new Msg().success();
		}
		
		return new Msg().fail();
	}
	
	//根据部门名查询
	@RequestMapping("/queryOnDepart")
	@ResponseBody
	public Map<String, Object> queryOnDepart(String dname,Integer page, Integer limit) {
		//Integer page, Integer limit
		System.out.println(page+"--"+limit);
		PageHelper.startPage(Integer.valueOf(page), Integer.valueOf(limit));
		List<department> list=depservice.queryOnDepart(dname);
		System.out.println(list.size());
	    Map<String, Object> resultMap = new HashMap<String, Object>();
	    PageInfo<department> pageInfo = new PageInfo<department>(list);
		  //总条数
		  resultMap.put("count",pageInfo.getTotal());
		  //获取每页数据
		  resultMap.put("data", pageInfo.getList());
		  
		  System.out.println(pageInfo.getTotal());
		  resultMap.put("msg", "");
		  resultMap.put("code", 0);
		
		return resultMap;
	}
	
}
