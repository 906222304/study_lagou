package cn.hp.dao;

import cn.hp.bean.staff;
import cn.hp.bean.staffExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface staffMapper {
    long countByExample(staffExample example);

    int deleteByExample(staffExample example);

    int deleteByPrimaryKey(Integer sId);

    int insert(staff record);

    int insertSelective(staff record);

    List<staff> selectByExample(staffExample example);
    
    List<staff> selectAll();
    
    staff queryOnestaff(String sname);
    
    staff selectBySid(Integer sid);

    staff selectByPrimaryKey(Integer sId);

    int updateByExampleSelective(@Param("record") staff record, @Param("example") staffExample example);

    int updateByExample(@Param("record") staff record, @Param("example") staffExample example);

    int updateByPrimaryKeySelective(staff record);

    int updateByPrimaryKey(staff record);
}