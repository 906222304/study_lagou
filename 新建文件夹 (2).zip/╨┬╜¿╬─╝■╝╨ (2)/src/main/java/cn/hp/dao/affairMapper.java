package cn.hp.dao;

import cn.hp.bean.affair;
import cn.hp.bean.affairExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface affairMapper {
    long countByExample(affairExample example);

    int deleteByExample(affairExample example);

    int deleteByPrimaryKey(Integer afId);

    int insert(affair record);

    int insertSelective(affair record);

    List<affair> selectByExample(affairExample example);

    affair selectByPrimaryKey(Integer afId);

    int updateByExampleSelective(@Param("record") affair record, @Param("example") affairExample example);

    int updateByExample(@Param("record") affair record, @Param("example") affairExample example);

    int updateByPrimaryKeySelective(affair record);

    int updateByPrimaryKey(affair record);
}