package cn.hp.dao;

import cn.hp.bean.position;
import cn.hp.bean.positionExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface positionMapper {
    long countByExample(positionExample example);

    int deleteByExample(positionExample example);

    int deleteByPrimaryKey(Integer pId);

    int insert(position record);

    int insertSelective(position record);

    List<position> selectByExample(positionExample example);

    position selectByPrimaryKey(Integer pId);

    int updateByExampleSelective(@Param("record") position record, @Param("example") positionExample example);

    int updateByExample(@Param("record") position record, @Param("example") positionExample example);

    int updateByPrimaryKeySelective(position record);

    int updateByPrimaryKey(position record);
}