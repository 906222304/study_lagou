package cn.hp.dao;

import cn.hp.bean.administrators;
import cn.hp.bean.administratorsExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface administratorsMapper {
    long countByExample(administratorsExample example);

    int deleteByExample(administratorsExample example);

    int deleteByPrimaryKey(Integer aId);

    int insert(administrators record);

    int insertSelective(administrators record);

    List<administrators> selectByExample(administratorsExample example);

    administrators selectByPrimaryKey(Integer aId);

    int updateByExampleSelective(@Param("record") administrators record, @Param("example") administratorsExample example);

    int updateByExample(@Param("record") administrators record, @Param("example") administratorsExample example);

    int updateByPrimaryKeySelective(administrators record);

    int updateByPrimaryKey(administrators record);
}