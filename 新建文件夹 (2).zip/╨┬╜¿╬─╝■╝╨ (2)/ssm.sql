-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: localhost    Database: ssm
-- ------------------------------------------------------
-- Server version	5.6.25-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrators`
--

DROP TABLE IF EXISTS `administrators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administrators` (
  `A_id` int(20) NOT NULL AUTO_INCREMENT COMMENT '管理员id',
  `A_username` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '管理员用户名',
  `A_password` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '管理员密码',
  `A_Permissions` int(11) NOT NULL COMMENT '权限',
  PRIMARY KEY (`A_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrators`
--

LOCK TABLES `administrators` WRITE;
/*!40000 ALTER TABLE `administrators` DISABLE KEYS */;
INSERT INTO `administrators` VALUES (1,'admin','123456',1),(2,'admin123','123456',2),(3,'admin1234','1234567',2),(4,'admin12345','1234567',2),(6,'22222','2222',2),(7,'333333','44444',2),(8,'222222385','52454',1),(9,'88','8888',3),(12,'ywb','123456',1);
/*!40000 ALTER TABLE `administrators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `affair`
--

DROP TABLE IF EXISTS `affair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `affair` (
  `AF_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '事务ID',
  `AF_name` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '事务类型',
  `AF_content` varchar(300) COLLATE utf8_bin NOT NULL COMMENT '事务内容',
  PRIMARY KEY (`AF_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `affair`
--

LOCK TABLES `affair` WRITE;
/*!40000 ALTER TABLE `affair` DISABLE KEYS */;
INSERT INTO `affair` VALUES (3,'有bug','插入数据有bug'),(4,'删除数据有bug','老板 删除数据有bug'),(5,'好多bug呀','全是bug'),(6,'有人抽烟','室内抽烟'),(8,'上班玩游戏','有人上班玩游戏'),(9,'啦啦啦啦啦','哈哈哈哈哈哈哈'),(10,'这是一条测试反馈','你好呀，我是bug'),(12,'什么时候加工资','加工资不存在的'),(13,'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx','z');
/*!40000 ALTER TABLE `affair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `D_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '部门编号',
  `D_name` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '部门名称',
  PRIMARY KEY (`D_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'财务部门'),(2,'人事部门'),(3,'开发部门'),(4,'运营部'),(5,'产品设计部'),(6,'销售部'),(7,'后勤部'),(8,'安保部'),(9,'UI美化部'),(10,'研发部'),(11,'摸鱼部'),(12,'信息部'),(16,'信息部'),(17,'信息部');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `position`
--

DROP TABLE IF EXISTS `position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `position` (
  `P_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '职位编号',
  `P_name` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '职位名称',
  `D_id` int(11) NOT NULL COMMENT '职位所属部门名称',
  PRIMARY KEY (`P_id`) USING BTREE,
  KEY `D_P` (`D_id`) USING BTREE,
  CONSTRAINT `D_P` FOREIGN KEY (`D_id`) REFERENCES `department` (`D_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `position`
--

LOCK TABLES `position` WRITE;
/*!40000 ALTER TABLE `position` DISABLE KEYS */;
INSERT INTO `position` VALUES (1,'人事主管',2),(2,'管理员',1);
/*!40000 ALTER TABLE `position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `S_id` int(20) NOT NULL AUTO_INCREMENT COMMENT '员工编号',
  `S_name` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '员工姓名',
  `S_sex` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '员工性别',
  `S_rofs` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '员工学历',
  `S_address` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '员工联系地址',
  `S_Marriage` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '员工婚姻状况',
  `S_major` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '员工专业',
  `S_Native` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '员工籍贯',
  `S_Political` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '员工政治面貌',
  `S_minority` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '员工名族',
  `S_phone` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '员工电话',
  `D_id` int(11) NOT NULL COMMENT '部门id',
  `P_id` int(11) NOT NULL COMMENT '职位id',
  `S_money_wages` decimal(10,2) NOT NULL COMMENT '员工基本工资',
  `S_birthday` date NOT NULL COMMENT '员工出生日期',
  `S_Entrydate` date NOT NULL COMMENT '员工入职日期',
  `S_becomedate` date NOT NULL COMMENT '员工转正日期',
  `S_employment` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '员工聘用形式',
  `S_state` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '员工在职状态',
  PRIMARY KEY (`S_id`) USING BTREE,
  KEY `S_D` (`D_id`) USING BTREE,
  KEY `S_P` (`P_id`) USING BTREE,
  CONSTRAINT `S_D` FOREIGN KEY (`D_id`) REFERENCES `department` (`D_id`),
  CONSTRAINT `S_P` FOREIGN KEY (`P_id`) REFERENCES `position` (`P_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'杨文博','男','大专','江苏南京','未婚','软件技术','江苏无锡','团员','汉','14751099521',11,1,8000.00,'2020-06-02','2020-06-02','2020-06-02','招聘','在职'),(2,'汤振','男','大专','江苏淮安','未婚','移动应用开发','江苏无锡','团员','汉','123456789',2,1,80000.00,'2020-06-05','2020-06-05','2020-06-05','招聘','在职'),(3,'宋小宝','男','大专','江苏南通','未婚','移动应用开发','江苏无锡','团员','汉','123456789',2,1,8000.00,'2019-07-28','2019-07-28','2019-07-28','招聘','在职'),(4,'陈跃飞','男','大专','江苏南通','未婚','嵌入式设计','江苏南京','团员','汉','123456789',2,1,8000.00,'2019-07-28','2019-07-28','2019-07-28','招聘','在职'),(5,'刘宏鑫','男','大专','四川南充','未婚','软件技术','江苏镇江','团员','汉','123456789',2,1,8000.00,'2019-10-29','2019-10-29','2019-10-29','招聘','在职'),(6,'张三','男','大专','新疆乌鲁木齐','未婚','云计算','江苏南京','团员','维吾尔','123456789',2,1,8000.00,'2019-07-28','2019-07-28','2019-07-28','招聘','在职'),(7,'李四','男','大专','江苏南京','未婚','财务管理','广西桂林','党员','壮','123456789',2,1,8000.00,'2000-06-03','2018-01-01','2018-04-01','招聘','在职'),(8,'王大锤','男','大专','江苏南京','未婚','移动应用开发','江苏南京','团员','汉','123456789',2,1,8000.00,'2019-07-28','2019-07-17','2019-07-24','招聘','在职'),(9,'许嵩','男','大专','江苏南京','未婚','移动应用开发','江苏南京','团员','汉','123456789',2,1,8000.00,'2019-07-28','2019-07-28','2019-07-28','招聘','在职'),(10,'张杰','男','大专','江苏南京','未婚','移动应用开发','江苏南京','团员','汉','123456789',2,1,8000.00,'2000-06-03','2018-01-01','2018-04-01','招聘','在职'),(14,'王美丽','女','本科','江苏南京','不详','移动应用开发','江苏南京','团员','汉','15877777711',1,1,8000.00,'2019-07-28','2019-07-28','2019-07-28','招聘','在职'),(16,'王阿韦','女','初中','江苏南京','未婚','软件技术','汉','群众','汉','12345678910',9,2,100.00,'2020-01-08','2020-05-28','2020-06-02','招聘','在职');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-06 16:21:36
