import com.lagou.edu.LagouBean;
import com.lagou.edu.ano.UserController;
import com.lagou.edu.aop.AopBean;
import com.lagou.edu.aop.AopBeanInf;
import com.lagou.edu.listener.Order;
import com.lagou.edu.listener.OrderEvent;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @Author 应癫
 */
public class IocTest {

	/**
	 * Ioc 容器源码分析基础案例
	 */
	@Test
	public void testIoC() {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
		LagouBean lagouBean = applicationContext.getBean(LagouBean.class);
		System.out.println(lagouBean.getItBean());
	}


	/**
	 * AOP源码测试
	 */
	@Test
	public void testAOP() {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath*:applicationContext-aop.xml");
		AopBeanInf aopBean = applicationContext.getBean(AopBeanInf.class);
		aopBean.testAop();
	}


	/**
	 * Ioc 循环依赖
	 */
	@Test
	public void testCyclicdependence() {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:applicationContext-cyclicdependence.xml");
		com.lagou.edu.cyclicdependence.LagouBean lagouBean =
				applicationContext.getBean(com.lagou.edu.cyclicdependence.LagouBean.class);
		lagouBean.print();
	}

	/**
	 * 事件发布
	 */
	@Test
	public void testAno() {
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext("com.lagou.edu.listener");
		/**
		 * 使用场景: 比如有一个订单, 由用户下单了,那么对应的就要减库存.其实下单和减库存不需要是串行.
		 * 通常, 我们会使用一个mq去处理减库存的情况. 也就是采用异步的方式.
		 *
		 * 那么, 监听器的远离和mq是类似的. 我们可以手动设置采用同步还是异步的方式处理.
		 */
		Order order = new Order();
		order.setId(1);
		System.out.println("下单");

		// 发布事件. 当在这里发布事件, 那么就会被事件监听器监听到
		applicationContext.publishEvent(new OrderEvent(order, "减库存"));
		System.out.println("日志.....");
	}
}
