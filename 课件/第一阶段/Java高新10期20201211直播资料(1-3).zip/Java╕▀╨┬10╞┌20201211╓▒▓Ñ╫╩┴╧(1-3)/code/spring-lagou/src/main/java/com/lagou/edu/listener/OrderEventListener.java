package com.lagou.edu.listener;

import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * Description
 * OrderEvent的事件监听器
 */
@Component
public class OrderEventListener implements ApplicationListener<OrderEvent> {
	/**
	 * 当某一个事件发布的时候, 就会触发事件监听器
	 */
	@Override
	public void onApplicationEvent(OrderEvent event) {
		if (event.getName().equals("减库存")) {
			System.out.println("事件监听器  监听到  减库存");
		}
	}
}