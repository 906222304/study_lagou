package com.lagou.edu.ano;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;


@Controller
public class UserController {
	@Autowired
			@Qualifier("userServiceImpl2")
	UserService userService;

	public void save() {
		System.out.println("11");
		userService.save();
	}
}
