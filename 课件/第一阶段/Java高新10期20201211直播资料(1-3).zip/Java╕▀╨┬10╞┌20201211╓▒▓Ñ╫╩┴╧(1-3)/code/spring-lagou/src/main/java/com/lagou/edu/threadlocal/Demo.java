package com.lagou.edu.threadlocal;

public class Demo {
	public static ThreadLocal<String> t = new ThreadLocal<String>();

	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getId());
		new Thread(new Runnable() {
			@Override
			public void run() {
				if (t.get() == null) {
					t.set("存放的值" + Thread.currentThread().getName());
				}
				System.out.println("线程1:"+t.get());
				System.out.println(Thread.currentThread().getId());
			}
		}, "thread1").start();

		new Thread(new Runnable() {
			@Override
			public void run() {
				/*if (t.get() == null) {
					t.set("存放的值" + Thread.currentThread().getName());
				}*/
				System.out.println("线程2:"+t.get());
				System.out.println(Thread.currentThread().getId());
			}
		}, "thread2").start();
	}
}
