package com.lagou.edu.aop;

import com.lagou.edu.ItBean;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;

/**
 * @Author 朝阳
 */
public interface AopBeanInf {

	public void testAop();
}

