package com.lagou.edu.ano;

public interface UserService {
	public void save();
}
