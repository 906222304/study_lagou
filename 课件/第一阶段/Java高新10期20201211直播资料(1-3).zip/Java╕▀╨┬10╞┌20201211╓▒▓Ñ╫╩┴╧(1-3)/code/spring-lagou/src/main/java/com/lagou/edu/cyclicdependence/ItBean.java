package com.lagou.edu.cyclicdependence;


/**
 * @author 朝阳
 */
public class ItBean {

	private LagouBean lagouBean;

	public void setLagouBean(LagouBean lagouBean) {
		this.lagouBean = lagouBean;
	}

	/**
	 * 构造函数
	 */
	public ItBean() {
		System.out.println("ItBean 构造器...");
	}

	/**
	 * 构造函数
	 */
	public ItBean(LagouBean lagouBean) {
		this.lagouBean = lagouBean;
	}
}
