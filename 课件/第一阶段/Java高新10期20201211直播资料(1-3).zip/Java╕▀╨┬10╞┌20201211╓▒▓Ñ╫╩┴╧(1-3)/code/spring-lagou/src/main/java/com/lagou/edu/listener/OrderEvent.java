package com.lagou.edu.listener;

import org.springframework.context.ApplicationEvent;

import java.io.Serializable;

/**
 * 订单的事件
 */
public class OrderEvent extends ApplicationEvent implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;

	public OrderEvent(Object event, String name) {
		super(event);
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}