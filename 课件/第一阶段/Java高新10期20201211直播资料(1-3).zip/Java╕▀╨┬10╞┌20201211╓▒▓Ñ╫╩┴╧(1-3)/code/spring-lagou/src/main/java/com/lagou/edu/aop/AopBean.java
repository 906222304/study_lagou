package com.lagou.edu.aop;

import com.lagou.edu.ItBean;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * @Author 朝阳
 */
public class AopBean implements AopBeanInf {

	@Override
	public void testAop() {
		System.out.println("spring aop 测试");
	}
}
