package com.lagou.edu.lifecycle;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

/**
 * Bean后处理器
 */
public class MyBeanPostProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		if ("lagouCycleBean".equals(beanName)) {
			System.out.println("LagouCycleBean的Before前置处理方法执行");
		}
		return bean;
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		if ("lagouCycleBean".equals(beanName)) {
			System.out.println("LagouCycleBean的After后置处理方法执行");
		}
		return bean;
	}
}