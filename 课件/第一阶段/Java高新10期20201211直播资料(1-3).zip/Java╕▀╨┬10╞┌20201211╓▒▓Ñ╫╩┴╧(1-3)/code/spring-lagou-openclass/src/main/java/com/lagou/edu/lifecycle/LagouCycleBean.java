package com.lagou.edu.lifecycle;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.*;

/**
 * 生命周期Bean
 */
public class LagouCycleBean implements
		BeanNameAware,/*让Bean获取自己在BeanFactory配置中的名字（根据情况是id或者name）*/
		BeanFactoryAware,/*让Bean获取配置他们的BeanFactory的引用*/
		BeanClassLoaderAware,/*让Bean获取获取Bean的类装载器*/
		InitializingBean,/* 为Bean提供了自定义初始化方法的方式 */
		DisposableBean /* bean允许在容器销毁该bean的时候获得一次回调 */ {


	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("LagouCycleBean的属性注入方法执行了. name=" + name);
		this.name = name;
	}

	/**
	 * 构造函数
	 */
	public LagouCycleBean() {
		System.out.println("LagouCycleBean的构造器方法执行.");
	}

	/**
	 * 自定义初始化方法
	 */
	public void initMethod() {
		System.out.println("LagouCycleBean的自定义初始化方法执行了.");
	}

	/**
	 *
	 */
	public void destroyMethod() {
		System.out.println("LagouCycleBean的自定义销毁方法执行了.");
	}

	/**
	 * InitializingBean
	 */
	public void afterPropertiesSet() throws Exception {
		System.out.println("LagouCycleBean的InitializingBean的afterPropertiesSet方法执行了.");
	}

	public void print() {
		System.out.println("print方法业务逻辑执行");
	}

	/**
	 * BeanNameAware
	 */
	@Override
	public void setBeanName(String name) {
		System.out.println("LagouCycleBean的BeanNameAware:" + name);
	}

	/**
	 * BeanFactoryAware
	 */
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		System.out.println("LagouCycleBean的BeanFactoryAware:" + beanFactory);
	}

	/**
	 * BeanClassLoaderAware
	 */
	@Override
	public void setBeanClassLoader(ClassLoader classLoader) {
		System.out.println("LagouCycleBean的BeanClassLoader方法执行了." + classLoader);
	}

	/**
	 * DisposableBean
	 */
	@Override
	public void destroy() throws Exception {
		System.out.println("LagouCycleBean的DisposableBean的方法执行了.");
	}
}
