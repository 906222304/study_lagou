package com.lagou.edu.cyclicdependence;

public class LagouBean{

	private ItBean itBean;

	public ItBean getItBean() {
		return itBean;
	}

	public void setItBean(ItBean itBean) {
		this.itBean = itBean;
	}

	/**
	 * 构造函数
	 */
	public LagouBean() {
		System.out.println("LagouBean 构造器...");
	}

	/**
	 * 构造函数
	 */
	public LagouBean(ItBean itBean) {
		this.itBean = itBean;
	}



}
