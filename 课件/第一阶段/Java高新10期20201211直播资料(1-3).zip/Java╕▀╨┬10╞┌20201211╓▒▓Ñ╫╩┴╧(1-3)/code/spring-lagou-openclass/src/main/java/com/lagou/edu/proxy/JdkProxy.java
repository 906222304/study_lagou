package com.lagou.edu.proxy;

import com.lagou.edu.proxy.IRentingHouse;
import com.lagou.edu.proxy.ProxyFactory;
import com.lagou.edu.proxy.RentingHouseImpl;

/**
 * @author 朝阳
 */
public class JdkProxy {

	public static void main(String[] args) {

		IRentingHouse rentingHouse = new RentingHouseImpl();  // 委托对象---委托方

		// 从代理对象工厂获取代理对象
		IRentingHouse jdkProxy = (IRentingHouse) ProxyFactory.getInstance().getJdkProxy(rentingHouse);
		jdkProxy.rentHosue();
	}
}
