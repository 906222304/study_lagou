import com.lagou.edu.cyclicdependence.LagouBean;
import com.lagou.edu.lifecycle.LagouCycleBean;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @Author 朝阳
 */
public class IocTest {
	/**
	 * Bean的生命周期
	 */
	@Test
	public void testCycle() {
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
		LagouCycleBean lagouCycleBean = applicationContext.getBean(LagouCycleBean.class);
		lagouCycleBean.print();
		applicationContext.close();
	}

	/**
	 * 循环依赖
	 */
	@Test
	public void testCyclicDependence() {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
		LagouBean lagouBean = applicationContext.getBean(LagouBean.class);
		System.out.println(lagouBean.getItBean());
	}

}
