package com.lagou.edu.service;

import org.springframework.stereotype.Service;

@Service
public class DemoService {
	public void handle() {
		System.out.println("service:执行了....");
	}
}
