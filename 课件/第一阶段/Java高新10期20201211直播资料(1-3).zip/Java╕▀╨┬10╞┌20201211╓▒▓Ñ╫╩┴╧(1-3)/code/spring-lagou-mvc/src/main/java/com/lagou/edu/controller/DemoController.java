package com.lagou.edu.controller;

import com.lagou.edu.dao.ResumeDao;
import com.lagou.edu.domain.Resume;
import com.lagou.edu.domain.User;
import com.lagou.edu.service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.RequestEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.FlashMap;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author 应癫
 */
@Controller
@RequestMapping("/demo")
public class DemoController {

	@Autowired
	DemoService demoService;
	@RequestMapping("/handle01")
	public String handle01(String name, Map<String, Object> model) {
		int i = 10 / 0;
		demoService.handle();
		System.out.println("++++++++handler业务逻辑处理中....");
		Date date = new Date();
		model.put("date", date);
		return "success";
	}


	@RequestMapping("/handle02")
	@ResponseBody
	public User handle02(@RequestBody User user) {
		System.out.println("user:" + user);
		return user;
	}


	@Autowired
	ResumeDao resumeDao;

	@RequestMapping("/handle03")
	@ResponseBody
	public List<Resume> handle03() {
		List<Resume> all = resumeDao.findAll();
		return all;
	}
}
