package com.lagou.edu.controller.handler;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * ControllerAdvice作为Spring中默认的注解，提供对所有（你的项目包扫描范围内）Controller的异常捕获功能。
 */
@ControllerAdvice
public class DefaultExceptionHandler {

	@ExceptionHandler(value = Exception.class)
	@ResponseBody
	public String defaultErrorHandler(Exception e) {
		System.out.println("异常统一处理...");
		return e.getMessage();
	}
}
