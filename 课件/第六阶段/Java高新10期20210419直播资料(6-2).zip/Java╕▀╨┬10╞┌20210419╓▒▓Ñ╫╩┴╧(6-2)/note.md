

# 疑难解答



希望老师可以再讲一讲保持一致性那块的东西，尤其是那个HW和LEO的更新过程，和有可能出现数据不一致的情况，感谢老师啦





## Kafka架构：

![image-20210218153400769](note.assets/image-20210218153400769.png)



## 名词解释

AR、ISR、OSR如下：

![image-20210218152018749](note.assets/image-20210218152018749.png)



LEO如下：

![image-20210218152051411](note.assets/image-20210218152051411.png)



HW如下：

![image-20210218152107265](note.assets/image-20210218152107265.png)





总体：

![image-20210218152200010](note.assets/image-20210218152200010.png)



## Follower与Leader的同步：

1. Follower以消费者姿态消费Leader消息

   拉取 pull

   长轮询

   “炼狱”（replica.fetch.wait.max.ms=500）



新分区的Leader和Follower副本

![image-20210218152325018](note.assets/image-20210218152325018.png)



Leader接收到生产者的一条消息：

![image-20210218152331537](note.assets/image-20210218152331537.png)

Follower发送拉取消息请求，带着自己的HW，LEO值

![image-20210218152358247](note.assets/image-20210218152358247.png)

Leader发送响应，Follower更新自己的LEO

![image-20210218152412068](note.assets/image-20210218152412068.png)

Follower发起请求拉取数据，自己的参数：LEO=1 HW=0

![image-20210218152427168](note.assets/image-20210218152427168.png)



Leader将Remote-LEO更新为1，比较将HW设置为1，并响应Follower

![image-20210218152443533](note.assets/image-20210218152443533.png)

Leader收到第二条消息，更新自己的LEO=2

![image-20210218152455716](note.assets/image-20210218152455716.png)



![image-20210218152502624](note.assets/image-20210218152502624.png)



![image-20210218152509933](note.assets/image-20210218152509933.png)

![image-20210218152514233](note.assets/image-20210218152514233.png)





Follower需要两次请求，才能更新HW值

这种设计是有问题的，请问是什么问题？如何解决？

提示一下：假如在Follower同步HW之前Leader宕机，此时Leader和Follower拥有同样的消息，但是共有的HW没有赶上消息的LEO。

1. 丢消息！！！

2. 消息不一致！！！



### 丢消息的步骤

使用HW值来确定备份进度时其值的更新是在<font color=red>下一轮RPC</font>中完成的。如果Follower副本在标记上方的的第一步与第二步之间发生崩溃，那么就有可能造成数据的丢失。

原来的leader宕机重启之后到新Leader拉取数据，LEO大于新Leader的LEO，新的Leader让它截断，丢弃数据。则原来Leader上已经写成功的消息被截去丢失。



Follower从Leader获取消息之后，需要发送第二次请求，才能更新HW的值。

此时Follower处的LEO=HW+1。

假设Follower在发起第二次请求之前宕机重启，则Follower会将LEO调整为HW的值，即丢弃前面一条消息。

然后再与Leader拉取数据，假设此时Leader宕机，Follower切换为Leader，原来的Leader启动起来，发请求到新Leader同步数据，由于新Follower请求的消息偏移量大于新Leader的偏移量，新Leader会让新Follower删除之前的消息，与Leader保持同步。

则原本存在于leader和follower上的消息，分两次全删除了。

生产者已经发送成功的消息被无辜删掉了。



设置acks=-1。同时建议设置 `min.insync.replicas` 为副本个数的 N/2 + 1。



### 消息不一致的步骤

该设计还会造成Leader的Log和Follower的Log数据不一致。

如Leader端记录序列：m1,m2,m3,m4,m5,…；Follower端序列可能是m1,m3,m4,m5,…。



===================================================================================================================

通过在本地记录epoch信息用于截断消息，防止与Leader不一致：

<epoch, offset>



leader：

<0, 0>

<1, 10>

<2, 25>

<3, 50>



follower：

<0, 0>



request({0, 12})：Follower请求纪元为0的时候的偏移量为12的消息。

response(<1, 10>)：返回比0大的最小纪元数和纪元对应的offset，意思是follower的纪元0的11,10两条消息多余，删除。



如果没有纪元数字，则

request(12)：follower请求偏移量为12的消息

response(12)：将原本是纪元1的12消息返回。但是leader的10,11和follower的10,11消息不一样。

===================================================================================================================





原因：

1. 使用HW衡量副本备份成功与否。

2. 在出现失败重启时作为日志截断的依据。

但是Follower需要两次请求，才能更新HW值，HW更新滞后，不可靠。



对于丢消息，可以设置生产者参数acks=-1，即消息向所有ISR副本或指定数量的副本写成功，才确认生产成功。



通过在本地记录epoch信息用于截断消息，防止与Leader不一致：

<epoch, offset>



每次Leader切换，由集群控制器分配新的epoch（递增）。

Follower根据epoch和offset请求Leader，决定是否截断本地消息。





Follower每次请求Leader都会告诉Leader一个开始复制的Offset和其对应的Epoch

没有新记录追加时，如果新Leader的LEO比Follower请求的offset大，则复制照样进行

没有新记录追加时，如果新Leader的LEO比Follower请求的offset小，则通知Follower 偏移量越界，Follower重新计算可用的offset，并截断自身日志。

当有新记录追加时，新Leader会为记录分派offset（从自身的LEO开始单调递增），并把第一条记录的offset作为新的leaderEpoch的startOffset。

Follower请求复制数据时，新Leader将Follower请求的epoch和新的leaderEpoch进行对比：

1. 如果相等则返回新leader的logEndOffset（follower收到后会跟自己的请求offset做对比，取较小值）；

2. **如果不相等，则根据请求的epoch，在所有比它大的leaderEpoch（cache中有多个leaderEpoch和startOffset对）中找出最小的一个，返回其对应的startOffset（follower收到后就会检查是否需要truncate）；**

3. 如果cache中没有找到，则通知follower重新获取可用的offset并检查是否truncate。



1. Follower作为消费者，拉取Leader消息

2. Follower是长轮询，如果Leader有新消息，就发送给Follower，如果没有，就将消费者请求放到“炼狱”中等待一定时长（500ms），一有消息就立刻返回，或者等待该时长，返回。
3. Follower向Leader发请求，为了防止数据不一致，会对比Follower的epoch和offset，一旦Follower消息多，则丢弃Follower的消息，与Leader保持一致。
4. 为了解决消息丢失的问题，可以设置生产者参数：acks=-1



## 判断一个副本属于ISR还是OSR的依据：

![image-20210218120237515](note.assets/image-20210218120237515.png)



Kafka的配置属性：`replica.lag.time.max.ms`，默认值：10000

该属性表示如果Follower这么长的时间没有向Leader发送fetch请求，或者Follower这么长时间还没有消费到Leader的LEO，则表示该Follower应该从ISR移除，添加到OSR。

使用 `ReplicaLagTimeMaxMsProp` 的位置：

![image-20210218120637733](note.assets/image-20210218120637733.png)

此处获取该属性的值。

![image-20210218121021039](note.assets/image-20210218121021039.png)



![image-20210218122436231](note.assets/image-20210218122436231.png)

根据replicaMaxLagTimeMs计算分区的OSR。

![image-20210218122802269](note.assets/image-20210218122802269.png)





## Kafka 为什么不支持读写分离

目前我们可以推导出来的：

1. Kafka主题可以分为多个分区，每个分区有多个副本，其中一个是Leader，其余是Follower。

2. Kafka的分区副本必须分散于不同的Broker上。

3. Kafka的分区Leader分散于不同的Broker上，分配策略尽量保证分区Leader分布于不同的Broker上，除非分区数多于Broker数。

4. Leader分区负责IO操作，Follower负责同步，提供分区高可用。



为什么要读写分离？

Kafka的设计有没有充分利用服务器集群？



1. 同样是10台服务器，如果读写分离，就需要若干服务器只能读，不能写，降低了生产能力，吞吐量下降。



<img src="note.assets/image-20210218152848123.png" alt="image-20210218152848123" style="margin-right:15px"  /><img src="note.assets/image-20210218152854076.png" alt="image-20210218152854076" style="margin-left:15px" />



2. Kafka工作于内网，是中间件，用于服务间通信，消费者不是海量C端用户，而是下游服务。没有读写分离的场景，不是典型的少写多读。



<img src="note.assets/image-20210218153027587.png" alt="image-20210218153027587" style="zoom:120%;" />



![image-20210218153031653](note.assets/image-20210218153031653.png)



3. Kafka通过将主题分区分布于不同的Broker上，本身就提高了IO能力；

![image-20210218153112310](note.assets/image-20210218153112310.png)



4. Kafka一个Broker存储不同主题的分区，这些分区本身就是Leader和Follower混合的，互为主从，Broker既负责读也负责写。



![image-20210218153125313](note.assets/image-20210218153125313.png)



5. 还有个不是问题的问题：

   消息同步的延迟

   

![image-20210218153146621](note.assets/image-20210218153146621.png)



总结：

读写分离是上个时代的产物，互为主备才是王道！

![image-20210218153213173](note.assets/image-20210218153213173.png)



**Kafka从2.4版本开始支持Follower的读。**

*减少了跨数据中心的Leader读取的性能损耗。*

1. 添加了发现最近邻Follower的策略。
2. 添加了从Follower读取的Fetch协议。