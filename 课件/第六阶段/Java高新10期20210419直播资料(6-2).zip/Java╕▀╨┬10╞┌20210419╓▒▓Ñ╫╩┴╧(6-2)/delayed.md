



# 关于Kafka的延迟操作



讲一讲kafka的延时队列吧。课件上讲的延时队列感觉不是真正的延时队列，更像是延时处理一样，和rabbitmq的延时交换机功能都不一样。



Kafka是一个流处理平台，具备消息队列的基本功能，可以称为消息队列。

它没有延迟消费这样的功能；因此如果想要延迟消费，比如等待30分钟再消费，则需要自己实现。



kafka包含了一个类：`kafka.server.DelayedOperation`

该类定义了延迟的操作。它是一个抽象类，它的子类包括：

`kafka.server.DelayedCreatePartitions`

`kafka.server.DelayedDeleteRecords`

`kafka.server.DelayedDeleteTopics`

`kafka.server.DelayedFetch`

`kafka.coordinator.group.DelayedHeartbeat`

`kafka.coordinator.group.DelayedJoin`

`kafka.server.DelayedProduce`

`kafka.coordinator.transaction.DelayedTxnMarker`

`kafka.coordinator.group.InitialDelayedJoin`



`kafka.server.DelayedFetch` 用于实现：

1. Follower向Leader拉取消息的时候，如果Leader没有新消息，则需要将请求放到炼狱中等待，默认500ms，如果在此时间内有消息，则响应Follower请求，如果没有，则500ms超时后响应Follower。
2. 当消费者拉取消息的时候，调用 `consumer.poll(3000)` ，表示如果消费者拉取消息的时候broker端没有新消息，则消费者请求在炼狱等待3000ms，如果在此期间有新消息，则响应消费者，如果没有，则当该时间超时后响应消费者没有新消息。





