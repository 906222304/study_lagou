

# 第六阶段 6-2 Kafka直播



## 0. 疑难解答

**点对点和发布订阅是指什么啊，kafka 是消费者拉取消息，又不是像  rabbitmq订阅了之后推送消息**



JMS规范目前支持两种消息模型：点对点（point to point， queue）和发布/订阅（publish/subscribe，topic）。

***点对点***

- 消息生产者生产消息发送到队列中，然后消息消费者从队列中取出并且消费消息。

- 消息被消费以后，队列中不再有存储，所以消息消费者不可能消费到已经被消费的消息。

- 队列支持存在多个消费者，但是对一个消息而言，只会有一个消费者可以消费。

***发布/订阅***

- 消息生产者（发布）将消息发布到topic中，同时有多个消息消费者（订阅）消费该消息。和点对点方式不同，发布到topic的消息会被所有订阅者消费。



*因此，究竟是发布订阅，还是点对点，跟消息的消费是推模式还是拉模式无关。*



**课程提到一旦Leader接收到Follower发送的FETCH请求，它先从Log中读取相      应的数据，给Follower返回数据前，先更新Follower的LEO，那是否会出现由于follow网络原因或者其他原因导致整个消息同步失败，最终两者的leo出现偏差，导致HW不准确**

会的，Follower同步Leader消息涉及到消息的拉取和HW的更新两个操作，而这两个操作不是原子的，如果不做处理，会引起消息的丢失和消息的离散（消息不一致）。之所以这么做，是因为类似于TCP的三次握手，需要二次确认。



**同步副本的定义是与leader副本保持一定程度同步的副本,在可以忍受的滞后范围内,为啥说只要有至少一个同步副本处于活动状态,提交的消息就不会丢失,它不是也有可能未同步完成吗**

至少一个同步副本：ISR中包含Leader副本，可能的Follower副本。

OSR中都是Follower副本。

消息的丢失是一个大问题。需要从Follower同步Leader消息的方式理解。



**所说的消费者只能消费到HW的消息是否只针对事务消息的read committed情况**

HW？LEO，LEO处没有消息，它是下一条消息的偏移量。

对于消费者客户端（不是Follower），只能读取到HW之前的消息，不管是不是事务消息。

对于事务消息，不仅仅是读取到HW之前消息的情况，LSO小于等于HW。如果有追加的事务消息，而该事务正在进行中，则即使HW更新到最后一条消息+1的位置，**LSO是该未提交事务第一条消息的偏移量**，LSO小于HW。消费者对read_committed的情况，也只能消费到LSO-1的位置，而不是HW。

如果是read_uncommitted的情况，消费者可以消费到HW-1的消息。



### Kafka架构：

<img src="kafka.assets/image-20210218153400769.png" alt="image-20210218153400769" style="zoom:120%;" />



### 名词解释

AR、ISR、OSR如下：

![image-20210218152018749](kafka.assets/image-20210218152018749.png)



LEO如下：latest end offset，LEO处没有消息

![image-20210218152051411](kafka.assets/image-20210218152051411.png)



HW如下：HW也是LEO，ISR中最小的LEO

![image-20210218152107265](kafka.assets/image-20210218152107265.png)





总体：

![image-20210218152200010](kafka.assets/image-20210218152200010.png)



10s

如果Follower副本超过10s，才从leader拉取数据，Follower属于OSR

如果Follower用了超过10s，都没有读到leader副本的LEO，则Follower属于OSR



### Follower与Leader的同步：

1. Follower以消费者姿态消费Leader消息

   拉取 pull

   长轮询

   “炼狱”（replica.fetch.wait.max.ms=500）



新分区的Leader和Follower副本

![image-20210218152325018](kafka.assets/image-20210218152325018.png)



Leader接收到生产者的一条消息：

![image-20210218152331537](kafka.assets/image-20210218152331537.png)

Follower发送拉取消息请求，带着自己的HW，LEO值

![image-20210218152358247](kafka.assets/image-20210218152358247.png)

Leader发送响应，Follower更新自己的LEO

此时，事实上的HW是1，但是HW=0？为什么？

TCP三次握手建立连接。需要对发送的消息进行二次确认

acks=1

过半机制

min.insync.replicas=N/2 + 1，该参数默认为1

acks=-1

![image-20210218152412068](kafka.assets/image-20210218152412068.png)

Follower发起请求拉取数据，自己的参数：LEO=1 HW=0

![image-20210218152427168](kafka.assets/image-20210218152427168.png)



Leader将Remote-LEO更新为1，比较将HW设置为1，并响应Follower

![image-20210218152443533](kafka.assets/image-20210218152443533.png)

Leader收到第二条消息，更新自己的LEO=2

![image-20210218152455716](kafka.assets/image-20210218152455716.png)



![image-20210218152502624](kafka.assets/image-20210218152502624.png)



![image-20210218152509933](kafka.assets/image-20210218152509933.png)

![image-20210218152514233](kafka.assets/image-20210218152514233.png)





Follower需要两次请求，才能更新HW值

这种设计是有问题的，请问是什么问题？如何解决？

提示一下：假如在Follower同步HW之前Leader宕机，此时Leader和Follower拥有同样的消息，但是共有的HW没有赶上消息的LEO。

1. 丢消息！！！

2. 消息不一致！！！



HW的用意：

1. 让消费者只能消费到HW之前的消息，可以保证在Leader发生变化的时候，ISR中的副本上消息是一致的。
2. 在broker重启的时候，对消息进行截断。



### 丢消息的步骤

使用HW值来确定备份进度时其值的更新是在<font color=red>下一轮RPC</font>中完成的。如果Follower副本在标记上方的的第一步与第二步之间发生崩溃，那么就有可能造成数据的丢失。

原来的leader宕机重启之后到新Leader拉取数据，LEO大于新Leader的LEO，新的Leader让它截断，丢弃数据。则原来Leader上已经写成功的消息被截去丢失。



Follower从Leader获取消息之后，需要发送第二次请求，才能更新HW的值。

此时Follower处的LEO=HW+1。

假设Follower在发起第二次请求之前宕机重启，则Follower会将LEO调整为HW的值，即丢弃前面一条消息。

然后再与Leader拉取数据，假设此时Leader宕机，Follower切换为Leader，原来的Leader启动起来，发请求到新Leader同步数据，由于新Follower请求的消息偏移量大于新Leader的偏移量，新Leader会让新Follower删除之前的消息，与Leader保持同步。

则原本存在于leader和follower上的消息，分两次全删除了。

生产者已经发送成功的消息被无辜删掉了。



设置acks=-1。同时建议设置 `min.insync.replicas` 为副本个数的 N/2 + 1。



acks = 0, 1, -1



### 消息不一致的步骤

当消息发送到D的时候，Follower拉取了D消息，发送第二次请求，要求更新HW，但是，此时，Leader收到了该请求，更新了自己的HW值，但是在响应的时候，双双宕机，重启，此时原来的Leader不需要截断消息；

新的Leader发生了切换，原来的Leader变为新的Follower了。

新的Leader需要截断，因为前一次没有来得及更新自己的HW

生产者接着发消息，发送给新的Leader，从原来D的位置截断后，接收新的消息E；

对于原来的Leader，此时的Follower，D消息不用截断，直接接着从D的下一个拉取新的Leader的消息

引起消息不一致。

消息截断依赖HW，自己副本的HW值，当该副本所在的broker宕机重启，broker在启动中要对消息进行截断

因为HW之前的消息是可靠的，HW之后的消息不可靠，截断。

一切leader说了算，leader会让follower截断消息。

![image-20210316204904972](kafka.assets/image-20210316204904972.png)

该设计还会造成Leader的Log和Follower的Log数据不一致。

如Leader端记录序列：m1,m2,m3,m4,m5,…；Follower端序列可能是m1,m3,m4,m5,…。



===================================================================================================================

通过在本地记录epoch信息用于截断消息，防止与Leader不一致：

<epoch, offset>



集群控制器，负责通过副本管理器，选择新的Leader，集群控制器生成新的epuch

单调递增

offset指的是，当前副本成为leader是接收的偏移量。



leader：

<0, 0>

<1, 10>

<2, 25>

<3, 50>



follower：

<0, 0>



request({0, 12})：Follower请求纪元为0的时候的偏移量为12的消息。

response(<1, 10>)：返回比0大的最小纪元数和纪元对应的offset，意思是follower的纪元0的11,10两条消息多余，删除。



如果没有纪元数字，则

request(12)：follower请求偏移量为12的消息

response(12)：将原本是纪元1的12消息返回。但是leader的10,11和follower的10,11消息不一样。

===================================================================================================================



epoch类似于打版本号，确切地讲，epoch更是将相同偏移量的消息，如果内容不一样，那么它们肯定来源于不同的Leader，epoch用于标记它们各自来源于哪个Leader，最终以当前Leader记录的消息为准，Follower的消息需要删除。

HW，HW表示ISR中所有副本中都包含的消息的偏移量+1。因为HW是从LEO计算出来的。



原因：

1. 使用HW衡量副本备份成功与否。

2. 在出现失败重启时作为日志截断的依据。

但是Follower需要两次请求，才能更新HW值，HW更新滞后，不可靠。



对于丢消息，可以设置生产者参数acks=-1，即消息向所有ISR副本或指定数量的副本写成功，才确认生产成功。

通过在本地记录epoch信息用于截断消息，防止与Leader不一致：

<epoch, offset>



每次Leader切换，由集群控制器分配新的epoch（递增）。

Follower根据epoch和offset请求Leader，决定是否截断本地消息。



Follower每次请求Leader都会告诉Leader一个开始复制的Offset和其对应的Epoch

没有新记录追加时，如果新Leader的LEO比Follower请求的offset大，则复制照样进行

没有新记录追加时，如果新Leader的LEO比Follower请求的offset小，则通知Follower 偏移量越界，Follower重新计算可用的offset，并截断自身日志。

当有新记录追加时，新Leader会为记录分派offset（从自身的LEO开始单调递增），并把第一条记录的offset作为新的leaderEpoch的startOffset。<epoch, offset>

Follower请求复制数据时，新Leader将Follower请求的epoch和新的leaderEpoch进行对比：

1. 如果相等则返回新leader的logEndOffset（follower收到后会跟自己的请求offset做对比，取较小值）；

2. **如果不相等，则根据请求的epoch，在所有比它大的leaderEpoch（cache中有多个leaderEpoch和startOffset对）中找出最小的一个，返回其对应的startOffset（follower收到后就会检查是否需要truncate）；**

3. 如果cache中没有找到，则通知follower重新获取可用的offset并检查是否truncate。



1. Follower作为消费者，拉取Leader消息

2. Follower是长轮询，如果Leader有新消息，就发送给Follower，如果没有，就将消费者请求放到“炼狱”中等待一定时长（500ms），一有消息就立刻返回，或者等待该时长，返回。
3. Follower向Leader发请求，为了防止数据不一致，会对比Follower的epoch和offset，一旦Follower消息多，则丢弃Follower的消息，与Leader保持一致。
4. 为了解决消息丢失的问题，可以设置生产者参数：acks=-1



### 判断一个副本属于ISR还是OSR的依据：

![image-20210218120237515](kafka.assets/image-20210218120237515.png)



Kafka的配置属性：`replica.lag.time.max.ms`，默认值：10000

该属性表示如果Follower这么长的时间没有向Leader发送fetch请求，或者Follower这么长时间还没有消费到Leader的LEO，则表示该Follower应该从ISR移除，添加到OSR。

使用 `ReplicaLagTimeMaxMsProp` 的位置：

![image-20210218120637733](kafka.assets/image-20210218120637733.png)

此处获取该属性的值。

![image-20210218121021039](kafka.assets/image-20210218121021039.png)



![image-20210218122436231](kafka.assets/image-20210218122436231.png)

根据replicaMaxLagTimeMs计算分区的OSR。

![image-20210218122802269](note.assets/image-20210218122802269.png)





## 1. 内容回顾

Kafka通过横向扩展的方式提升吞吐量。

单机：200g/H



主题：-> n分区

宕机概率：

为了保证主题分区的高可用：副本机制。

21s PB



生产者发送消息：

1. 如果发送的消息既没有设置key，也没有手动指定分区号，则通过轮询的方式将消息均匀地分发到主题的各个分区；第一个消息随机地分配主题分区。
2. 如果发送消息的时候指定了key，则根据hash(key)%主题分区个数，计算消息的分区号；
3. 手动指定消息的分区号；具体的分配分区策略自己按照业务要求来写，需要保证消息的负载均衡，同时满足业务上对消息顺序的要求；



消费者如何横向扩展？

消费组：消费组中有多个消费者

消费组协调器：broker端



一个分区只能分配给消费组中一个消费者，一个消费者可以分配多个分区

防止消息的重复消费。

再平衡：

主题：10分区

消费组：3消费者；

消费组名称：

根据消费组名称(group.id)，请求一个broker，根据group.id的hash值对`__consumer_offsets`主题的分区个数取模，计算出该消费组应该将偏移量存储在`__consumer_offsets`的哪个分区

然后由该分区leader副本所在的broker上的消费组协调器组件，对该消费组负责，进行再平衡。

从消费组中选出一个消费者做为leader，对主题分区进行分配，分配给各个消费者。joingroup

syncgroup：将leader消费者计算的分区分配同步给消费组中的各个消费者，此时，各个消费者就知道该消费哪些分区的数据了。



触发再平衡？

1. 有消费者从消费组退出/加进来
2. 订阅的主题分区数变更
3. 订阅的主题使用的是正则表达式：假如又创建了新的主题，匹配该正则表达式，则触发再平衡。



10个分区，11个消费者，会有一个消费者分配不到分区







![image-20210107194226736](kafka.assets/image-20210107194226736.png)

通过消费组协调器：GroupCoordinator进行分配：

分配的过程：将主题分区分配给同一个消费组中的消费者，再平衡

“__consumer_offsets”主题  哪个分区，则该分区leader所在的broker上的GroupCoordinator对消费组负责：

协调器从该组中的消费者中选出一个消费者对分区分配进行计算，结果由组协调器同步到该组的各个消费者中

各个消费者就知道它该消费哪几个分区的数据了。



再平衡的分区分配策略：

按范围分配：RangeAssigner

按轮询分配：RoundRobinAssigner

粘性分配：StickyAssigner





集群：

分片：横向扩展

镜像：读写分离，高可用。。



主题 —- MySQL分库分表中的虚拟表 MyCat  tb_order (tb_order1,tb_order2,tb_order3…)

主题进行分片

分区，一个主题对应多个分区，每个分区，尽量放到不同的Broker上。



redis如何做横向扩展？

hashslot的作用：16384个hashslot



主题—分区–副本机制

Leader Follower  不能在同一台服务器上

数据一致性

CAP定理 zk数据一致性  分区容忍性   可用性   5  4  1

zk是AP还是CP？



过半机制？没有

200GB/h

1  3副本

2  5副本



Kafka不使用过半机制



ISR集合 + OSR集合 = AR  all replcas

同步副本集合   不同步副本集合

HW LEO LSO。。。





生产者发送消息的负载均衡策略：

key，分区号，什么都不指定



1. 如果什么都不指定，生产者消息以轮询的方式将消息发送到主题的各个分区
2. 如果指定key，则使用key的hash%分区数  计算当前消息应该发向的分区
3. 如果指定了分区号，则直接向该分区发送消息





两个反常识：

1. 不使用过半机制保证分区副本的高可用和一致性
2. Kafka的消息存储在磁盘上



磁盘IO速度要不要和内存比？

磁盘IO和网络IO进行比较：



1. MMap  内存映射

2. 零拷贝  transferTo

3. 磁盘的顺序读写

只要磁盘的读写速度比网卡快一点点即可。







## 2. Kafka测试题和模块作业

### 任务一：Kafka架构与实战

 

**1、Kafka的优势有哪些？AB**

A、高吞吐量

B、高性能

C、根据Tag进行消息过滤（RocketMQ）

D、遵循AMQP协议（RabbitMQ）

 

**2、Kafka应用场景有哪些？ABD**

A、日志收集

B、消息队列

C、请求响应模式

D、流式处理

 

 

**3、下面几项属于Kafka基本架构的是？ABCD**

A、生产者

B、消费者

C、主题

D、分区

E、Router

 

**4、属于Kafka概念的是：ACDE**

A、AR  ar=isr+osr

B、AI

C、ISR

D、OSR

E、HW

 

### 任务二：Kafka高级特性解析

**1、生产者发送数据，客户端需要经过的步骤包括：ABCDE**

A、过滤器

B、In-Flight-Request缓存区  sender线程使用的（记录已经发送尚未确认的消息）

C、分区器

D、序列化器

E、RecordAccumulator

 

**2、Kafka与传统消息系统之间关键区别BC**

A、Kafka持久化日志，这些日志默认可以被重复读取和无限期保留

B、Kafka是一个分布式系统：它以集群的方式运行，可以灵活伸缩，在内部通过复制数据提升容错能力和高可用性

C、Kafka支持实时的流式处理

D、支持消息的推送

 

**3、kafka为什么那么快ABCD**

A、PageCache缓存

B、顺序写；由于现代的操作系统提供了预读和写技术，磁盘的顺序写大多数情况下比随机写内存还要快。

C、零拷技术减少拷贝次数

D、批量处理。合并小的请求，然后以流的方式进行交互，直顶网络上限。

E、Kafka从设计上，延时较小。





### 任务三：Kafka集群与运维

**1、什么时候发生rebalance？ABCD**

A、组订阅topic数变更

B、topic partition数变更

C、consumer成员变更

D、consumer 加入群组或者离开群组的时候

E、生产者停止发送消息的时候

**2、Kafka的设计是什么样的？ACD**

A、Kafka将消息以topic为单位进行归纳

B、将向Kafka topic发布消息的程序称为producer，producer没有横向扩展

C、将预订topics并消费消息的程序成为consumer，consumer可以横向扩展

D、Kafka以集群的方式运行，可以由一个或多个服务组成，每个服务叫做一个 broker.

 

**3、Kafka producer如何优化加快速度 ABCDEF**

A、增加线程

B、提高batch.size

C、增加更多Producer实例

D、增加partition数

E、设置acks=-1时，如果延迟增大：可以增大num.replica.fetchers（follower 同步数据的线程数）来调解；

F、跨数据中心的传输：增加socket缓冲区设置以及OS tcp缓冲区设置。

 

### 任务四：Kafka源码剖析

**1、Kafka中Zookeeper的作用是？ABCE**

A、meta信息存储

B、consumer的消费状态

C、group的管理

D、offset管理。  __consumer_offsets主题

E、选举controller和检测broker是否存活。

 

 

**2、request.required.acks属性值的解释正确的是？C**

A、0表示当Leader接收成功时确认；

B、1表示不进行消息接收是否成功的确认；

C、-1表示Leader和Follower都接收成功时确认；

D、All表示当Leader接收成功时确认；

**3、数据传输的事务定义有哪三种？ACD**

A、最多一次: 消息不会被重复发送，最多被传输一次，但也有可能一次不传输

B、不能保证精确一次

C、最少一次: 消息不会被漏发送，最少被传输一次，但也有可能被重复传输.

D、精确的一次（Exactly once）





## 3. 模块作业：

 

使用Kafka做日志收集。

需要收集的信息：

1、用户ID（user_id）

2、时间（act_time）

3、操作（action，可以是：点击：click，收藏：job_collect，投简历：cv_send，上传简历：cv_upload）

4、对方企业编码（job_code）





1、HTML可以理解为拉勾的职位浏览页面

2、Nginx用于收集用户的点击数据流，记录日志access.log

3、将Nginx收集的日志数据发送到Kafka主题：tp_individual



架构：

HTML+Nginx+[ngx_kafka_module](https://github.com/brg-liuwei/ngx_kafka_module)+Kafka



http://localhost:8080/log.gif=xxxxxx



实战步骤：

1. 安装Kafka

2. 安装Nginx

3. 配置ngx_kafka_module

4. 开发HTML页面

 

### 解决方案



1. 安装依赖

   ```shell
   yum install wget git -y
   yum install gcc-c++ -y
   
   git clone https://github.com/edenhill/librdkafka
   cd librdkafka
   ./configure
   make
   sudo make install
   ```

2. 下载nginx

   ```shell
   wget http://nginx.org/download/nginx-1.17.8.tar.gz
   tar -zxf nginx-1.17.8.tar.gz
   cd nginx-1.17.8
   yum install gcc zlib zlib-devel openssl openssl-devel pcre pcre-devel -y
   ```

3. 下载ngx_kafka_module

   ```shell
   cd ~
   git clone https://github.com/brg-liuwei/ngx_kafka_module.git
   cd nginx-1.17.8
   ./configure --add-module=/root/ngx_kafka_module
   make
   sudo make install
   ```

4. 配置nginx：nginx.conf

   ```shell
   http {
   
       # some other configs
   
   	kafka;
   
   	kafka_broker_list 127.0.0.1:9092 127.0.0.1:9093; # host:port ...
   
   	server {
   		location = /log {
   			add_header 'Access-Control-Allow-Origin' $http_origin;
   			add_header 'Access-Control-Allow-Credentials' 'true';
   			add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS';
   			add_header 'Access-Control-Allow-Headers' 'DNT,web-token,app-token,Authorization,Accept,Origin,Keep-Alive,User-Agent,X-Mx-ReqToken,X-Data-Type,X-Auth-Token,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range';
   			add_header 'Access-Control-Expose-Headers' 'Content-Length,Content-Range';
   			if ($request_method = 'OPTIONS') {
   				add_header 'Access-Control-Max-Age' 1728000;
   				add_header 'Content-Type' 'text/plain; charset=utf-8';
   				add_header 'Content-Length' 0;
   				return 204;
   		     }
   		     kafka_topic tp_log_01;
   	}
   }
   ```

5. 让操作系统加载模块：

   ```shell
   echo "/usr/local/lib" >> /etc/ld.so.conf
   ldconfig
   ```

6. 启动Kafka

   ```shell
   zkServer.sh start
   kafka-server-start.sh /opt/kafka_2.12-1.0.2/config/server.properties
   ```

7. 启动nginx：

   ```shell
   /usr/local/nginx/sbin/nginx
   ```

8. 测试：

   ```shell
   curl localhost/log -d "hello ngx_kafka_module" -v
   ```

   ![image-20200824153039666](kafka.assets/image-20200824153039666.png)

9. 使用Idea的静态项目直接打开访问即可：

   ![image-20200824153326801](kafka.assets/image-20200824153326801.png)

10. 效果

    <img src="kafka.assets/image-20200824153444480.png" alt="image-20200824153444480" style="zoom:80%;" />



## 4. 疑难解答





### 问题1

**不同规模kafka集群kafka的配置**





### 问题2

**在kafka server.properties的配置文件中配置的 zookeeper.connect=linux121:2181/kafka-solo 我只配置了一个zk地址 我吧这个服务器上的zk停止后 kafka还是能正常运行的 与我配置多个zk 挂了一个的效果是一样的 但是在课程中好像说到只配置一个的话挂了 kafka不能使用了 这里不太理解kafka连接zk的机制 怎么配置一个挂了 还是能正常运行**



`zookeeper.connect` 连接的如果是zk集群，不要写一个zk地址，最好写多个，以防有zk节点宕机。

你说的kafka正常运行指的什么情况？

演示：

创建好kafka集群，启动zk集群，kafka中指定一个zk节点。关闭该zk节点，创建主题试试结果。





### 问题3

**在配置了主题的参数 compression.type producer为压缩格式后消费者是不是也要进行对应的解压缩才能读取啊？能不能操作下**



你有没有操作过？





生产者发送的压缩消息，以压缩的形式存储到日志中，消费者消费的时候读取的也是压缩的消息。

读取到后，由消费者进行解压：



```java
package com.lagou.kafka.demo;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.record.CompressionType;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.HashMap;
import java.util.Map;

public class ComProducer {
    public static void main(String[] args) {
        Map<String, Object> configs = new HashMap<>();
        configs.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "node1:9092,node2:9092,node3:9092");
        configs.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configs.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configs.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, CompressionType.GZIP.name);

        KafkaProducer<String, String> producer = new KafkaProducer<String, String>(configs);

        for (int i = 0; i < 1000; i++) {
            producer.send(new ProducerRecord<>(
                    "tp_com_01",
                    "key-" + i,
                    "value-" + i
            ), new Callback() {
                @Override
                public void onCompletion(RecordMetadata metadata, Exception exception) {
                    if (exception != null) {
                        System.err.println(exception);
                    }
                }
            });
        }

        producer.close();

    }
}
```



```java
package com.lagou.kafka.demo;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.record.CompressionType;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.HashMap;
import java.util.Map;

public class MyProducer {
    public static void main(String[] args) {
        Map<String, Object> configs = new HashMap<>();
        configs.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "node1:9092,node2:9092,node3:9092");
        configs.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configs.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
//        configs.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, CompressionType.GZIP.name);

        KafkaProducer<String, String> producer = new KafkaProducer<String, String>(configs);

        for (int i = 0; i < 1000; i++) {
            producer.send(new ProducerRecord<>(
                    "tp_com_01",
                    "key-" + i,
                    "value-" + i
            ), new Callback() {
                @Override
                public void onCompletion(RecordMetadata metadata, Exception exception) {
                    if (exception != null) {
                        System.err.println(exception);
                    }
                }
            });
        }

        producer.close();

    }
}
```



```java
package com.lagou.kafka.demo;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.record.CompressionType;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.HashMap;
import java.util.Map;

public class ComProducer {
    public static void main(String[] args) {
        Map<String, Object> configs = new HashMap<>();
        configs.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "node1:9092,node2:9092,node3:9092");
        configs.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configs.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configs.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, CompressionType.GZIP.name);

        KafkaProducer<String, String> producer = new KafkaProducer<String, String>(configs);

        for (int i = 0; i < 1000; i++) {
            producer.send(new ProducerRecord<>(
                    "tp_com_01",
                    "key-" + i,
                    "value-" + i
            ), new Callback() {
                @Override
                public void onCompletion(RecordMetadata metadata, Exception exception) {
                    if (exception != null) {
                        System.err.println(exception);
                    }
                }
            });
        }

        producer.close();

    }
}
```



创建主题，指定主题的默认压缩策略为GZIP：

```shell
kafka-topics.sh --zookeeper node2:2181/myKafka --create --topic tp_com_02 --partitions 3 --replication-factor 2 --config compression-type=gzip
```

重新测试。





### 问题4

**Kafka丢失数据问题如何优化**



- Kafka的副本机制

- 生产者发送数据的时候，设置acks=-1，默认ISR集合中所有副本都确认，即表示发送消息成功。

  在acks=-1的基础上，可以设置 `min.insync.replicas` 。

  典型的使用方式为：`replication-factor=3`， `min.insync.replicas=2`，如此可以保证大多数副本接收到消息，提高了消息的可靠性。

  如果在发送消息的时候，同步的副本个数达不到 `min.insync.replicas` 指定的值，则生产者抛异常： `NotEnoughReplicas` 或者 `NotEnoughReplicasAfterAppend` 。

- 消费者使用手动提交偏移量，保证在消息消费失败的时候可以重试。

- 幂等解决数据重复，事务保证原子性

- 禁用不完全leader选举：`unclean.leader.election.enable=false`

- 失败的消息单独处理





### 问题5

疑问 ：baseOffset是否在两个不同的场景下分别有其独有的定义吗？① .log 文件的元数据中每一条记录（对应一个消息批）包含的第一条消息的offset；② 每个 logSegment 日志分段文件的基准偏移量（每个分段日志对应的第一条消息的偏移量，就是 logSegment 的文件名）；总结一下问题，请问baseOffset定义是什么呢？

是如 .log 日志文件的元数据所示，每一个消息批都有一个baseOffset（和一个lastOffset）；还是每个日志分段的第一条消息的偏移量？

个人理解：结合baseOffset和logStartOffset的组合使用来看，使用的是后者的定义，但是 .log 文件中每个消息批的数据信息都写有baseOffset作为起始消息的偏移量，使用的又是前者的定义。所以比较迷惑，是两个不同的定义共用了同一个名词吗？



仅是重名，或者说定义两个str的变量，不同类中str表示不同的含义。

- 日志片段LogSegment有baseOffset，表示当前日志分段的第一个消息偏移量。

- 消息批也有baseOffset，它表示该消息批中第一条消息的偏移量



日志片段中的baseOffset：

![image-20210107153116256](kafka.assets/image-20210107153116256.png)



baseOffset是消息批的属性：

![image-20210107150441630](kafka.assets/image-20210107150441630.png)





### 问题6

疑问：事务流程的初始阶段中，步骤三提到“Broker负责生成事务ID”，个人理解事务ID TransactionalId 是需要用户提前自行配置的？而且需要有 TransactionalId 才可以计算出哪个Broker作为事务协调器 实现步骤一的内容。所以是步骤三动作有错还是TransactionalId的确是Broker生成的？（目前的疑惑在于，如果是后者这种理解，这就有点先有鸡还是先有蛋的感觉了）



我们设置的是`transactional.id`，使用beginTransaction()方法开启事务，该方法需要对我们的`transactional.id`，以及其他信息进行封装。



Kafka事务怎么实现？



#### 事务工作流程



<img src="D:/lagou3/kafka%25E7%259B%25B4%25E6%2592%25AD-new/troubleshooting.assets/transactions-1-1024x693.png" alt="img" style="zoom:80%;" />

#### 事务协调器和事务日志

事务协调器是每个broker内部运行的一个模块。事务日志是kafka的内部主题。每个事务协调器对应事务日志的某些分区。

事务日志的Leader分区和事务协调器在同一个broker中，则这些事务日志的分区对应于当前broker上的事务协调器。

每个transactional.id通过简单的散列算法映射到事务日志指定的分区。每个transactional.id，对应一个事务协调器。

Kafka的副本机制和leader选举保证事务协调器是高可用的，并且所有的事务状态数据是持久化的。

需要注意的是事务日志只记录最新事务的状态而不是实际的事务消息。实际的事务消息存储于真正的主题分区。事务由多种状态，如"Ongoing"，"Prepare commit"以及"Completed"。事务日志中记录的就是这些状态以及这些状态关联的元数据。



#### 数据流

从高层看，数据流分为四种类型。

##### A: 生产者和事务协调器的交互

执行事务的时候，生产者在如下节点向事务协调器发送请求：

1. `initTransactions` API注册`transactional.id`到事务协调器。此时，协调器会关闭相同`transactional.id`对应的事务，通过epoch隔离僵尸生产者。对每个生产者会话只发生一次。
2. 当生产者第一次向主题分区发送数据的时候，需要先将分区注册到事务协调器。
3. 当应用调用*commitTransaction*或*abortTransaction*的时候，向协调器发送请求以开启两阶段提交。

##### B: 事务协调器和事务日志的交互

当事务进行的时候，生产者发送请求到事务协调器用于更新事务的状态。事务协调器在内存保存每个事务的状态，同时也将事务的状态持久化到事务日志。

事务协调器是唯一读写事务日志的组件。如果broker宕机，当前事务对应的事务日志的分区Leader分区会出现在其他broker上，当前事务的事务管理器就在该新的broker上。新的事务协调器在内存重建事务日志分区的各个事务的状态。

##### C: 生产者写数据到目标主题分区

生产者向事务协调器注册一个新的主题分区，然后开始向该主题分区写消息，这个写消息的过程跟往常一样，只是多了一些验证，保证该生产者不是应该被隔离的。

##### D: 事务协调器和主题分区的交互

当生产者请求提交或中断事务，协调器开始两阶段提交。

第一个阶段，协调器将事务的内部状态修改为"prepare_commit"，同时在事务日志中更新该事务状态。一旦搞定，事务就可以提交或中断。

在第二个阶段，向主题分区写事务提交标记，这些主题的分区就是该事务涉及到的主题分区，用于存放业务数据的。

事务标记不会暴露给应用，消费者在使用`read_committed`隔离级别消费消息的时候会使用事务标记过滤掉中断的事务。

一旦事务标记写入完成，事务协调器标记该事务为"complete"，生产者就可以开启下一个事务了。





### 问题7

为什么使用多个拦截器，一个拦截器里面进行多个逻辑的处理不行吗



可以在一个拦截器中执行多个逻辑。但是拦截器的使用方式不适用于处理重的逻辑，一般用于自定义监控，记录日志等。类似于Spring中的AOP横切性质的方法使用。







============================================================================================================================================================================================================================================================================================================================================================================================================================================================================



### 问题1

**broker宕机，主题X的分区3宕机，此时分区3有Leader副本，是否触发再平衡**



触发再平衡的条件：

1. 消费组成员增加或减少
2. 主题分区数增加
3. 订阅的主题发生变化



broker宕机引起的分区leader切换，触发再平衡。





### 问题2

**老师，调用链路过长，想采用MQ拆分，但是什么时候应该拆分什么时候不应该差分有没有什么判断标准呢**



首先，MQ用在业务场合，一般用于解耦，异步，流量削峰等。

1. 调用链路上的各个部分有没有前后依赖关系？是否可以异步处理
2. 如果可以异步处理，如何保证一致性
3. 需要处理幂等性







### 问题3

**对于kafka得某一个主题，部分消息只有100k，部分消息可能达到1MB（可能不具体，就是特别大）该怎么处理呢（区分开怎么没处理，混在一起又该怎么去处理呢），消费端代码不变**



1. 如果传输大的消息，Kafka吞吐量会下降，所以最好别传输大的消息
2. 可以对消息进行切割，分块发送，不过需要保证消息发送到同一个主题分区，确保顺序
3. 开启Kafka的消息压缩



如果必须传输大消息，则服务端可以设置：

1. Kafka可以设置允许的消息大小：

   全局：message.max.bytes，用于设置消息批次的字节最大值。

   单个主题设置：max.message.bytes，用于设置消息批次的字节最大值。

```shell
bin/kafka-topics.sh --zookeeper localhost:2181 --create --topic my-topic \
--partitions 1 --replication-factor 1 \ 
--config max.message.bytes=64000 --config flush.messages=1
```

2. replica.fetch.max.bytes，（默认: 1MB）：broker可复制的消息的最大字节数。这个值应该比message.max.bytes大，否则broker会接收此消息，但无法将此消息复制出去，从而造成数据丢失。



消费端设置：

fetch.message.max.bytes，（默认 1MB）：消费者能读取的最大消息。这个值应该大于或等于message.max.bytes。





### 问题4

**leader挂了重新选leader的时候，允许有一定的滞后性，这个滞后的消息怎么办？**



消息首先放到消息累加器

Sender线程负责查找准备好需要发送的消息批次，检查是否连接上broker，可以发送消息批次了。如果消息的分区leader未准备好，则强制刷新集群元数据。

![image-20201130173513335](kafka.assets/image-20201130173513335.png)

![image-20201130173550448](kafka.assets/image-20201130173550448.png)

![image-20201130173623305](kafka.assets/image-20201130173623305.png)

![image-20201130173639306](kafka.assets/image-20201130173639306.png)



然后将未准备好接收数据的broker从发送列表中移除，消息批次不发送。只发送可以发送的消息批次。

未发送的消息在消息累加器中计时，如果消息批次超时，则将消息失败，从消息累加器删除，同时回调send方法的onComplete方法，处理发送失败异常。

```java
producer.send(message, new Callback() {
    @Override
    public void onCompletion(RecordMetadata metadata, Exception exception) {
        // 处理消息发送失败逻辑
    }
});
```



不过期的消息会下次run(long time)调用时重新发送。



### 问题5

**kafka的重新选举再讲一下**



 * 选择新的分区leader，新的isr和接收LeaderAndIsrRequest的副本：
 * 1. 如果isr中至少有一个broker存活，则从存活的isr中选择一个broker作为新的leader，存活的isr作为新的isr。
 * 2. 否则，如果没有设置不干净的leader选举，则抛异常NoReplicaOnlineException
 * 3. 否则，就从OSR中选择一个存活的broker作为新的leader，只有leader是isr。
 * 4. 如果分区没有副本存活，则抛异常：NoReplicaOnlineException
 * 接收LeaderAndIsr请求的副本就是该分区分配的存活的副本。
 * 一旦新的leader成功注册到zk，就更新allLeaders缓存。





启动broker的时候，调用KafkaServer的startup方法：

![image-20201130161112504](kafka.assets/image-20201130161112504.png)



![image-20201130161848931](kafka.assets/image-20201130161848931.png)

![image-20201130163658760](kafka.assets/image-20201130163658760.png)

![image-20201130163806840](kafka.assets/image-20201130163806840.png)



ControllerEventThread的run方法调用这里的doWork方法：

![image-20201130160849604](kafka.assets/image-20201130160849604.png)



![image-20201130163901806](kafka.assets/image-20201130163901806.png)



控制器对事件的处理：

![image-20201130160806961](kafka.assets/image-20201130160806961.png)



最后一行处理broker失败的事件：

![image-20201130160713999](kafka.assets/image-20201130160713999.png)



此处调用了onReplicasBecomeOffline方法：

![image-20201130160151358](kafka.assets/image-20201130160151358.png)



KafkaController.scala的方法：

```scala
/**
 *  该方法负责标记指定的副本们为下线状态，并进行如下操作：
 * 1. 标记指定主题分区们为下线的。
 * 2. 对所有new/offline分区触发OnlinePartition状态更改操作。
 * 3. 对下线的副本们调用OfflineReplica状态更改操作。
 * 4. 如果没有分区收到影响，则向存活的或关闭中的broker发送UpdateMetadataRequest请求。
 *
 * 此时不需要更新leader/isr缓存信息。交给分区状态机来做。
 */
def onReplicasBecomeOffline(newOfflineReplicas: Set[PartitionAndReplica]): Unit = {
  val (newOfflineReplicasForDeletion, newOfflineReplicasNotForDeletion) =
    newOfflineReplicas.partition(p => topicDeletionManager.isTopicQueuedUpForDeletion(p.topic))
  val partitionsWithoutLeader = controllerContext.partitionLeadershipInfo.filter(partitionAndLeader =>
    !controllerContext.isReplicaOnline(partitionAndLeader._2.leaderAndIsr.leader, partitionAndLeader._1) &&
      !topicDeletionManager.isTopicQueuedUpForDeletion(partitionAndLeader._1.topic)).keySet
  // 对所有leader副本在新下线的副本中的分区触发OfflinePartition状态更改操作。
  partitionStateMachine.handleStateChanges(partitionsWithoutLeader, OfflinePartition)
  // 对新分区或下线分区触发OnlinePartition状态更改操作。
  partitionStateMachine.triggerOnlinePartitionStateChange()
  // 对新下线的副本触发OfflineReplica状态更改操作。
  replicaStateMachine.handleStateChanges(newOfflineReplicasNotForDeletion, OfflineReplica)
  // fail deletion of topics that affected by the offline replicas
  if (newOfflineReplicasForDeletion.nonEmpty) {
    // it is required to mark the respective replicas in TopicDeletionFailed state since the replica cannot be
    // deleted when its log directory is offline. This will prevent the replica from being in TopicDeletionStarted state indefinitely
    // since topic deletion cannot be retried until at least one replica is in TopicDeletionStarted state
    topicDeletionManager.failReplicaDeletion(newOfflineReplicasForDeletion)
  }
```



当分区状态发生改变，则调用该方法进行分区状态的转换：

![image-20201130153521379](kafka.assets/image-20201130153521379.png)



PartitionStateMachine.scala中的方法：

```scala
private def handleStateChange(topic: String, partition: Int, targetState: PartitionState,
                              leaderSelector: PartitionLeaderSelector,
                              callbacks: Callbacks) {
  val topicAndPartition = TopicAndPartition(topic, partition)
  val currState = partitionState.getOrElseUpdate(topicAndPartition, NonExistentPartition)
  val stateChangeLog = stateChangeLogger.withControllerEpoch(controller.epoch)
  try {
    assertValidTransition(topicAndPartition, targetState)
    targetState match {
      case NewPartition =>
        partitionState.put(topicAndPartition, NewPartition)
        val assignedReplicas = controllerContext.partitionReplicaAssignment(topicAndPartition).mkString(",")
        stateChangeLog.trace(s"Changed partition $topicAndPartition state from $currState to $targetState with " +
          s"assigned replicas $assignedReplicas")
        // post: partition has been assigned replicas
      case OnlinePartition =>
        // 获取指定主题分区的分区状态，进行模式匹配
        partitionState(topicAndPartition) match {
            // 如果是新分区
          case NewPartition =>
            // 初始化新分区的leader和isr
            initializeLeaderAndIsrForPartition(topicAndPartition)
            // 如果是分区下线
          case OfflinePartition =>
            // 选举该分区的新的leader和isr，并在控制器上下文更新该信息，并在该分区存活副本所在的broker上更新该信息。
            electLeaderForPartition(topic, partition, leaderSelector)
            // 如果需要重新选举
          case OnlinePartition =>
            // 选举该分区的新的leader和isr，并在控制器上下文更新该信息，并在该分区存活副本所在的broker上更新该信息。
            electLeaderForPartition(topic, partition, leaderSelector)
          case _ => // should never come here since illegal previous states are checked above
        }
        partitionState.put(topicAndPartition, OnlinePartition)
        val leader = controllerContext.partitionLeadershipInfo(topicAndPartition).leaderAndIsr.leader
        stateChangeLog.trace(s"Changed partition $topicAndPartition from $currState to $targetState with leader $leader")
         // post: partition has a leader
      case OfflinePartition =>
        // should be called when the leader for a partition is no longer alive
        stateChangeLog.trace(s"Changed partition $topicAndPartition state from $currState to $targetState")
        partitionState.put(topicAndPartition, OfflinePartition)
        // post: partition has no alive leader
      case NonExistentPartition =>
        stateChangeLogger.trace(s"Changed partition $topicAndPartition state from $currState to $targetState")
        partitionState.put(topicAndPartition, NonExistentPartition)
        // post: partition state is deleted from all brokers and zookeeper
    }
  } catch {
    case t: Throwable =>
      stateChangeLog.error(s"Initiated state change for partition $topicAndPartition from $currState to $targetState failed",
        t)
  }
}
```





PartitionStateMachine.scala中的方法：

```scala
/**
 * Invoked on the OfflinePartition,OnlinePartition->OnlinePartition state change.
 * 为leader下线的主题分区调用leader选举的API，选举新的leader
 * @param topic               leader下线的主题
 * @param partition           leader下线的分区
 * @param leaderSelector      指定的leader选举器(e.g., offline/reassigned/etc.)
 */
def electLeaderForPartition(topic: String, partition: Int, leaderSelector: PartitionLeaderSelector) {
  // 创建TopicAndPartition对象
  val topicAndPartition = TopicAndPartition(topic, partition)
  val stateChangeLog = stateChangeLogger.withControllerEpoch(controller.epoch)
  // handle leader election for the partitions whose leader is no longer alive
  stateChangeLog.trace(s"Started leader election for partition $topicAndPartition")
  try {
    var zookeeperPathUpdateSucceeded: Boolean = false
    var newLeaderAndIsr: LeaderAndIsr = null
    var replicasForThisPartition: Seq[Int] = Seq.empty[Int]
    while(!zookeeperPathUpdateSucceeded) {
      // 获取当前leader isr和纪元数字
      val currentLeaderIsrAndEpoch = getLeaderIsrAndEpochOrThrowException(topic, partition)
      // leader和isr
      val currentLeaderAndIsr = currentLeaderIsrAndEpoch.leaderAndIsr
      // 纪元数字
      val controllerEpoch = currentLeaderIsrAndEpoch.controllerEpoch
      // 如果纪元数字大于控制器的纪元数字，则抛异常
      if (controllerEpoch > controller.epoch) {
        val failMsg = s"Aborted leader election for partition $topicAndPartition since the LeaderAndIsr path was " +
          s"already written by another controller. This probably means that the current controller $controllerId went " +
          s"through a soft failure and another controller was elected with epoch $controllerEpoch."
        stateChangeLog.error(failMsg)
        throw new StateChangeFailedException(stateChangeLog.messageWithPrefix(failMsg))
      }
      // 选举新的leader或抛异常
      val (leaderAndIsr, replicas) = leaderSelector.selectLeader(topicAndPartition, currentLeaderAndIsr)
      val (updateSucceeded, newVersion) = ReplicationUtils.updateLeaderAndIsr(zkUtils, topic, partition,
        leaderAndIsr, controller.epoch, currentLeaderAndIsr.zkVersion)
      newLeaderAndIsr = leaderAndIsr.withZkVersion(newVersion)
      zookeeperPathUpdateSucceeded = updateSucceeded
      replicasForThisPartition = replicas
    }
    // 创建新的LeaderAndIsrControllerEpoch对象
    val newLeaderIsrAndControllerEpoch = LeaderIsrAndControllerEpoch(newLeaderAndIsr, controller.epoch)
    // 在控制器上下文更新leader缓存信息
    controllerContext.partitionLeadershipInfo.put(TopicAndPartition(topic, partition), newLeaderIsrAndControllerEpoch)
    stateChangeLog.trace(s"Elected leader ${newLeaderAndIsr.leader} for Offline partition $topicAndPartition")
    val replicas = controllerContext.partitionReplicaAssignment(TopicAndPartition(topic, partition))
    // 在broker上更新leader和isr信息缓存
    brokerRequestBatch.addLeaderAndIsrRequestForBrokers(replicasForThisPartition, topic, partition,
      newLeaderIsrAndControllerEpoch, replicas)
  } catch {
    case _: LeaderElectionNotNeededException => // swallow
    case nroe: NoReplicaOnlineException => throw nroe
    case sce: Throwable =>
      val failMsg = s"Encountered error while electing leader for partition $topicAndPartition due to: ${sce.getMessage}"
      stateChangeLog.error(failMsg)
      throw new StateChangeFailedException(stateChangeLog.messageWithPrefix(failMsg), sce)
  }
  debug(s"After leader election, leader cache for $topicAndPartition is updated to ${controllerContext.partitionLeadershipInfo(topicAndPartition)}")
}
```





调用选举leader的方法：

![image-20201130151342418](kafka.assets/image-20201130151342418.png)



```scala
/**
 * 选择新的分区leader，新的isr和接收LeaderAndIsrRequest的副本：
 * 1. 如果isr中至少有一个broker存活，则从存活的isr中选择一个broker作为新的leader，存活的isr作为新的isr。
 * 2. 否则，如果没有设置不干净的leader选举，则抛异常NoReplicaOnlineException
 * 3. 否则，就从OSR中选择一个存活的broker作为新的leader，剩下的就是新的isr。
 * 4. 如果分区没有副本存活，则抛异常：NoReplicaOnlineException
 * 接收LeaderAndIsr请求的副本就是该分区分配的存活的副本。
 * 一旦新的leader成功注册到zk，就更新allLeaders缓存。
 */
 def selectLeader(topicAndPartition: TopicAndPartition, currentLeaderAndIsr: LeaderAndIsr): (LeaderAndIsr, Seq[Int]) = {
  // 从集群控制器上下文查询该主题分区的副本分配信息，进行模式匹配
  controllerContext.partitionReplicaAssignment.get(topicAndPartition) match {
      // 如果找到了该分区分配的副本信息
    case Some(assignedReplicas) =>
      // 该主题分区存活的副本集合
      val liveAssignedReplicas = assignedReplicas.filter(r => controllerContext.isReplicaOnline(r, topicAndPartition))
      // 该主题分区存活的broker和ISR集合
      val liveBrokersInIsr = currentLeaderAndIsr.isr.filter(r => controllerContext.isReplicaOnline(r, topicAndPartition))
      // 新的leader
      val newLeaderAndIsr =
      // 如果isr的broker集合是空的
        if (liveBrokersInIsr.isEmpty) {
          // 如果禁用了该主题分区的不干净leader选举，抛异常
          if (!LogConfig.fromProps(config.originals, AdminUtils.fetchEntityConfig(controllerContext.zkUtils,
            ConfigType.Topic, topicAndPartition.topic)).uncleanLeaderElectionEnable) {
            throw new NoReplicaOnlineException(
              s"No replica in ISR for partition $topicAndPartition is alive. Live brokers are: [${controllerContext.liveBrokerIds}], " +
                s"ISR brokers are: [${currentLeaderAndIsr.isr.mkString(",")}]"
            )
          }
          debug(s"No broker in ISR is alive for $topicAndPartition. Pick the leader from the alive assigned " +
            s"replicas: ${liveAssignedReplicas.mkString(",")}")
          // 如果存活的副本集合是空的，则抛异常：没有存活的副本
          if (liveAssignedReplicas.isEmpty) {
            throw new NoReplicaOnlineException(s"No replica for partition $topicAndPartition is alive. Live " +
              s"brokers are: [${controllerContext.liveBrokerIds}]. Assigned replicas are: [$assignedReplicas].")
          } else {
            // 标记应该开始不干净leader选举
            controllerContext.stats.uncleanLeaderElectionRate.mark()
            // 从存活的副本中，即OSR中，找到第一个broker，作为新的leader
            val newLeader = liveAssignedReplicas.head
            warn(s"No broker in ISR is alive for $topicAndPartition. Elect leader $newLeader from live " +
              s"brokers ${liveAssignedReplicas.mkString(",")}. There's potential data loss.")
            // 创建LeaderAndIsr请求信息，此时leader就是新的leader，isr只包含leader。
            currentLeaderAndIsr.newLeaderAndIsr(newLeader, List(newLeader))
          }
        } else {
          // 如果isr中有存活的副本，则找出存活副本的broker集合
          val liveReplicasInIsr = liveAssignedReplicas.filter(r => liveBrokersInIsr.contains(r))
          // 获取该集合中第一个副本为新的leader
          val newLeader = liveReplicasInIsr.head
          debug(s"Some broker in ISR is alive for $topicAndPartition. Select $newLeader from ISR " +
            s"${liveBrokersInIsr.mkString(",")} to be the leader.")
          // 创建LeaderAndIsr请求对象，leader就是新的leader，isr就是isr集合
          currentLeaderAndIsr.newLeaderAndIsr(newLeader, liveBrokersInIsr)
        }
      info(s"Selected new leader and ISR $newLeaderAndIsr for offline partition $topicAndPartition")
      (newLeaderAndIsr, liveAssignedReplicas)
      // 如果没有找到该分区的副本信息，抛异常：没有存活的副本信息。
    case None =>
      throw new NoReplicaOnlineException(s"Partition $topicAndPartition doesn't have replicas assigned to it")
  }
}
```





### 问题6

**一致性有点懵**

ISR

OSR

HW

LEO



分区副本分为ISR，OSR。

判断一个副本属于ISR还是OSR，根据：`replica.lag.time.max.ms`，默认10s。

当leader接收了消息，则follower从leader拉取消息进行同步。

拉取消息的同时更新follower的LEO和HW。





两套LEO：

1. 一套LEO保存在Follower副本所在Broker的副本管理器中；
2. 另一套LEO保存在Leader副本所在Broker的副本管理器中。Leader副本机器上保存了所有的follower副本的LEO。

Kafka使用前者帮助Follower副本更新其HW值；利用后者帮助Leader副本更新其HW。





Follower副本不停地向Leader副本所在的broker发送FETCH请求，获取消息后写入自己的日志中进行备份。

Follower副本的LEO值就是日志的LEO值，每当新写入一条消息，LEO值就会被更新。

一旦Leader接收到Follower发送的FETCH请求，它先从Log中读取相应的数据，给Follower返回数据前，先更新Follower的LEO。



Follower更新HW发生在其更新LEO之后，一旦Follower向Log写完数据，尝试更新自己的HW值。

比较当前LEO值与FETCH响应中Leader的HW值，取两者的小者作为新的HW值。



Leader写Log时自动更新自己的LEO值。



尝试更新HW值：

当Kafka broker都正常工作时，分区HW值的**更新时机**有两个：

1. Leader处理PRODUCE请求时
2. Leader处理FETCH请求时



当尝试确定分区HW时，它会选出所有满足条件的副本，比较它们的LEO(包括Leader的LEO)，并选择最小的LEO值作为HW值。

**leader中的hw值是所有分区副本中最小的。**而该值又同步给了各个副本。



HW值是不能读到同步消息的最小值。客户端可以消费的消息偏移量是HW以下。





### 问题7

**更新数据库后，发消息到mq,mq接收到消息后返回ack,返回ack时出现网络故障，程序认为mq消息发送失败，数据库就回滚了。这种场景如何解决？**



重试，事务加幂等



重试失败的事务

事务负责发送消息的原子性

幂等负责解决消息重发时的重复问题



如果消息发送失败，则在下面处理：



```java
producer.send(message, new Callback() {
    @Override
    public void onCompletion(RecordMetadata metadata, Exception exception) {
        // 处理消息发送失败逻辑
    }
});
```



要么重试，要么回滚数据库信息。一般不会直接回滚数据库信息。可以尝试将消息写到另一个不同的事务补偿主题。

然后由专门的事务补偿程序进行处理。





### 问题8

**Kafka什么时候用zookeeper，什么时候可以不用zookeeper，看视频有点乱。**



首先，Apache Kafka v1.0.2中不再使用zk存储消费组的偏移量信息了，因为zk不适合高并发场景存储偏移量，而是迁移到了`__consumer_offsets`主题中。

其次，Apache Kafka都需要zk存储元数据：

1. Controller选举

   控制器负责维护所有分区的leader-follower关系。如果有节点宕机，控制器触发新的leader选举。如果controller所在broker宕机，则使用zk的分布式锁选举新的controller。

2. 主题配置

   所有主题列表，每个主题的分区数，每个分区副本的位置，覆盖主题配置的配置信息以及leader偏向的节点。

3. 维护ACL

4. 集群成员信息维护

   zk维护所有存活的broker信息。

5. Kafka消费组信息维护





## 5. 知识点扩展



1. Kafka是怎么设计的？

   Kafka 将消息以 topic 为单位进行管理。

   向Kafka topic发布消息的程序成为producer。

   订阅topics并消费消息的程序成为consumer。

   Kafka以集群的方式运行，可以由一个或多个服务组成，每个服务叫做broker。

   producers 通过网络将消息发送到Kafka集群，集群向消费者提供消息。

   producer、consumer以及Kafka都可以横向扩展。

 

2. 数据传输的事务语义有哪三种？

   数据传输的事务定义通常有以下三种级别：

   （1）最多一次: 消息不会被重复发送，最多被传输一次，但也有可能一次不传输

   （2）最少一次: 消息不会被漏发送，最少被传输一次，但也有可能被重复传输.

   （3）精确的一次（Exactly once）: 不会漏传输也不会重复传输,每个消息都传输被一次而仅仅被传输一次，Kafka支持“仅一次”语义。

 

3. Kafka判断一个节点是否还活着有那两个条件？

   （1）节点必须可以维护和ZooKeeper的连接，Zookeeper通过心跳机制检查每个节点的连接。

   （2）如果节点是个 follower，必须能及时的同步leader的写操作，延时不能太久。

 

4. producer是否直接将数据发送到broker的leader(主节点)？

   producer直接将数据发送到broker的leader(主节点)，不需要在多个节点进行分发，为了帮助producer做到这点，所有的Kafka节点都可以及时的告知：哪些节点是活动的，目标topic 目标分区的leader在哪。这样producer就可以直接将消息发送到目的地了。

   这些元数据保存于zookeeper。

 

5. Kafa consumer 是否可以消费指定分区消息？

   Kafa consumer消费消息时，向broker发出"fetch"请求去消费特定分区的消息，consumer指定消息在日志中的偏移量（offset），就可以消费从这个位置开始的消息，customer 拥有offset的控制权，可以向后回滚去重新消费之前的消息。

   当采用手动消费管理的时候是可以手动指定要消费的消息的分区的。

 

6. Kafka消息是采用Pull模式，还是Push模式？

   Kafka 遵循了一种大部分消息系统共同的传统的设计：producer将消息推送到broker，consumer从broker拉取消息

    一些消息系统比如 Scribe 和 Apache Flume 采用了push模式，将消息推送到下游的consumer。

   这样做有好处也有坏处：由broker决定消息推送的速率，对于不同消费速率的consumer就不太好处理了。消息系统都致力于让consumer以最大的速率最快速的消费消息，但push模式下，当broker推送的速率远大于consumer消费的速率时，consumer有可能宕机。最终Kafka还是选取了传统的pull模式。

    Pull模式的另外一个好处是consumer可以自主决定是否批量的从broker拉取数据。Push模式必须在不知道下游consumer消费能力和消费策略的情况下决定是立即推送每条消息还是缓存之后批量推送。如果为了避免consumer崩溃而采用较低的推送速率，将可能导致一次只推送较少的消息而造成浪费。Pull模式下，consumer就可以根据自己的消费能力去决定这些策略

    Pull 有个缺点是，如果broker没有可供消费的消息，将导致consumer不断在循环中轮询，直到新消息到达。为了避免这点，Kafka有个参数可以让consumer阻塞知道新消息到达(当然也可以阻塞知道消息的数量达到某个特定的量这样就可以批量发。

 

 

7. Kafka 存储在硬盘上的消息格式是什么？

    消息由一个固定长度的头部和可变长度的字节数组组成。头部包含了一个版本号和 CRC32校验码。

    消息长度: 4 bytes (value: 1+4+n)

   版本号: 1 byte

   CRC 校验码: 4 bytes

   具体的消息: n bytes

 

8. Kafka高效文件存储设计特点：

    (1).Kafka把topic中一个parition大文件分成多个小文件段，通过多个小文件段，就容易定期清除或删除已经消费完文件，减少磁盘占用。

   (2).通过索引信息可以快速定位message和确定response的最大大小。

   (3).通过index元数据全部映射到memory，可以避免segment file的IO磁盘操作。

   (4).通过索引文件稀疏存储，可以大幅降低index文件元数据占用空间大小。

 

9. Kafka与传统消息系统之间有三个关键区别

   (1).Kafka 持久化日志，这些日志可以被重复读取和无限期保留，默认7天保留。

   (2).Kafka 是一个分布式系统：它以集群的方式运行，可以灵活伸缩，在内部通过复制数据提升容错能力和高可用性

   (3).Kafka 支持实时的流式处理

 

10. Kafka创建Topic时如何将分区放置到不同的Broker中

    副本因子不能大于Broker的个数；

    第一个分区（编号为0）的第一个副本放置位置是随机从brokerList选择的；

    其他分区的第一个副本放置位置相对于第0个分区依次往后移。也就是如果我们有5个Broker，5个分区，假设第一个分区放在第四个Broker上，那么第二个分区将会放在第五个 Broker上；第三个分区将会放在第一个Broker上；第四个分区将会放在第二个Broker 上，依次类推；

    剩余的副本相对于第一个副本放置位置其实是由nextReplicaShift决定的，而这个数也是随机产生的

 

11. Kafka新建的分区会在哪个目录下创建

    在启动 Kafka 集群之前，我们需要配置好log.dirs参数，其值是Kafka数据的存放目录，这个参数可以配置多个目录，目录之间使用逗号分隔，通常这些目录是分布在不同的磁盘上用于提高读写性能。

     当然也可以配置log.dir参数，含义一样。只需要设置其中一个即可。

    如果log.dirs参数只配置了一个目录，那么分配到各个Broker上的分区肯定只能在这个目录下创建文件夹用于存放数据。

     如果log.dirs参数配置了多个目录，Kafka会在含有分区目录最少的文件夹中创建新的分区目录，分区目录名为Topic名+分区ID。注意，是分区文件夹总数最少的目录，而不是磁盘使用量最少的目录！也就是说，如果你给log.dirs参数新增了一个新的磁盘，新的分区目录肯定是先在这个新的磁盘上创建直到这个新的磁盘目录拥有的分区目录不是最少为止。

 

12. partition的数据如何保存到硬盘

    topic中的多个partition以文件夹的形式保存到broker，每个分区序号从0递增，且消息有序

    Partition文件下有多个segment（xxx.index，xxx.log）

    segment文件里的大小和配置文件大小一致可以根据要求修改默认为1g

    如果大小大于1g时，以第一条消息的偏移量命名，滚动新segment文件。

 

13. kafka 的 ack 机制

    request.required.acks 有三个值 0 1 -1

     0:生产者不会等待broker的ack，这个延迟最低但是存储的保证最弱，当server挂掉的时候就会丢数据。

    1：服务端会等待ack值leader副本确认接收到消息后发送ack；但是如果leader挂掉后他不确保是否复制完成新leader也会导致数据丢失

    -1：服务端会等所有的ISR follower的副本受到数据后才会收到leader发出的ack，这样数据不会丢失。也可以指定最小确认副本的个数。

 

14. Kafka 的消费者如何消费数据

    消费者每次消费数据的时候，消费者都会记录消费的物理偏移量（offset）的位置，等到下次消费时，他会接着上次位置继续消费。偏移量存储于Kafka特定主题：`__consumer_offsets`中。

 

15. 消费者负载均衡策略

    同一个消费组中的消费者在订阅消息的时候，按照一定的规则进行再平衡。

    一个主题分区只能对应同一个消费组中的一个消费者。

    同一个消费组中的消费者如果多于主题的分区数，则有消费者空闲。

 

16. 数据有序

    一个消费者组里它的内部各个消费者是有序的

    消费组与消费组之间是无序的

    生产者发送的消息在broker端指定消息偏移量。消息在存储到日志文件的时候，通过顺序写保证消息的有序，保证磁盘的高校读写。

    Kakfa保证在同一个主题的同一个分区消息的顺序，不能保证同一个主题不同分区之间的消息有序。

 

17. kafaka 生产数据时数据的分组策略

    生产者如果不指定消息的key，则客户端通过轮询的方式选择该消息所属的分区。

    生产者如果指定了key，则以key的hashCode对分区数量取模决定该消息所属的分区。

    生产者也可以直接指定该消息所属的分区，此时忽略消息的key。



