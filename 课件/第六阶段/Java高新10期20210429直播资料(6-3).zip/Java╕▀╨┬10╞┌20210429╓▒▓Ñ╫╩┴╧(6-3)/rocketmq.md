

# RocketMQ

## 一、内容回顾

解耦  /  异步  /  流量削峰填谷

架构：

![image-20210303175023702](rocketmq.assets/image-20210303175023702.png)



Kafka中，横向扩展，主题的横向扩展   分区

RocketMQ的横向扩展，主题的横向扩展。 messageQueue

高可用：RocketMQ：主从结构

​               Kafka：互为主备

RocketMQ：broker级别的主从之间，数据是完全一致的：一台broker和其他几台broker



Kafka：互为主备：broker1，broker2：在broker级别，数据不一定一样。主题分区级别，主从关系



## 

消息存储：



![image-20210303175054420](rocketmq.assets/image-20210303175054420.png)



生产者：

![image-20210303175110860](rocketmq.assets/image-20210303175110860.png)



两种消费模式：

1. 集群消费
   一个主题多个消费者共同消费，需要避免重复消费。
2. 广播消费
   所有消费者都消费订阅主题的全量消息。



Kafka中的三种再平衡策略：RangeAssignor，RoundRobinAssignor，StickyAssignor

RocketMQ：

内置六种再平衡策略，用于将订阅主题的各个MessageQueue分配给同一个消费组中的消费者。

一个MessageQueue对应一个消费者

一个消费者对应多个MessageQueue

避免重复消费。



消费：

-r    -w

![image-20210303175205031](rocketmq.assets/image-20210303175205031.png)



横向扩展：

![image-20210303175215587](rocketmq.assets/image-20210303175215587.png)









## 二、练习题

### 第一部分

1. 下面属于RocketMQ架构中的角色的是：ABCD

   A．Producer

   B．Consumer

   C．Broker

   D．NameServer

   E．Zookeeper

 

2. 下面属于RocketMQ特性的是：ABCEFGHIJK

   A．订阅与发布

   B．消息有序

   C．消息过滤

   D．RocketMQ“仅一次”语义

   E．回溯消费

   F．事务消息

   G．定时消息

   H．消息重试

   I．消息重投

   J．流控

   K．死信队列

 

3. 关于RocketMQ的消息推拉说法正确的是：ABCD

   A．RocketMQ支持消息推拉两种模式

   B．RocketMQ的推消息本质上是拉消息   长轮询

   C．Push模式实时性高

   D．Pull模式由客户端控制消费的频率

 

4. RocketMQ角色和表述属于正确的是：ABE

   A．RocketMQ的消息模型包括生产者、消费者、Broker，其中每个Broker可以存储多个主题的消息，每个主题的消息可以分片存储于不同的Broker上。MessageQueue是主题分片的最小单元，多个生产者可以属于同一个生产组，多个消费者可以属于同一个消费组。

   B．生产组中的生产者发送同一类型的消息，且发送逻辑一致。如果发送的是事务消息，原生产者崩溃之后，Broker可以联系同一生产组的其他生产者实例提交或回滚。

   C．同一消费组中消费同一类消息且消费逻辑可以不一致。消费者也不需要订阅完全相同的主题。

   D．广播消费表示一条消息可以被多个消费者消费，但是同一消费组的消费者只能被一个消费者消费一次。

   E．集群消费表示一个消费组中的消费者平摊同一个主题中的消息。

 

### 第二部分

 

1. 消息发送的返回状态包括：ABD

   A． FLUSH_DISK_TIMEOUT

   B． FLUSH_SLAVE_TIMEOUT

   C． FLUSH_NOT_AVAILABLE

   D．SEND_OK

 

2. 关于提升生产者写入性能的说法正确的是：ABCD

   A．  可以采用Oneway方式发送

   B．  可以增加生产者提高消息发送的并发量

   C．  推荐使用EXT4文件系统，IO调度算法使用deadline算法

   D． 顺序写CommitLog无论是HDD还是SSD磁盘，都能保持较高的写入性能

 

3. 关于消息存储，下列说法正确的是：ABCE

   A． 消息真正的物理存储文件是CommitLog，ConsumeQueue是消息的逻辑队列

   B． 目前的高性能磁盘顺序写超过了一般网卡的传输速度。

   C． ConsumeQueue保存了指定主题下队列消息在CommitLog中的起始物理偏移量，消息大小以及消息标签的HashCode值

   D．CommitLog在滚动的时候，每个新文件的名称就是该新文件中第一条消息的时间戳

   E． IndexFile文件名fileName是以创建时的时间戳命名的。

 

4. 下面关于零拷贝原理说法正确的是：ACD

   A.  RocketMQ既使用了HeapByteBuffer，也使用了DirectByteBuffer

   B.   Java中有HeapByteBuffer和DirectByteBuffer两个类对应。

   C.  HeapByteBuffer的数据维护在JVM堆空间，写入速度快，回收方便

   D.  DirectByteBuffer数据维护在堆外内存，可以省略数据从JVM拷贝到系统内存的步骤。

   E.   操作系统不能直接操作JVM内存。

 

5. 关于消息重试，下列说法正确的是：ADE

   A.  消息的重试只针对集群消费方式，对广播方式无效

   B.   RocketMQ的消息队列默认允许每条消息最多重试18次，时间依次延长。

   C.  在消息重试的时候，需要客户端维护消息的MessageID，否则会引起混乱

   D.  在客户端需要重试的场合，可以返回Null，可以抛异常，对于并发消费，推荐使用ConsumeConcurrentlyStatus.RECONSUME_LATER。

   E.   顺序消息在消费失败后，RocketMQ会不断进行消息重试，可能引起应用阻塞。

 

### 第三部分

1. NameServer的设计特点包括：ABD

   A． NameServer相互独立，彼此没有通信，单台NameServer宕机不影响其他NameServer。

   B． NameServer不主动推消息

   C． Broker默认每隔10s与NameServer发送心跳包，保持活跃状态。

   D．Consumer随机与一个NameServer建立长连接，如果NameServer断开，则从NameServer列表中查找下一个NameServer进行连接。

 

2. 关于故障对消息的影响，正确的是：AD

   A.  Broker正常关闭，启动，如果是同步发送，不会引起消息的丢失。

   B.   Broker异常宕机，然后启动，不会引起消息的丢失。

   C.  磁盘损坏，一定会造成消息丢失。

   D.  机器损坏，但能马上恢复供电，如果MASTER、SLAVE都配置为SYNC_FLUSH，可以不丢失消息。

 

3. 关于消费者说法，正确的是：BCD

   A.  RocketMQ无法避免消息重复。

   B.   可以提高消费者数量达到加快消费的目的。

   C.  可以使用批量方式消费，加快消费速度。

   D.  可以跳过不重要的消息，提高消费速度。

 

### 第四部分

1. 动态增减NameServer机器，下列说法正确的是：ABCD

   A.  可以在客户端通过setNamesrvAddr的方式扩展Namesrv

   B.   可以在Java启动参数中设置，扩展Namesrv

   C.  可以通过Linux环境变量，扩展Namesrv

   D.  可以通过HTTP服务，扩展Namesrv

 

2. 新增一个主题的消费组，无法消费历史消息，该如何解决？BC

   A.  setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_LAST_OFFSET)

   B.   setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET)

   C.  setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_TIMESTAMP)

   D. consumer.setConsumeTimeout(System.currentTimeMillis() - 3600000);

 

3. 关于刷盘机制，下列说法正确的是：ABCD

   A.  RocketMQ所有消息都是持久化的

   B.   同步刷盘中，消息首先写入PageCache，然后线程等待，通知刷盘线程刷盘，前端线程等待。

   C.  异步刷盘中，消息写入到PageCache，前端线程返回给生产者。

   D.  如果内存不足，则尝试丢弃干净的Page，如果还内存不足，则OS尝试刷盘部分脏页。



### 第五部分

1. 关于死信消息的特性，正确的是：BCE

   A.  死信不会被消费者消费

   B.   死信有效期与正常消息相同，均为3天，3天后被自动删除。

   C.  一个死信队列对应一个GroupId

   D.  如果GroupId没有产生死信消息，则RocketMQ也要为其创建相应的死信队列。

   E.   死信队列保存了对应的GroupId的所有死信，不管属于哪个主题。

 

2. 关于定时消息，下列说法正确的是：ADE

   A.   messageDelayLevel有18个级别

   B.   messageDelayLevel是主题的属性

   C.   messageDelayLevel的值可以小于0

   D.   messageDelayLevel的值可以大于18

   E.   定时消息暂存于SCHEDULE_TOPIC_XXXX主题中。

 

3. 下列关于事务消息说法正确的是：BCD

   A.  生产者向RocketMQ发送“待确认”消息，订阅了该主题的消费者即可看到该消息

   B.   生产者发送完待确认消息，收到RocketMQ的确认之后，执行本地事务逻辑。

   C.  生产者根据本地事务逻辑的执行结果，提交或回滚事务消息

   D.  Broker可以对生产者的本地事务结果发起“回查”作为事务的补偿手段。





## 三、实战题

基于RocketMQ设计秒杀。

要求：

1. 秒杀商品LagouPhone，数量100个。

2. 秒杀商品不能超卖。

3. 抢购链接隐藏

4. Nginx+Redis+RocketMQ+Tomcat+MySQL

 

提示：



![image-20210115211146505](rocketmq.assets/image-20210115211146505.png)

上图为下单流程：

![image-20210115211314825](rocketmq.assets/image-20210115211314825.png)

上图为MQ消息的处理流程：



如果是正常购买，直接下单即可，insert一条记录到数据库

秒杀：有库存限制：

如果下单，insert一条记录到订单库，update一下库存信息

MQ解耦，将**分布式事务**进行分解，异步update库存信息（数据库：不是redis中的库存信息）



延迟支付：

![image-20210115214232970](rocketmq.assets/image-20210115214232970.png)



![image-20210115214241829](rocketmq.assets/image-20210115214241829.png)





![table](rocketmq.assets/table.png)





```sql
-- 创建数据库
create database db_flashsale;

use db_flashsale;

create table `tb_order` (
	`order_id` varchar(255) not null,
	`user_id` varchar(255) default null,
	`order_status` char(255) default null,
	`content` varchar(255) default null,
	primary key (`order_id`)
);
```



安装redis：

```shell
yum install wget -y
wget https://download.redis.io/releases/redis-5.0.8.tar.gz
tar -zxf redis-5.0.8.tar.gz
yum install gcc -y
cd redis-5.0.8
make && make install
cd /usr/local/bin/
cp ~/redis-5.0.8/redis.conf .
redis-server redis.conf
```



node1操作：

```shell
mqnamesrv
```



node2操作：

```shell
mqnamesrv
```



启动broker：

```shell
[root@node1 ~]# mqbroker -n "node1:9876;node2:9876" -c /opt/rocketmq-all-4.5.1-bin-release/conf/2m-2s-sync/broker-a.properties
[root@node2 ~]# mqbroker -n "node1:9876;node2:9876" -c /opt/rocketmq-all-4.5.1-bin-release/conf/2m-2s-sync/broker-b.properties
[root@node3 ~]# mqbroker -n "node1:9876;node2:9876" -c /opt/rocketmq-all-4.5.1-bin-release/conf/2m-2s-sync/broker-a-s.properties
[root@node4 ~]# mqbroker -n "node1:9876;node2:9876" -c /opt/rocketmq-all-4.5.1-bin-release/conf/2m-2s-sync/broker-b-s.properties
```





## 四、疑难解答



### 1. 那个读队列和写队列是怎么理解的,一个读队列和一个写队列加起来对应一个MessageQueue吗,读队列和写队列在物理上是分开存储的吗

读队列和写队列的设置只是与生产者和消费者相关。

生产者对应写队列

消费者对应读队列。

**实际上都是MessageQueue**，只不过通过读队列和写队列指定了生产者将消息索引放到**几个MQ中**，消费者从几个MQ中读取索引消费消息。



正常情况下读队列和写队列个数一样，在主题扩缩容的时候会不一样。



读队列写队列的个数调整用于主题的**平滑扩缩容**。



当需要扩展主题的时候，需要首先调大读队列的值，此时再平衡给消费者重新分配MQ给各个消费者。

等再平衡结束，再调大写队列的值，让读队列个数等于写队列个数。

此时，主题扩展完成。



当需要收缩主题的时候，需要首先调小写队列的值，让生产者向指定个数的主题MQ写消息索引。等消费者将写队列个数覆盖不到的MQ中消息消费结束，就调小读队列的值，让读队列的值等于写队列的值。

此时，主题收缩完成。



### 2. broker是通过什么进行sql92过滤的,我看consumequeue并没有保存任何关于userProperty的字段信息,是直接遍历所有消息的userProperty吗



每次拉取消息，对每条消息使用SQL92表达式进行过滤。

由于是消息属性，需要解析出消息的所有属性。

为了提升效率，使用功能了布隆过滤器。





SQL92方式进行消息的过滤，仅对PUSH的消费者有效。

通过rocketmq-filter模块进行处理。



broker.properties文件中添加：`enablePropertyFilter=true`



创建主题：

```shell
mqadmin updateTopic -b node1:10911 -n "node1:9876;node2:9876" -r 2 -w 2 -t topic_demo_01
mqadmin updateTopic -b node3:10911 -n "node1:9876;node2:9876" -r 3 -w 3 -t topic_demo_01
```



生产者：

```java
DefaultMQProducer producer = new DefaultMQProducer("pro_1");
producer.setNamesrvAddr("node1:9876;node2:9876");
producer.start();
for (int i = 0; i < 100; i++) {
    Message message = new Message();
    message.setTopic("topic_demo_01");
    message.putUserProperty("keya", "valuea" + (i % 5));
    message.setBody(("hello lagou - " + i).getBytes());
    producer.send(message);
    producer.send(message, new SendCallback() {
        @Override
        public void onSuccess(SendResult sendResult) {
            System.out.println(sendResult.getSendStatus());
        }
        @Override
        public void onException(Throwable throwable) {
            System.err.println(throwable.getLocalizedMessage());
        }
    });
}
```



消费者的使用：

```java
DefaultMQPushConsumer consumer = new DefaultMQPushConsumer("sql92_consumer_07");
consumer.setNamesrvAddr("node1:9876;node2:9876");
consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
//  consumer.subscribe("topic_demo_01", MessageSelector.bySql("keya = 'valuea2'"));
consumer.subscribe("topic_demo_01", MessageSelector.bySql("keya in ('valuea1', 'valuea3')"));
consumer.setMessageListener(
        (MessageListenerConcurrently) (list, consumeConcurrentlyContext) -> {
            list.forEach(messageExt ->
                System.out.println(
                        messageExt.getTopic() + "\t"
                                + messageExt.getProperty("keya") + "\t"
                                + messageExt.getQueueId() + "\t"
                                + messageExt.getQueueOffset() + "\t"
                                + messageExt.getTags() + "\t"
                                + new String(messageExt.getBody())
                )
            );
            // 确认消息
            return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
        });
consumer.start();
```



处理流程：

处理拉取消息的Processor：

![image-20210325172721397](rocketmq.assets/image-20210325172721397.png)



![image-20210325172956638](rocketmq.assets/image-20210325172956638.png)



![image-20210325173257556](rocketmq.assets/image-20210325173257556.png)



build方法调用的是ConsumerFilterManager的build方法，用于将表达式解析为Expression对象：

![image-20210325173342817](rocketmq.assets/image-20210325173342817.png)



解析完，build方法返回，接着，使用consumerFilterData创建表达式消息过滤器：

![image-20210325173212202](rocketmq.assets/image-20210325173212202.png)



获取消息的时候使用表达式消息过滤器过滤找到的消息：

![image-20210325172937536](rocketmq.assets/image-20210325172937536.png)



其中用到了messageFilter

![image-20210325173538405](rocketmq.assets/image-20210325173538405.png)

其中，消息过滤1，标签过滤：

![image-20210325173709085](rocketmq.assets/image-20210325173709085.png)



消息过滤2：

![image-20210325173739993](rocketmq.assets/image-20210325173739993.png)



![image-20210325174112828](rocketmq.assets/image-20210325174112828.png)







### 3. namesever增加了后,broker依然要向所有nameserver注册信息,感觉也没有做到写扩展(因为它每个节点都要保存全量信息)



AP

CP

NameServer只保留元数据，不是业务消息。NameServer是作为注册中心来使用的，只需要保证AP即可。

类似于Dubbo中的zookeeper的角色。



### 4. kafka当主题数目过多的时候，会严重影响性能是什么原因，而rocketmq又是怎么做优化做到主题数目过多时，只影响一点点性能



Kafka每个分片的副本在一个文件夹中，该文件夹中包括Log文件，索引文件和时间戳索引文件。

每个Kafka的Broker上管理多个主题分区，是多个分立的文件夹。

kafka每个broker上有很多分区，每个分区都需要单独打开很多文件，缓存很多跟主题分区相关的信息。



对于Kafka：

1. 分区越多，服务器端缓存各种数据需要的内存就越大；
2. 分区越多，打开的文件越多，系统开销越大；
3. 分区越多，如果broker宕机，受影响的主题分区Leader切换成本越高。





RocketMQ中，每个Broker上一个Log文件，该Log文件是共享的，MessageQueue对应于主题分片。

每个Broker上的日志文件是一个整体的分片。没有主题分片副本的概念。



对于RocketMQ的共享Log文件：

1. 每次Mmap只能管理1.5-2GB的内存空间
2. 整个Broker上一个Log文件片段是1GB
3. 不需要对不同的主题打开不同的Log文件片段，有利于Mmap维护。
4. 需要打开的文件数变少了，主题数量对系统吞吐量的影响比Kafka要小。



### 5. 看nameserver源码的时候发现有KV配置属性的持久化路径,但是运行了一段时间没有发现该文件的生成,请问下nameserver什么时候会进行信息的持久化



首先，该命令还未使用。。。



![image-20210325181054504](rocketmq.assets/image-20210325181054504.png)



```shell
# 对node1上的namesrv配置命名空间为myspace的hello:world
mqadmin updateKvConfig -k hello -s myspace -v world -n node1:9876
```



在家目录下的namesrv文件夹中存放该配置信息：

![image-20210325180617643](rocketmq.assets/image-20210325180617643.png)



![image-20210325180324441](rocketmq.assets/image-20210325180324441.png)



![image-20210325180408794](rocketmq.assets/image-20210325180408794.png)



持久化KV配置信息到文件：

![image-20210325180436822](rocketmq.assets/image-20210325180436822.png)





### 1. RocketMQ是如何自动创建重试队列和死信队列的？

%RETRY%<消费组名称>

%DLQ%<消费组名称>



我们自己编写的消费者代码：

```java
DefaultMQPushConsumer consumer = new DefaultMQPushConsumer("csm_01");
// 设置命名服务器地址
consumer.setNamesrvAddr("node1:9876");
// 订阅主题
consumer.subscribe("topic_demo_01", "*");
// 设置消息消费模型：集群消费
consumer.setMessageModel(MessageModel.CLUSTERING);
// 设置消息监听器为并发监听器
consumer.setMessageListener(new MessageListenerConcurrently() {
    @Override
    public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
        // 稍后消费
        return ConsumeConcurrentlyStatus.RECONSUME_LATER;
    }
});
// 启动消费者
consumer.start();
```



上面最后一句的start：

![image-20210303151739450](rocketmq.assets/image-20210303151739450.png)



`DefaultMQPushConsumerImpl` 中的 `start` 方法：

![image-20210303151523042](rocketmq.assets/image-20210303151523042.png)



在该方法的CREATE_JUST分支判断中有启动并发消费服务的方法：

```java
// 顺序消费
if (this.getMessageListenerInner() instanceof MessageListenerOrderly) {
    this.consumeOrderly = true;
    this.consumeMessageService =
        new ConsumeMessageOrderlyService(this,
                (MessageListenerOrderly) this.getMessageListenerInner());
// 并发消费
} else if (this.getMessageListenerInner() instanceof MessageListenerConcurrently) {
    this.consumeOrderly = false;
    this.consumeMessageService =
        new ConsumeMessageConcurrentlyService(this,
                (MessageListenerConcurrently) this.getMessageListenerInner());
}
// 对于并发消费，该对象是ConsumeMessageConcurrentlyService类型的
// 启动该对象是ConsumeMessageConcurrentlyService服务
this.consumeMessageService.start();
```



并发消费服务启动后，就开始调度执行清空处理失败消息的任务，该任务会将消费者消费失败的消息<font color=red>**回发**</font>给重试主题或死信主题，看重试次数有没有达到最大重试次数。

调用的方法：`cleanExpireMsg()` 

![image-20210303150908063](rocketmq.assets/image-20210303150908063.png)



在客户端服务中保有处理队列表，它的元素key是消费的哪个messageQueue对象，value是客户端缓存的消息。

即客户端实际上是拉取消息到本地缓存，等待处理。`cleanExpireMsg()` 方法会定期扫描该表中的元素，发现有处理超时的，就<font color=red>**回发**</font>到重试主题或死信主题。

![image-20210303150835913](rocketmq.assets/image-20210303150835913.png)



```java
/**
 * 清空消费失败的消息
 * @param pushConsumer push消费者实例
 */
public void cleanExpiredMsg(DefaultMQPushConsumer pushConsumer) {
    // 如果是顺序消费者，则直接返回，因为顺序消费没有重试次数限制，没有过期的消息要移除的
    if (pushConsumer.getDefaultMQPushConsumerImpl().isConsumeOrderly()) {
        return;
    }
// ......
// <<<<此处省略若干代码>>>>
// ......
        try {
            // 将消息发回重试队列，稍后重试。
            pushConsumer.sendMessageBack(msg, 3);
// ......
// <<<<此处省略若干代码>>>>
// ......
```

调用下面的方法：

![image-20210303150540321](rocketmq.assets/image-20210303150540321.png)



客户端回发消息给broker主题：重试主题或死信主题：

![image-20210303141926981](rocketmq.assets/image-20210303141926981.png)



consumerSendMessageBack方法中创建远程请求命令，

并设置请求的代码为：`CONSUMER_SEND_MSG_BACK`。

![image-20210303153824335](rocketmq.assets/image-20210303153824335.png)



通过通信层将请求发送给Broker：

![image-20210303153949531](rocketmq.assets/image-20210303153949531.png)





broker端Netty接收请求后，调用 `SendMessageProcessor.processRequest(...)` 方法处理请求：

rocketmq-broker模块中的处理器（`SendMessageProcessor`）处理请求流程：



如果是 `CONSUMER_SEND_MSG_BACK` ，表明是<font color=red>**消费者回发**</font>的消息：

![image-20210303142613397](rocketmq.assets/image-20210303142613397.png)



调用 `consumerSendMsgBack(ctx, request)` 方法进行处理

`consumerSendMsgBack(ctx, request)` 方法从发起该请求的消费组名称中创建重试主题名称，并创建该主题

如果达到了最大重试次数，则创建死信主题。

之后将消息存储到CommitLog中。

```java
// ......
// ......
// 通过消费组名称构建重试主题的名称：%RETRY%<消费组名称>
String newTopic = MixAll.getRetryTopic(requestHeader.getGroup());
// 随机数对重试队列个数取模，获取messageQueue的id
int queueIdInt = Math.abs(this.random.nextInt() % 99999999) % subscriptionGroupConfig.getRetryQueueNums();
int topicSysFlag = 0;
if (requestHeader.isUnitMode()) {
    topicSysFlag = TopicSysFlag.buildSysFlag(false, true);
}
// 创建%RETRY%主题
TopicConfig topicConfig = this.brokerController.getTopicConfigManager().createTopicInSendMessageBackMethod(
    newTopic,
    subscriptionGroupConfig.getRetryQueueNums(),
    PermName.PERM_WRITE | PermName.PERM_READ, topicSysFlag);
// ......
// <<<<此处省略若干代码>>>>
// ......
// 如果重试次数大于等于最大重试次数或者重试次数小于0，表示放死信队列
// 并返回
if (msgExt.getReconsumeTimes() >= maxReconsumeTimes
    || delayLevel < 0) {
    // 从消费组名称构建死信主题名称%DLQ%<消费组名称>
    newTopic = MixAll.getDLQTopic(requestHeader.getGroup());
    queueIdInt = Math.abs(this.random.nextInt() % 99999999) % DLQ_NUMS_PER_GROUP;
    // 创建死信主题
    topicConfig = this.brokerController.getTopicConfigManager().createTopicInSendMessageBackMethod(newTopic,
        DLQ_NUMS_PER_GROUP,
        PermName.PERM_WRITE, 0
    );
    if (null == topicConfig) {
        response.setCode(ResponseCode.SYSTEM_ERROR);
        response.setRemark("topic[" + newTopic + "] not exist");
        return response;
    }
}
// ......
// <<<<此处省略若干代码>>>>
// ......
// 将消息放到CommitLog中
PutMessageResult putMessageResult = this.brokerController.getMessageStore().putMessage(msgInner);
```



### 2. RabbitMQ,RocketMQ,Kafka的对比



rabbitmq kafka rocketmq各自概念对比；rabbitmq kafka rocketmq各自功能对比



**RabbitMQ**

RabbitMQ开始是用在电信业务的可靠通信的，也是少有的几款支持AMQP协议的产品之一。

优点：

1. 轻量级，快速，部署使用方便
2. 支持灵活的路由配置。RabbitMQ中，在生产者和队列之间有一个交换器模块。根据配置的路由规则，生产者发送的消息可以发送到不同的队列中。路由规则很灵活，还可以自己实现。
3. RabbitMQ的客户端支持大多数的编程语言。

缺点：

1. 如果有大量消息堆积在队列中，性能会急剧下降
2. RabbitMQ的性能在Kafka和RocketMQ中是最差的，每秒处理几万的消息。如果应用要求高的性能，不要选择RabbitMQ。
3. RabbitMQ是Erlang开发的，功能扩展和二次开发代价很高。



**RocketMQ**

RocketMQ是一个开源的消息队列，使用java实现。借鉴了Kafka的设计并做了很多改进。RocketMQ主要用于有序，事务，流计算，消息推送，日志流处理，binlog分发等场景。经过了历次的双11考验，性能，稳定性可可靠性没的说。

RocketMQ几乎具备了消息队列应该具备的所有特性和功能。

java开发，阅读源代码、扩展、二次开发很方便。

对电商领域的响应延迟做了很多优化。在大多数情况下，响应在毫秒级。如果应用很关注响应时间，可以使用RocketMQ。

性能比RabbitMQ高一个数量级，每秒处理几十万的消息。

缺点：

跟周边系统的整合和兼容不是很好。



**Kafka**

Kafka的可靠性，稳定性和功能特性基本满足大多数的应用场景。

跟周边系统的兼容性是数一数二的，尤其是大数据和流计算领域，几乎所有相关的开源软件都支持Kafka。

Kafka高效，可伸缩，消息持久化。支持分区、副本和容错。



Kafka是Scala和Java开发的，对批处理和异步处理做了大量的设计，因此Kafka可以得到非常高的性能。它的异步消息的发送和接收是三个中最好的，但是跟RocketMQ拉不开数量级，每秒处理几十万的消息。

如果是异步消息，并且开启了压缩，Kafka最终可以达到每秒处理2000w消息的级别。

但是由于是异步的和批处理的，延迟也会高，不适合电商场景。



|                        | RabbitMQ   | RocketMQ                               | Kafka                          |
| ---------------------- | ---------- | -------------------------------------- | ------------------------------ |
| 单机吞吐量             | 1w量级     | 10w量级                                | 10w量级                        |
| 开发语言               | Erlang     | Java                                   | Java和Scala                    |
| 消息延迟               | 微秒       | 毫秒                                   | 毫秒                           |
| 消息丢失               | 可能性很低 | 参数优化后可以0丢失                    | 参数优化后可以0丢失            |
| 消费模式               | 推拉       | 推拉                                   | 拉取                           |
| 主题数量对吞吐量的影响 | \          | 几百上千个主题会对吞吐量有一个小的影响 | 几十上百个主题会极大影响吞吐量 |
| 可用性                 | 高（主从） | 很高（主从）                           | 很高（分布式）                 |



### 3. RocketMQ 偏移量是怎么存储的



对于推送模式，可以设置

对于顺序消费：

```java
return ConsumeOrderlyStatus.SUCCESS;
return ConsumeOrderlyStatus.SUSPEND_CURRENT_QUEUE_A_MOMENT;
return ConsumeOrderlyStatus.COMMIT
return ConsumeOrderlyStatus.ROLLBACK;
```



对于集群消费：

```java
return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
return ConsumeConcurrentlyStatus.RECONSUME_LATER;
```



通过上述处理，不需要对偏移量进行显式的管理。rocketmq建议如果有需求，自己管理偏移量。

偏移量也可以存储于broker上：

对于拉取模式：

```java
package com.lagou.rocketmq.demo;

import org.apache.rocketmq.client.consumer.DefaultMQPullConsumer;
import org.apache.rocketmq.client.consumer.PullResult;
import org.apache.rocketmq.client.exception.MQBrokerException;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.common.message.MessageQueue;
import org.apache.rocketmq.remoting.exception.RemotingException;

import java.util.List;

public class PullConsumer {
    public static void main(String[] args) throws MQClientException, RemotingException, InterruptedException, MQBrokerException {
        DefaultMQPullConsumer consumer = new DefaultMQPullConsumer("pull");

        consumer.setNamesrvAddr("node1:9876;node2:9876");

        consumer.start();

        long beginOffset = consumer.getDefaultMQPullConsumerImpl().fetchConsumeOffset(new MessageQueue("tp_01", "broker-a", 0), true);

        System.out.println(beginOffset);
        PullResult pullResult = consumer.pull(new MessageQueue("tp_01", "broker-a", 0), "*", beginOffset, 10);

        long nextBeginOffset = pullResult.getNextBeginOffset();
        long maxOffset = pullResult.getMaxOffset();

        System.out.println("最大偏移量：" + maxOffset);
        System.out.println("起始偏移量：" + nextBeginOffset);

        List<MessageExt> msgFoundList = pullResult.getMsgFoundList();
        if (msgFoundList != null && msgFoundList.size() > 0) {
            msgFoundList.forEach(messageExt -> {
                System.out.println(
                        messageExt.getTopic() + "\t"
                                + messageExt.getStoreHost() + "\t"
                                + messageExt.getQueueOffset() + "\t"
                                + new String(messageExt.getBody())
                );
            });
        }

        consumer.getDefaultMQPullConsumerImpl().updateConsumeOffsetToBroker(new MessageQueue("tp_01", "broker-a", 0), 500, true);

    }
}
```

推送模式自动保存到broker上。

文件 **`store/config/consumerOffset.json`**中保存。



### 4. 事务消息



中间消息存储于主题 `RQM_SYS_TRANS_HALF_TOPIC` 中。

中间倒次手，如果提交，消息会发送到目标主题，如果回滚，消息不发送。只要目标主题中没有消息，消费者就看不到该消息。



Op如果包含half消息的索引，表示该事务消息提交，如果不包含Half消息的索引，表示该事务消息回滚。

如果没有Op消息，表示当前事务消息是待定状态，不知道该提交还是回滚。



首先，half消息存在的主题：RMQ_SYS_TRANS_HALF_TOPIC

op消息存在的主题：RMQ_SYS_TRANS_OP_HALF_TOPIC



TransactionalMessageServiceImpl中有opQueueMap属性，其中记录了half messageQueue和op messageQueue的对应关系，key是half的messageQueue，value是op的messageQueue



op消息的messageQueue

broker名称就是half消息messageQueue的broker名称

queueId就是half消息messageQueue的queueId

op消息的值就是half消息的偏移量。



比较的时候首先获取RMQ_SYS_TRANS_HALF_TOPIC主题的messageQueue。

遍历messageQueue，根据opQueueMap查找op消息的messageQueue 然后遍历op的messageQueue

判断是否需要回查：

half消息有免疫期，如果在免疫期内，不需要回查消息。 

过了免疫期，看half消息回查的次数，如果达到了15次，就不再回查，直接回滚。

其他的回查。



对于事务状态确定的half消息，将消息发送到真正的主题messageQueue。



同时更新op消息的messageQueue的offset和half消息的messageQueue的offset。



org.apache.rocketmq.broker.transaction.queue.TransactionalMessageServiceImpl类中有这个流程。



### 5. 原本地事务处理时间过长，触发了回查了且回查执行成功，那么原执行本地事务还会接着执行吗？



回查不是执行本地事务，只是确认本地事务的执行是否成功。

执行本地事务一般会有事务执行时间的限制，在该时间内事务没有执行完，事务执行失败。

**回查就是查询该事务的执行结果**，如果执行失败，则回滚事务消息。如果执行成功，则提交事务消息。

事务回查次数为15次，如果执行15次之后还没取到事务状态，则回滚事务消息。



```java
package com.lagou.rocket.demo.producer;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.client.producer.LocalTransactionState;
import org.apache.rocketmq.client.producer.TransactionListener;
import org.apache.rocketmq.client.producer.TransactionMQProducer;
import org.apache.rocketmq.common.message.Message;
import org.apache.rocketmq.common.message.MessageExt;
public class TxProducer {
    public static void main(String[] args) throws MQClientException {
        TransactionListener listener = new TransactionListener() {
            @Override
            public LocalTransactionState executeLocalTransaction(Message
msg, Object arg) {
//
msg) {
// 当发送事务消息prepare(half)成功后，调用该方法执行本地事务 System.out.println("执行本地事务，参数为:" + arg);
    try {
        Thread.sleep(100000);
    } catch (InterruptedException e) {
        e.printStackTrace();
}
    return LocalTransactionState.COMMIT_MESSAGE;
}
@Override
public LocalTransactionState checkLocalTransaction(MessageExt
return LocalTransactionState.ROLLBACK_MESSAGE;
// 如果没有收到生产者发送的Half Message的响应，broker发送请求到生产 者回查生产者本地事务的状态
//
// 该方法用于获取本地事务执行的状态。 System.out.println("检查本地事务的状态:" + msg); return LocalTransactionState.COMMIT_MESSAGE;
  return LocalTransactionState.ROLLBACK_MESSAGE;
} };
        TransactionMQProducer producer = new
TransactionMQProducer("tx_producer_grp_08");
        producer.setTransactionListener(listener);
        producer.setNamesrvAddr("node1:9876");
        producer.start();
        Message message = null;
        message = new Message("tp_demo_08", "hello lagou - tx".getBytes());
        producer.sendMessageInTransaction(message, "
{\"name\":\"zhangsan\"}");
} }
```



### 6. 主题读队列和写队列的含义



默认值为：readqueue=8，writequeue=8



在正常使用的时候：

1. readqueue=writequeue；
2. 如果readqueue>writequeue，会导致有些消费者消费不到消息；
3. 如果readqueue<writequeue，会导致消息无法消费，引起消息丢失。



读写队列主要用于**平滑扩缩容**。

对于扩容来讲：

1. 首先扩容readqueue，此时消费者可以关联到所有的读队列；
2. 然后在扩容writequeue，达到readqueue的数量即可。



对于缩容：

1. 首先缩容writequeue，此时生产者只能向指定个数的writequeue写索引；
2. 等原来messagequeue中的多余索引消息消费完，就可以缩容readqueue，不会引起消息的丢失。



### 7. RocketMQ中msgId和offsetMsgId 为什么会有俩个id，各自的作用是什么？

- msgId：该ID 是消息发送者在消息发送时会首先在客户端生成，全局唯一，也叫uniqId。
- offsetMsgId：消息偏移ID，该 ID 记录了消息所在集群的物理地址，包括消息所在Broker的IP地址和端口号，以及所在commitlog文件的物理偏移量。

<img src="rocketmq.assets/image-20201109164529563.png" alt="image-20201109164529563" style="zoom: 67%;" />



```shell
# 此处的id字符串是offsetMsgId
mqadmin queryMsgById -n localhost:9876 -i "C0A8646500002A9F000000000000F2E2"
```



```shell
# 此处的id字符串是全局唯一的msgId
mqadmin queryMsgByUniqueKey -i "0A470A3445501F89AB832CAC2E300000" -n localhost:9876 -t tp_test_01
# 此处的id字符串是offsetMsgId
mqadmin queryMsgByUniqueKey -i "C0A8646500002A9F000000000000F2E2" -n localhost:9876 -t tp_test_01
```

rocketmq-console对messageId做了兼容，既可以通过msgId查询，也可以通过offsetMsgId查询。





### 8. RocketMQ为什么没有使用kafka中的ISR和OSR队列呢？各自的优缺点是什么



主从同步复制，主从异步复制

同步刷盘，异步刷盘



Kafka每个分片的副本在一个文件夹中，该文件夹中包括Log文件，索引文件和时间戳索引文件。

每个Kafka的Broker上管理多个主题分区，是多个分立的文件夹。



RocketMQ中，每个Broker上一个Log文件，该Log文件是共享的，MessageQueue对应于主题分片。

每个Broker上的日志文件是一个整体的分片。没有主题分片副本的概念。



对于RocketMQ的共享Log文件：

1. 每次Mmap只能管理1.5-2GB的内存空间
2. 整个Broker上一个Log文件片段是1GB
3. 不需要对不同的主题打开不同的Log文件片段，有利于Mmap维护。
4. 需要打开的文件数变少了，主题数量对系统吞吐量的影响比Kafka要小。





## 五、面试题

1、RocketMQ Broker中的消息被消费后会立即删除吗？

不会，每条消息都会持久化到CommitLog中，每个Consumer连接到Broker后会维持消费进度信息，当有消息消费后只是当前Consumer的消费进度（CommitLog的offset）更新了。

 

追问：那么消息会堆积吗？什么时候清理过期消息？

默认72小时后会删除不再使用的CommitLog文件

 

检查这个文件最后访问时间

判断是否大于过期时间

指定时间删除，默认凌晨4点

 

2、RocketMQ消费模式有几种？

**集群消费**

1. 一条消息只会被同Group中的一个Consumer消费

2. 多个Group同时消费一个Topic时，每个Group都会有一个Consumer消费到数据

**广播消费**

消息将对一个Consumer Group下的各个Consumer实例都消费一遍。即使这些Consumer属于同一个Consumer Group，消息也会被Consumer Group中的每个Consumer都消费一次。

 

3、消费消息是push还是pull？

RocketMQ没有真正意义的push，都是pull，虽然有push类，但实际底层实现采用的是长轮询机制，即拉取方式。

 

broker端属性 longPollingEnable 标记是否开启长轮询。默认开启

 

追问：为什么要主动拉取消息而不使用事件监听方式？

事件驱动方式是建立好长连接，由事件（发送数据）的方式来实时推送。

 

如果broker主动推送消息的话有可能push速度快，消费速度慢的情况，那么就会造成消息在consumer端堆积过多，同时又不能被其他consumer消费的情况。而pull的方式可以根据当前自身情况来pull，不会造成过多的压力而造成瓶颈。所以采取了pull的方式。

 

4、broker如何处理拉取请求的？

Consumer首次请求Broker

 

Broker中是否有符合条件的消息

有 ->响应Consumer

等待下次Consumer的请求

没有

PullRequestHoldService 来Hold连接，每个5s执行一次检查pullRequestTable有没有消息，有的话立即推送

每隔1ms检查commitLog中是否有新消息，有的话写入到pullRequestTable

当有新消息的时候返回请求

挂起consumer的请求，即不断开连接，也不返回数据使用consumer的offset。

 

5、RocketMQ如何做负载均衡？

通过Topic在多Broker中分布式存储实现。

 

producer端

发送端指定message queue发送消息到相应的broker，来达到写入时的负载均衡

 

提升写入吞吐量，当多个producer同时向一个broker写入数据的时候，性能会下降

消息分布在多broker中，为负载消费做准备

默认策略是随机选择：

 

producer维护一个index

每次取节点会自增

index向所有broker个数取余

自带容错策略

其他实现：

 

SelectMessageQueueByHash

hash的是传入的args

SelectMessageQueueByRandom

SelectMessageQueueByMachineRoom 没有实现

也可以自定义实现MessageQueueSelector接口中的select方法

 

MessageQueue select(final List\<MessageQueue> mqs, final Message msg, final Object arg);

consumer端

采用的是平均分配算法来进行负载均衡。

 

其他负载均衡算法

 

平均分配策略(默认)(AllocateMessageQueueAveragely)

环形分配策略(AllocateMessageQueueAveragelyByCircle)

手动配置分配策略(AllocateMessageQueueByConfig)

机房分配策略(AllocateMessageQueueByMachineRoom)

一致性哈希分配策略(AllocateMessageQueueConsistentHash)

靠近机房策略(AllocateMachineRoomNearby)

 

追问：当消费负载均衡consumer和queue不对等的时候会发生什么？

Consumer和queue会优先平均分配，如果Consumer少于queue的个数，则会存在部分Consumer消费多个queue的情况，如果Consumer等于queue的个数，那就是一个Consumer消费一个queue，如果Consumer个数大于queue的个数，那么会有部分Consumer空余出来，白白的浪费了。

 

6、消息重复消费

影响消息正常发送和消费的重要原因是网络的不确定性。

 

引起重复消费的原因

 

ACK

正常情况下在consumer真正消费完消息后应该发送ack，通知broker该消息已正常消费，从queue中剔除

 

当ack因为网络原因无法发送到broker，broker会认为词条消息没有被消费，此后会开启消息重投机制把消息再次投递到consumer

 

消费模式

在CLUSTERING模式下，消息在broker中会保证相同group的consumer消费一次，但是针对不同group的consumer会推送多次

 

解决方案

 

数据库表

处理消息前，使用消息主键在表中带有约束的字段中insert

 

Map

单机时可以使用map ConcurrentHashMap -> putIfAbsent  guava cache

 

Redis

分布式锁。

 

7、如何让RocketMQ保证消息的顺序消费

你们线上业务用消息中间件的时候，是否需要保证消息的顺序性?

 

如果不需要保证消息顺序，为什么不需要?假如我有一个场景要保证消息的顺序，你们应该如何保证?

 

首先多个queue只能保证单个queue里的顺序，queue是典型的FIFO，天然顺序。多个queue同时消费是无法绝对保证消息的有序性的。所以总结如下：

 

同一topic，同一个QUEUE，发消息的时候一个线程去发送消息，消费的时候 一个线程去消费一个queue里的消息。

 

追问：怎么保证消息发到同一个queue？

Rocket MQ给我们提供了MessageQueueSelector接口，可以自己重写里面的接口，实现自己的算法，举个最简单的例子：判断i % 2 == 0，那就都放到queue1里，否则放到queue2里。

 

复制代码

for (int i = 0; i < 5; i++) {

  Message message = new Message("orderTopic", ("hello!" + i).getBytes());

  producer.send(

​    // 要发的那条消息

​    message,

​    // queue 选择器 ，向 topic中的哪个queue去写消息

​    new MessageQueueSelector() {

​      // 手动 选择一个queue

​      @Override

​      public MessageQueue select(

​        // 当前topic 里面包含的所有queue

​        List<MessageQueue> mqs,

​        // 具体要发的那条消息

​        Message msg,

​        // 对应到 send（） 里的 args，也就是2000前面的那个0

​        Object arg) {

​        // 向固定的一个queue里写消息，比如这里就是向第一个queue里写消息

​        if (Integer.parseInt(arg.toString()) % 2 == 0) {

​          return mqs.get(0);

​        } else {

​          return mqs.get(1);

​        }

​      }

​    },

​    // 自定义参数：0

​    // 2000代表2000毫秒超时时间

​    i, 2000);

}

复制代码

8、RocketMQ如何保证消息不丢失

首先在如下三个部分都可能会出现丢失消息的情况：

- Producer端

- Broker端

- Consumer端



9、Producer端如何保证消息不丢失

采取send()同步发消息，发送结果是同步感知的。

发送失败后可以重试，设置重试次数。默认3次。

producer.setRetryTimesWhenSendFailed(10);

 

集群部署，比如发送失败了的原因可能是当前Broker宕机了，重试的时候会发送到其他Broker上。



10、Broker端如何保证消息不丢失

修改刷盘策略为同步刷盘。默认情况下是异步刷盘的。

flushDiskType = SYNC_FLUSH

 

集群部署，主从模式，高可用。



11、Consumer端如何保证消息不丢失

完全消费正常后在进行手动ack确认。



12、rocketMQ的消息堆积如何处理

下游消费系统如果宕机了，导致几百万条消息在消息中间件里积压，此时怎么处理?

 你们线上是否遇到过消息积压的生产故障?如果没遇到过，你考虑一下如何应对?

 首先要找到是什么原因导致的消息堆积，是Producer太多了，Consumer太少了导致的还是说其他情况，总之先定位问题。

 然后看下消息消费速度是否正常，正常的话，可以通过上线更多consumer临时解决消息堆积问题

 追问：如果Consumer和Queue不对等，上线了多台也在短时间内无法消费完堆积的消息怎么办？

准备一个临时的topic

queue的数量是堆积的几倍

queue分布到多Broker中

上线一台Consumer做消息的搬运工，把原来Topic中的消息挪到新的Topic里，不做业务逻辑处理，只是挪过去

上线N台Consumer同时消费临时Topic中的数据

改bug

恢复原来的Consumer，继续消费之前的Topic

追问：堆积时间过长消息超时了？

RocketMQ中的消息只会在commitLog被删除的时候才会消失，不会超时。也就是说未被消费的消息不会存在超时删除这情况。

 

追问：堆积的消息会不会进死信队列？

不会，消息在消费失败后会进入重试队列（%RETRY%+ConsumerGroup），18次（默认18次，网上所有文章都说是16次，无一例外。但是我没搞懂为啥是16次，这不是18个时间吗 ？）才会进入死信队列（%DLQ%+ConsumerGroup）。

 

源码如下：

 

public class MessageStoreConfig {

  // 每隔如下时间会进行重试，到最后一次时间重试失败的话就进入死信队列了。

 private String messageDelayLevel = "1s 5s 10s 30s 1m 2m 3m 4m 5m 6m 7m 8m 9m 10m 20m 30m 1h 2h";

}

13、RocketMQ在分布式事务支持这块机制的底层原理?

你们用的是RocketMQ?RocketMQ很大的一个特点是对分布式事务的支持，你说说他在分布式事务支持这块机制的底层原理?

 

分布式系统中的事务可以使用TCC（Try、Confirm、Cancel）、2pc来解决分布式系统中的消息原子性

 

RocketMQ 4.3+提供分布事务功能，通过 RocketMQ 事务消息能达到分布式事务的最终一致

 

RocketMQ实现方式：

 

**Half Message：**预处理消息，当broker收到此类消息后，会存储到RMQ_SYS_TRANS_HALF_TOPIC的消息消费队列中

 

**检查事务状态：**Broker会开启一个定时任务，消费RMQ_SYS_TRANS_HALF_TOPIC队列中的消息，每次执行任务会向消息发送者确认事务执行状态（提交、回滚、未知），如果是未知，Broker会定时去回调在重新检查。

 

**超时：**如果超过回查次数，默认回滚消息。

 

也就是他并未真正进入Topic的queue，而是用了临时queue来放所谓的half message，等提交事务后才会真正的将half message转移到topic下的queue。

 

14、如果让你来动手实现一个分布式消息中间件，整体架构你会如何设计实现?

我个人觉得从以下几个点回答吧：

 

需要考虑能快速扩容、天然支持集群

持久化的姿势

高可用性

数据0丢失的考虑

服务端部署简单、client端使用简单

15、看过RocketMQ 的源码没有。如果看过，说说你对RocketMQ 源码的理解?

里面比较典型的设计模式有单例、工厂、策略、门面模式。单例工厂无处不在，策略印象深刻比如发消息和消费消息的时候queue的负载均衡就是N个策略算法类，有随机、hash等，这也是能够快速扩容天然支持集群的必要原因之一。持久化做的也比较完善，采取的CommitLog来落盘，同步异步两种方式。

 

16、高吞吐量下如何优化生产者和消费者的性能?

开发

同一group下，多机部署，并行消费

单个Consumer提高消费线程个数

批量消费

消息批量拉取

业务逻辑批量处理

运维

网卡调优

jvm调优

多线程与cpu调优

Page Cache

 

17、说说RocketMQ是如何保证数据的高容错性的?

在不开启容错的情况下，轮询队列进行发送，如果失败了，重试的时候过滤失败的Broker

如果开启了容错策略，会通过RocketMQ的预测机制来预测一个Broker是否可用。

如果上次失败的Broker可用那么还是会选择该Broker的队列

如果上述情况失败，则随机选择一个进行发送

在发送消息的时候会记录一下调用的时间与是否报错，根据该时间去预测broker的可用时间。其实就是send消息的时候queue的选择。

源码：

org.apache.rocketmq.client.latency.MQFaultStrategy#selectOneMessageQueue()

 

18、任何一台Broker突然宕机了怎么办？

Broker主从架构以及多副本策略。

Master收到消息后会同步给Slave，Master宕机了还有slave中的消息可用，保证了MQ的可靠性和高可用性。而且Rocket MQ4.5.1开始就支持了Dlegder模式，基于raft做到了真正意义的HA。

 

19、Broker把自己的信息注册到哪个NameServer上？

Broker会向所有的NameServer上注册自己的信息，而不是某一个，是全部。多线程的方式向所有NameServer上注册。'

 

20、RocketMQ由哪些角色组成，每个角色作用和特点是什么？

Nameserver  无状态，动态列表；这也是和zookeeper的重要区别之一。zookeeper是有状态的。

Producer 消息生产者，负责发消息到Broker。

Broker  就是MQ本身，负责收发消息、持久化消息等。

Consumer   消息消费者，负责从Broker上拉取消息进行消费，消费完进行ack。

 

21、RocketMQ中的Topic和JMS的queue有什么区别？

queue就是来源于数据结构的FIFO队列。而Topic是个抽象的概念，每个Topic底层对应N个queue，而数据也真实存在queue上的。

