## 源码剖析-内嵌Tomcat

Spring Boot默认支持Tomcat，Jetty，和Undertow作为底层容器。

而Spring Boot默认使用Tomcat，一旦引入spring-boot-starter-web模块，就默认使用Tomcat容器。

```xml
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-web</artifactId>
</dependency>
```



### Servlet容器的使用

#### 默认servlet容器	

我们看看spring-boot-starter-web这个starter中有什么

<img src="img/image-20201123161230378.png" alt="image-20201123161230378" style="zoom:80%;" />



核心就是引入了tomcat和SpringMvc



### 切换servlet容器

那如果我么想切换其他Servlet容器呢，只需如下两步：

- 将tomcat依赖移除掉
- 引入其他Servlet容器依赖

引入jetty：

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
    <exclusions>
        <exclusion>
            <!--移除spring-boot-starter-web中的tomcat-->
            <artifactId>spring-boot-starter-tomcat</artifactId>
            <groupId>org.springframework.boot</groupId>
        </exclusion>
    </exclusions>
</dependency>

<dependency>
    <groupId>org.springframework.boot</groupId>
    <!--引入jetty-->
    <artifactId>spring-boot-starter-jetty</artifactId>
</dependency>
```



### 内嵌Tomcat自动配置原理

在启动springboot的时候可谓是相当简单，只需要执行以下代码

```java
public static void main(String[] args) {
	SpringApplication.run(SpringBootMytestApplication.class, args);
}
```

那些看似简单的事物，其实并不简单。我们之所以觉得他简单，是因为复杂性都被隐藏了。通过上诉代码，大概率可以提出以下几个疑问

- SpringBoot是如何启动内置tomcat的
- SpringBoot为什么可以响应请求，他是如何配置的SpringMvc



#### SpringBoot启动内置tomcat流程

1、进入SpringBoot启动类，点进@SpringBootApplication源码，如下图

<img src="img/image-20200218165203584.png" alt="image-20200218165203584" style="zoom:40%;" />

------------------------



<img src="img/image-20200218165233922.png" alt="image-20200218165233922" style="zoom:40%;" />



2、继续点进@EnableAutoConfiguration,进入该注解，如下图

<img src="img/image-20200218165352083.png" alt="image-20200218165352083" style="zoom:40%;" />



3、上图中使用@Import注解对AutoConfigurationImportSelector 类进行了引入，该类做了什么事情呢？进入源码，首先调用selectImport()方法，在该方法中调用了getAutoConfigurationEntry（）方法，在之中又调用了getCandidateConfigurations()方法，getCandidateConfigurations()方法就去META-INF/spring.factory配置文件中加载相关配置类

<img src="img/image-20200218165718781.png" alt="image-20200218165718781" style="zoom:40%;" />



这个spring.factories配置文件是加载的spring-boot-autoconfigure的配置文件

<img src="img/image-20200218165827431.png" alt="image-20200218165827431" style="zoom:50%;" />



继续打开spring.factories配置文件，找到tomcat所在的类，tomcat加载在ServletWebServerFactoryAutoConfiguration配置类中



<img src="img/image-20200218170001683.png" alt="image-20200218170001683" style="zoom:40%;" />



进入该类，里面也通过@Import注解将EmbeddedTomcat、EmbeddedJetty、EmbeddedUndertow等嵌入式容器类加载进来了，springboot默认是启动嵌入式tomcat容器，如果要改变启动jetty或者undertow容器，需在pom文件中去设置。如下图：

<img src="img/image-20200218170113075.png" alt="image-20200218170113075" style="zoom:40%;" />



继续进入EmbeddedTomcat类中，见下图：

<img src="img/image-20200218170414296.png" alt="image-20200218170414296" style="zoom:40%;" />

进入TomcatServletWebServerFactory类，里面的getWebServer（）是关键方法，如图：

<img src="img/image-20200218170829834.png" alt="image-20200218170829834" style="zoom:40%;" />



继续进入getTomcatWebServer()等方法，一直往下跟到tomcat初始化方法，调用tomcat.start()方法，tomcat就正式开启运行，见图

<img src="img/image-20200218170937061.png" alt="image-20200218170937061" style="zoom:40%;" />

走到这里tomcat在springboot中的配置以及最终启动的流程就走完了，相信大家肯定有一个疑问，上上图中的getWebServer()方法是在哪里调用的呢？上面的代码流程并没有发现getWebServer()被调用的地方。因为getWebServer()方法的调用根本就不在上面的代码流程中，它是在另外一个流程中被调用的



#### getWebServer()的调用分析

首先进入SpringBoot启动类的run方法：

```java
SpringApplication.run(HppaApplication.class, args);
```

这个会最终调用到一个同名方法run(String… args)

```java
public ConfigurableApplicationContext run(String... args) {
	//StopWatch主要是用来统计每项任务执行时长，例如Spring Boot启动占用总时长。
	StopWatch stopWatch = new StopWatch();
	stopWatch.start();
	ConfigurableApplicationContext context = null;
	Collection<SpringBootExceptionReporter> exceptionReporters = new ArrayList<>();
	configureHeadlessProperty();
	//第一步：获取并启动监听器 通过加载META-INF/spring.factories 完成了SpringApplicationRunListener实例化工作
	SpringApplicationRunListeners listeners = getRunListeners(args);
	//实际上是调用了EventPublishingRunListener类的starting()方法
	listeners.starting();
	try {
		ApplicationArguments applicationArguments = new DefaultApplicationArguments(args);
		//第二步：构造容器环境，简而言之就是加载系统变量，环境变量，配置文件
		ConfigurableEnvironment environment = prepareEnvironment(listeners, applicationArguments);
		//设置需要忽略的bean
		configureIgnoreBeanInfo(environment);
		//打印banner
		Banner printedBanner = printBanner(environment);
		//第三步：创建容器
		context = createApplicationContext();
		//第四步：实例化SpringBootExceptionReporter.class，用来支持报告关于启动的错误
		exceptionReporters = getSpringFactoriesInstances(SpringBootExceptionReporter.class,
				new Class[] { ConfigurableApplicationContext.class }, context);
		//第五步：准备容器 这一步主要是在容器刷新之前的准备动作。包含一个非常关键的操作：将启动类注入容器，为后续开启自动化配置奠定基础。
		prepareContext(context, environment, listeners, applicationArguments, printedBanner);
		//第六步：刷新容器 springBoot相关的处理工作已经结束，接下的工作就交给了spring。 内部会调用spring的refresh方法，
		// refresh方法在spring整个源码体系中举足轻重，是实现 ioc 和 aop的关键。
		refreshContext(context);
		//第七步：刷新容器后的扩展接口 设计模式中的模板方法，默认为空实现。如果有自定义需求，可以重写该方法。比如打印一些启动结束log，或者一些其它后置处理。
		afterRefresh(context, applicationArguments);
		stopWatch.stop();
		if (this.logStartupInfo) {
			new StartupInfoLogger(this.mainApplicationClass).logStarted(getApplicationLog(), stopWatch);
		}
		//发布应用已经启动的事件
		listeners.started(context);
		/*
		 * 遍历所有注册的ApplicationRunner和CommandLineRunner，并执行其run()方法。
		 * 我们可以实现自己的ApplicationRunner或者CommandLineRunner，来对SpringBoot的启动过程进行扩展。
		 */
		callRunners(context, applicationArguments);
	}
	catch (Throwable ex) {
		handleRunFailure(context, ex, exceptionReporters, listeners);
		throw new IllegalStateException(ex);
	}

	try {
		//应用已经启动完成的监听事件
		listeners.running(context);
	}
	catch (Throwable ex) {
		handleRunFailure(context, ex, exceptionReporters, null);
		throw new IllegalStateException(ex);
	}
	return context;
}
```

这个方法大概做了以下几件事

1. 获取并启动监听器 通过加载META-INF/spring.factories 完成了SpringApplicationRunListener实例化工作
2. 构造容器环境，简而言之就是加载系统变量，环境变量，配置文件
3. 创建容器
4. 实例化SpringBootExceptionReporter.class，用来支持报告关于启动的错误
5. 准备容器
6. 刷新容器
7. 刷新容器后的扩展接口

那么内置tomcat启动源码，就是隐藏在上诉第六步：refreshContext方法里面，该方法最终会调用到AbstractApplicationContext类的refresh()方法

进入refreshContext()方法，如图：

```java
public void refresh() throws BeansException, IllegalStateException {
	synchronized (this.startupShutdownMonitor) {
		// Prepare this context for refreshing.
		prepareRefresh();

		// Tell the subclass to refresh the internal bean factory.
		ConfigurableListableBeanFactory beanFactory = obtainFreshBeanFactory();

		// Prepare the bean factory for use in this context.
		prepareBeanFactory(beanFactory);

		try {
			// Allows post-processing of the bean factory in context subclasses.
			postProcessBeanFactory(beanFactory);

			// Invoke factory processors registered as beans in the context.
			invokeBeanFactoryPostProcessors(beanFactory);

			// Register bean processors that intercept bean creation.
			registerBeanPostProcessors(beanFactory);

			// Initialize message source for this context.
			initMessageSource();

			// Initialize event multicaster for this context.
			initApplicationEventMulticaster();

			// Initialize other special beans in specific context subclasses.
			onRefresh();

			// Check for listener beans and register them.
			registerListeners();

			// Instantiate all remaining (non-lazy-init) singletons.
			finishBeanFactoryInitialization(beanFactory);

			// Last step: publish corresponding event.
			finishRefresh();
		}

		catch (BeansException ex) {
			if (logger.isWarnEnabled()) {
				logger.warn("Exception encountered during context initialization - " +
						"cancelling refresh attempt: " + ex);
			}

			// Destroy already created singletons to avoid dangling resources.
			destroyBeans();

			// Reset 'active' flag.
			cancelRefresh(ex);

			// Propagate exception to caller.
			throw ex;
		}

		finally {
			// Reset common introspection caches in Spring's core, since we
			// might not ever need metadata for singleton beans anymore...
			resetCommonCaches();
		}
	}
}
```

一直点击refresh()方法，如图：

onRefresh()会调用到ServletWebServerApplicationContext中的createWebServer()

<img src="img/image-20200218171528863.png" alt="image-20200218171528863" style="zoom:50%;" />



```java
private void createWebServer() {
	WebServer webServer = this.webServer;
	ServletContext servletContext = getServletContext();
	if (webServer == null && servletContext == null) {
		ServletWebServerFactory factory = getWebServerFactory();
		this.webServer = factory.getWebServer(getSelfInitializer());
	}
	else if (servletContext != null) {
		try {
			getSelfInitializer().onStartup(servletContext);
		}
		catch (ServletException ex) {
			throw new ApplicationContextException("Cannot initialize servlet context", ex);
		}
	}
	initPropertySources();
}
```

createWebServer()就是启动web服务，但是还没有真正启动Tomcat，既然webServer是通过ServletWebServerFactory来获取的，那就来看看这个工厂的真面目。

<img src="img/image-20200218172123083.png" alt="image-20200218172123083" style="zoom:40%;" />

可以看到，tomcat,Jetty都实现了这个getWebServer方法，我们看TomcatServletWebServerFactory中的getWebServer(ServletContextInitializer… initializers).



<img src="img/image-20200218172314563.png" alt="image-20200218172314563" style="zoom:40%;" />



最终就调用了TomcatServletWebServerFactory类的getWebServer()方法。

![image-20201123173942734](img/image-20201123173942734.png)

#### 小结

springboot的内部通过`new Tomcat()`的方式启动了一个内置Tomcat。但是这里还有一个问题，这里只是启动了tomcat，但是我们的springmvc是如何加载的呢？下一章我们讲接收，springboot是如何自动装配springmvc的