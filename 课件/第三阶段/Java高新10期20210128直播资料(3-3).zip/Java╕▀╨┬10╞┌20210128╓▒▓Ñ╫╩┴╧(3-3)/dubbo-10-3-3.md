1.Dubbo在实际工作中场景是怎么样的，能举个例子吗

​       dubbo 一般作为基础服务    然后配合其它的分布式技术进行调用    早期没有SpringCloud的时候 还是非常流行的技术。dubbo springcloud Alibaba 中 已经可以完美整合了。

| 功能组件                                             | Spring Cloud                 | Dubbo Spring Cloud                              |
| ---------------------------------------------------- | ---------------------------- | ----------------------------------------------- |
| 分布式配置（Distributed configuration）              | Git、Zookeeper、Consul、JDBC | Spring Cloud 分布式配置 + Dubbo 配置中心        |
| 服务注册与发现（Service registration and discovery） | Eureka、Zookeeper、Consul    | Spring Cloud 原生注册中心 + Dubbo 原生注册中心  |
| 负载均衡（Load balancing）                           | Ribbon（随机、轮询等算法）   | Dubbo 内建实现（随机、轮询等算法 + 权重等特性） |
| 服务熔断（Circuit Breakers）                         | Spring Cloud Hystrix         | Spring Cloud Hystrix + Alibaba Sentinel 等      |
| 服务调用（Service-to-service calls）                 | Open Feign、RestTemplate     | Spring Cloud 服务调用 + Dubbo @Reference        |
| 链路跟踪（Tracing）                                  | Spring Cloud Sleuth + Zipkin | Zipkin、opentracing 等                          |



2.dubbo不需要单独导入spring的包? AnnotationConfigApplicationContext类，Configuration注解属于spring，课程视频中的项目未引用dependency，DubboPureMain中测试类为什么能正常启动？

dubbo 是依赖于spring的    打开dubbo的jar包是可以看到这些依赖的  



3.学dubbo的时候看到有SPI功能，我感觉这个也是注入服务的实现类。 spring的IOC也是类的实现注入； 那么 dubbo是想在不引人spring的前提下来解决动态扩展的问题吗？

SPI 全称为 (Service Provider Interface) ，是JDK内置的一种服务提供发现机制。 目前有不少框架用它来做服务的扩展发现，简单来说，它就是一种动态替换发现的机制。使用SPI机制的优势是实现解耦，使得第三方服务模块的装配控制逻辑与调用者的业务代码分离。IOC 只是一种思想  不是Spring 专有的。dubbo 使用SPI 进制  对SPI 进制做扩展  结合 AOP  和 IOC  ，相互配合 为服务扩展提供更加方便的服务。



常见的面试题 

 什么是dubbo   特性  调用过程  

 什么是SPI  dubbo中的SPI 做了哪些改进 

dubbo的负载均衡策略      一致性hash

dubbo 注册中心挂了之后   是否能进行服务调用 

dubbo的架构层次 (调用原理 )

dubbo的服务注册和发现的流程 

dubbo的集群容错策略

dubbo的服务降级手段 

dubbo 支持的协议  特点    能否改进 

dubbo 如何处理粘包和拆包

如何设计一个RPC 框架   



 