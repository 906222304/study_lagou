package com.lagou;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.boot.autoconfigure.transaction.jta.JtaAutoConfiguration;

//@EnableTransactionManagement
@SpringBootApplication(exclude = JtaAutoConfiguration.class)
public class RunBoot {
}
